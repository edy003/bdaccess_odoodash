/** @odoo-module **/

import { Component } from "@odoo/owl";
import { registry } from "@web/core/registry";

// Définition du composant
export class HelloComponent extends Component {
}
HelloComponent.template = "qc_dashboard.HelloTemplate";

// Enregistrement dans les actions Odoo
registry.category("actions").add("qc_dashboard.hello_action", HelloComponent);
