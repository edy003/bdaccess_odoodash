# -*- coding: utf-8 -*-
{
    'name': 'QC Dashboard avec Analytics',
    'version': '1.1',
    'summary': 'Dashboard KPI avec graphiques Plotly',
    # 'sequence': -1,
    'description': """
    Tableau de bord avancé avec :
    - KPI des utilisateurs
    - Graphiques interactifs Plotly
    - Analytics en temps réel
    """,
    'category': 'Dashboard',
    'depends': ['base', 'web'],
    'data': [
        # 'views/kpi_card_views.xml',
        # 'qc_dashboard/static/src/xml/templates.xml',
        # 'qc_dashboard/static/src/xml/kpi_card.xml',
        'views/kpi_card_views.xml',
        # 'views/user_kpi_dashboard.xml',

    ],
    'qweb': [
        # 'static/src/xml/dashboard_templates.xml',
        # 'qc_dashboard/static/src/xml/templates.xml',
        # 'qc_dashboard/static/src/xml/kpi_card.xml',
        # 'qc_dashboard/static/src/xml/kpi_card.xml',
        # 'qc_dashboard/static/src/js/my_component.xml',

    ],
    'assets': {
        'web.assets_backend': [
            'qc_dashboard/static/src/css/dist/output.css',
            'qc_dashboard/static/src/css/kpi.css',
            'qc_dashboard/static/src/xml/templates.xml',
            'qc_dashboard/static/src/xml/kpi_card.xml',
            'qc_dashboard/static/src/js/kpi_card.js',
            'qc_dashboard/static/src/js/kpi_dashboard.js',
            'https://cdn.plot.ly/plotly-3.1.0.min.js',
        ],
        'web.assets_qweb': [
            'qc_dashboard/static/src/xml/templates.xml',
            'qc_dashboard/static/src/xml/kpi_card.xml',

            # Templates QWeb legacy si nécessaire
        ],
    },
    'demo': [],
    'installable': True,
    'application': True,
}