/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./static/src/**/*.{html,js,xml}"],
  theme: {
    extend: {},
  },
  plugins: [],
  blocklist: ['container', 'collapse'],
};