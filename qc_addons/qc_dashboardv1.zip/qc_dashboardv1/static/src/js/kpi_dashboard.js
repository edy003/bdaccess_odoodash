/** @odoo-module **/
import { registry } from "@web/core/registry";
import { useService } from "@web/core/utils/hooks";

const { Component } = owl;
const { useState, onMounted, useRef } = owl.hooks;

console.log("Chargement de kpi_dashboard.js");
console.log("Plotly disponible ?", typeof Plotly !== 'undefined');

export class UserKPIDashboard extends Component {
    setup() {
        console.log("Initialisation du composant UserKPIDashboard");
        this.state = useState({
            kpiData: {
                title: "Nombre d'utilisateurs",
                value: 0,
                description: "Total des utilisateurs dans Odoo.",
            },
            chartData: null,
            loading: true,
            error: null,
            activeUsers: 0,
            newUsers: 0,
            currentFilter: 'all', // Ajout du filtre actuel
            rawData: null // Ajout des données brutes
        });
        this.rpc = useService("rpc");
        this.chartRef = useRef("plotly-chart");
        
        onMounted(() => {
            this.loadDashboardData();
        });
    }
    
    async loadDashboardData(filterType = 'all') {
        try {
            console.log("Chargement des données du dashboard avec filtre:", filterType);
            this.state.loading = true;
            this.state.error = null;
            
            // Appel au contrôleur Python avec le filtre
            const result = await this.rpc("/dashboard/user_analytics", {
                filter_type: filterType
            });
            
            console.log("Réponse du serveur:", result);
            
            if (result.error) {
                this.state.error = result.message;
                console.error("Erreur retournée par le serveur:", result.message);
                return;
            }
            
            // Mise à jour du titre selon le filtre
            let title = "Nombre d'utilisateurs";
            let description = "Total des utilisateurs dans Odoo.";
            
            if (filterType === 'active') {
                title = "Utilisateurs actifs";
                description = "Total des utilisateurs actifs dans Odoo.";
            } else if (filterType === 'inactive') {
                title = "Utilisateurs inactifs";
                description = "Total des utilisateurs inactifs dans Odoo.";
            }
            
            // Mise à jour des données KPI
            this.state.kpiData.title = title;
            this.state.kpiData.description = description;
            this.state.kpiData.value = result.total_users;
            this.state.activeUsers = result.active_users;
            this.state.newUsers = result.new_users;
            this.state.currentFilter = filterType;
            
            // Stockage des données brutes pour les statistiques détaillées
            this.state.rawData = result;
            
            // Mise à jour des données du graphique
            this.state.chartData = result.chart_data;
            
            console.log("Données du dashboard chargées:", result);
            console.log("État du composant mis à jour:", this.state);
            
            // Petit délai pour s'assurer que le DOM est prêt
            setTimeout(() => {
                this.renderChart();
            }, 100);
            
        } catch (error) {
            console.error("Erreur lors du chargement des données:", error);
            this.state.error = "Erreur lors du chargement des données: " + error.message;
        } finally {
            this.state.loading = false;
        }
    }
    
    // Gestionnaire pour le changement de filtre
    async onFilterChange(event) {
        const filterValue = event.target.value;
        console.log("Changement de filtre vers:", filterValue);
        await this.loadDashboardData(filterValue);
    }
    
    renderChart() {
        if (!this.state.chartData || !this.chartRef.el) {
            console.warn("Données du graphique ou élément DOM manquants");
            return;
        }
        
        if (typeof Plotly === 'undefined') {
            console.warn("Plotly non disponible");
            this.state.error = "Plotly n'est pas chargé";
            return;
        }
        
        try {
            const data = [{
                x: this.state.chartData.labels,
                y: this.state.chartData.values,
                type: 'bar',
                marker: {
                    color: ['#3B82F6', '#EF4444', '#10B981', '#8B5CF6', '#F59E0B'],
                    opacity: 0.8
                },
                text: this.state.chartData.values.map(v => v.toString()),
                textposition: 'auto',
            }];
            
            let chartTitle = 'Analytics des Utilisateurs';
            if (this.state.currentFilter === 'active') {
                chartTitle = 'Analytics des Utilisateurs Actifs';
            } else if (this.state.currentFilter === 'inactive') {
                chartTitle = 'Analytics des Utilisateurs Inactifs';
            }
            
            const layout = {
                title: {
                    text: chartTitle,
                    font: { size: 18, color: '#1F2937' }
                },
                xaxis: {
                    title: 'Catégories',
                    tickangle: -45
                },
                yaxis: {
                    title: 'Nombre d\'utilisateurs'
                },
                plot_bgcolor: '#F9FAFB',
                paper_bgcolor: '#FFFFFF',
                margin: { t: 60, r: 30, b: 100, l: 60 },
                height: 400,
                responsive: true
            };
            
            const config = {
                displayModeBar: true,
                displaylogo: false,
                modeBarButtonsToRemove: ['pan2d', 'lasso2d', 'select2d']
            };
            
            Plotly.newPlot(this.chartRef.el, data, layout, config);
            console.log("Graphique Plotly rendu avec succès");
            
        } catch (error) {
            console.error("Erreur lors du rendu du graphique:", error);
            this.state.error = "Erreur lors du rendu du graphique: " + error.message;
        }
    }
}

// Template corrigé - plus de centrage et layout scrollable
UserKPIDashboard.template = owl.tags.xml`
    <div class="p-6 bg-gray-50 min-h-screen w-full">
        <div class="w-full">
            <!-- Header avec titre et filtres -->
            <div class="flex flex-col sm:flex-row sm:justify-between sm:items-center mb-8 gap-4">
                <h1 class="text-3xl font-bold text-gray-900">Dashboard Utilisateurs</h1>
                
                <!-- Dropdown de filtrage -->
                <div class="flex flex-col">
                    <label class="block text-sm font-medium text-gray-700 mb-2">Filtrer par statut</label>
                    <select 
                        class="block w-full sm:w-64 px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm bg-white"
                        t-on-change="onFilterChange"
                        t-att-value="state.currentFilter"
                    >
                        <option value="all">Tous les utilisateurs</option>
                        <option value="active">Utilisateurs actifs uniquement</option>
                        <option value="inactive">Utilisateurs inactifs uniquement</option>
                    </select>
                </div>
            </div>
            
            <!-- Message d'erreur -->
            <div t-if="state.error" class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-6">
                <strong>Erreur:</strong> <t t-esc="state.error"/>
            </div>
            
            <!-- Indicateur de filtre actif -->
            <div t-if="state.currentFilter !== 'all'" class="bg-blue-100 border border-blue-400 text-blue-700 px-4 py-3 rounded mb-6 flex items-center">
                <svg class="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 20 20">
                    <path fill-rule="evenodd" d="M3 3a1 1 0 011-1h12a1 1 0 011 1v3a1 1 0 01-.293.707L12 11.414V15a1 1 0 01-.293.707l-2 2A1 1 0 018 17v-5.586L3.293 6.707A1 1 0 013 6V3z" clip-rule="evenodd"/>
                </svg>
                <span>
                    Filtre actif: 
                    <span t-if="state.currentFilter === 'active'" class="font-semibold">Utilisateurs actifs seulement</span>
                    <span t-if="state.currentFilter === 'inactive'" class="font-semibold">Utilisateurs inactifs seulement</span>
                </span>
            </div>
            
            <!-- Section KPI - Cartes principales -->
            <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                <!-- KPI Principal (titre dynamique selon filtre) -->
                <div class="bg-white rounded-lg shadow-lg p-6 border-l-4 border-blue-500">
                    <div class="flex items-center justify-between">
                        <div>
                            <h2 class="text-lg font-semibold text-gray-900 mb-1">
                                <t t-esc="state.kpiData.title"/>
                            </h2>
                            <p class="text-3xl font-bold text-blue-600">
                                <t t-esc="state.kpiData.value"/>
                            </p>
                        </div>
                        <div class="text-blue-500">
                            <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197m13.5-9a2.5 2.5 0 11-5 0 2.5 2.5 0 015 0z"/>
                            </svg>
                        </div>
                    </div>
                    <p class="text-gray-600 text-sm mt-2">
                        <t t-esc="state.kpiData.description"/>
                    </p>
                </div>
                
                <!-- KPI Utilisateurs Actifs -->
                <div class="bg-white rounded-lg shadow-lg p-6 border-l-4 border-green-500">
                    <div class="flex items-center justify-between">
                        <div>
                            <h2 class="text-lg font-semibold text-gray-900 mb-1">Utilisateurs Actifs</h2>
                            <p class="text-3xl font-bold text-green-600">
                                <t t-esc="state.activeUsers"/>
                            </p>
                        </div>
                        <div class="text-green-500">
                            <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/>
                            </svg>
                        </div>
                    </div>
                    <p class="text-gray-600 text-sm mt-1">
                        <span t-if="state.currentFilter === 'all'">Utilisateurs avec statut actif</span>
                        <span t-elif="state.currentFilter === 'active'">Filtrés - statut actif</span>
                        <span t-else="">Actifs dans la sélection</span>
                    </p>
                    <div t-if="state.rawData and state.rawData.analytics_summary" class="text-xs text-gray-500 mt-2 flex items-center">
                        <span class="bg-green-100 text-green-800 px-2 py-1 rounded-full">
                            <t t-esc="state.rawData.analytics_summary.active_percentage"/>% du total
                        </span>
                    </div>
                </div>
                
                <!-- KPI Nouveaux Utilisateurs -->
                <div class="bg-white rounded-lg shadow-lg p-6 border-l-4 border-purple-500">
                    <div class="flex items-center justify-between">
                        <div>
                            <h2 class="text-lg font-semibold text-gray-900 mb-1">Nouveaux Utilisateurs</h2>
                            <p class="text-3xl font-bold text-purple-600">
                                <t t-esc="state.newUsers"/>
                            </p>
                        </div>
                        <div class="text-purple-500">
                            <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0zM3 20a6 6 0 0112 0v1H3v-1z"/>
                            </svg>
                        </div>
                    </div>
                    <p class="text-gray-600 text-sm mt-1">
                        <span t-if="state.currentFilter === 'all'">Créés dans les 30 derniers jours</span>
                        <span t-elif="state.currentFilter === 'active'">Nouveaux actifs (30j)</span>
                        <span t-else="">Nouveaux inactifs (30j)</span>
                    </p>
                    <div t-if="state.rawData and state.rawData.analytics_summary" class="text-xs text-gray-500 mt-2 flex items-center">
                        <span class="bg-purple-100 text-purple-800 px-2 py-1 rounded-full">
                            <t t-esc="state.rawData.analytics_summary.new_users_percentage"/>% du total
                        </span>
                    </div>
                </div>
            </div>
            
            <!-- Section Statistiques détaillées -->
            <div t-if="state.rawData and state.rawData.analytics_summary" class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
                <div class="bg-white rounded-lg shadow p-4 text-center">
                    <div class="text-2xl font-bold text-gray-800">
                        <t t-esc="state.rawData.analytics_summary.users_with_recent_login || 0"/>
                    </div>
                    <div class="text-sm text-gray-600">Connexions récentes</div>
                </div>
                
                <div class="bg-white rounded-lg shadow p-4 text-center">
                    <div class="text-2xl font-bold text-gray-800">
                        <t t-esc="state.rawData.analytics_summary.average_groups_per_user || 0"/>
                    </div>
                    <div class="text-sm text-gray-600">Groupes moyens/utilisateur</div>
                </div>
                
                <div class="bg-white rounded-lg shadow p-4 text-center">
                    <div class="text-2xl font-bold text-gray-800">
                        <t t-esc="state.rawData.analytics_summary.users_with_multiple_groups || 0"/>
                    </div>
                    <div class="text-sm text-gray-600">Multi-groupes</div>
                </div>
                
                <div class="bg-white rounded-lg shadow p-4 text-center">
                    <div class="text-2xl font-bold text-gray-800">
                        <t t-esc="state.rawData.analytics_summary.max_groups_per_user || 0"/>
                    </div>
                    <div class="text-sm text-gray-600">Max groupes</div>
                </div>
            </div>
            
            <!-- Section Graphique -->
            <div class="bg-white rounded-lg shadow-lg p-6">
                <div class="flex flex-col sm:flex-row sm:justify-between sm:items-center mb-4 gap-2">
                    <h2 class="text-xl font-bold text-gray-900">
                        <t t-if="state.currentFilter === 'active'">Analytics des Utilisateurs Actifs</t>
                        <t t-elif="state.currentFilter === 'inactive'">Analytics des Utilisateurs Inactifs</t>
                        <t t-else="">Analytics des Utilisateurs</t>
                    </h2>
                    <div t-if="state.rawData" class="text-sm text-gray-500">
                        Filtre: <span class="font-medium"><t t-esc="state.rawData.filter_label"/></span>
                    </div>
                </div>
                
                <!-- État de chargement -->
                <t t-if="state.loading">
                    <div class="flex justify-center items-center h-64">
                        <div class="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
                        <span class="ml-4 text-gray-600">Chargement des données...</span>
                    </div>
                </t>
                
                <!-- État d'erreur -->
                <t t-elif="state.error">
                    <div class="flex flex-col justify-center items-center h-64 text-red-600">
                        <svg class="w-16 h-16 mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L3.732 16c-.77.833.192 2.5 1.732 2.5z"/>
                        </svg>
                        <p class="text-lg font-medium">Impossible de charger le graphique</p>
                        <p class="text-sm mt-2"><t t-esc="state.error"/></p>
                    </div>
                </t>
                
                <!-- Graphique ou message vide -->
                <t t-else="">
                    <div t-if="state.chartData and state.chartData.values and state.chartData.values.length > 0">
                        <div t-ref="plotly-chart" class="w-full" style="min-height: 400px;"></div>
                    </div>
                    <div t-else="" class="flex flex-col justify-center items-center h-64 text-gray-500">
                        <svg class="w-16 h-16 mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 00-2-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"/>
                        </svg>
                        <p class="text-lg font-medium">Aucune donnée à afficher</p>
                        <p class="text-sm mt-2">Les données du graphique ne sont pas disponibles</p>
                    </div>
                </t>
            </div>
            
            <!-- Section Résumé -->
            <div t-if="state.rawData and state.rawData.analytics_summary" class="mt-8 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-lg p-6">
                <h3 class="text-lg font-semibold text-gray-900 mb-4">Résumé des Analytics</h3>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                    <div>
                        <span class="font-medium text-gray-700">Total des utilisateurs:</span>
                        <span class="ml-2 text-gray-900"><t t-esc="state.rawData.analytics_summary.total_all"/></span>
                    </div>
                    <div>
                        <span class="font-medium text-gray-700">Pourcentage actifs:</span>
                        <span class="ml-2 text-green-600 font-semibold"><t t-esc="state.rawData.analytics_summary.active_percentage"/>%</span>
                    </div>
                    <div>
                        <span class="font-medium text-gray-700">Utilisateurs inactifs:</span>
                        <span class="ml-2 text-red-600"><t t-esc="state.rawData.analytics_summary.inactive_users"/></span>
                    </div>
                    <div>
                        <span class="font-medium text-gray-700">Nouveaux utilisateurs (30j):</span>
                        <span class="ml-2 text-purple-600"><t t-esc="state.rawData.analytics_summary.new_users_percentage"/>%</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
`;

console.log("Enregistrement de l'action qc_dashboard.action_user_dashboard");
registry.category('actions').add('qc_dashboard.action_user_dashboard', UserKPIDashboard);