/** @odoo-module **/
import { registry } from "@web/core/registry";
import { useService } from "@web/core/utils/hooks";

const { Component } = owl;
const { useState, onMounted } = owl.hooks;

// Sous-composant KPI Card (PAS enregistré dans registry)
export class UserKPICard extends Component {
    setup() {
        this.state = useState({
            value: 0,
            loading: true,
            error: null
        });
        this.rpc = useService("rpc");
        
        onMounted(() => {
            this.loadKPIData();
        });
    }

    async loadKPIData() {
        try {
            this.state.loading = true;
            this.state.error = null;
            
            const result = await this.rpc({
                model: this.props.model || 'res.users',
                method: 'search_count',
                args: [this.props.domain || []],
            });
            
            this.state.value = result;
        } catch (error) {
            console.error("Erreur lors du chargement des données KPI:", error);
            this.state.error = "Erreur de chargement";
        } finally {
            this.state.loading = false;
        }
    }

    get colorClasses() {
        const colors = {
            blue: { border: 'border-blue-500', text: 'text-blue-600', bg: 'bg-blue-50' },
            green: { border: 'border-green-500', text: 'text-green-600', bg: 'bg-green-50' },
            red: { border: 'border-red-500', text: 'text-red-600', bg: 'bg-red-50' },
            purple: { border: 'border-purple-500', text: 'text-purple-600', bg: 'bg-purple-50' }
        };
        return colors[this.props.color] || colors.blue;
    }
}

// Template inline (comme votre approche actuelle)
UserKPICard.template = owl.tags.xml`
    <div t-att-class="'bg-white rounded-lg shadow p-6 border-l-4 hover:shadow-md transition-shadow ' + colorClasses.border">
        <div class="flex items-center justify-between">
            <div class="flex-1">
                <h3 class="text-lg font-medium text-gray-900 mb-2">
                    <t t-esc="props.title"/>
                </h3>
                
                <div t-if="state.loading" class="flex items-center">
                    <div class="animate-spin rounded-full h-6 w-6 border-b-2 border-blue-600"></div>
                    <span class="ml-2 text-gray-500 text-sm">Chargement...</span>
                </div>
                
                <div t-elif="state.error" class="text-red-500 text-sm">
                    <t t-esc="state.error"/>
                </div>
                
                <div t-else="">
                    <p t-att-class="'text-3xl font-bold ' + colorClasses.text">
                        <t t-esc="state.value"/>
                    </p>
                    <p class="text-sm text-gray-600 mt-1">
                        <t t-esc="props.description"/>
                    </p>
                </div>
            </div>
            
            <div t-att-class="'rounded-full p-3 ' + colorClasses.bg">
                <svg class="w-6 h-6" t-att-class="colorClasses.text" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197m13.5-9a2.5 2.5 0 11-5 0 2.5 2.5 0 015 0z"/>
                </svg>
            </div>
        </div>
    </div>
`;