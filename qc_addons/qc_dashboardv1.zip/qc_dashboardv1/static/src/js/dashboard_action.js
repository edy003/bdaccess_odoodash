/** @odoo-module **/

import { AbstractAction } from "@web/webclient/actions/abstract_action";
import { Component } from "@odoo/owl";
import { Dashboard } from "./dashboard_components";

// ====================================
// ACTION ODOO POUR LE DASHBOARD
// ====================================

export class DashboardAction extends AbstractAction {
    static template = "dashboard.DashboardAction";
    static components = { Dashboard };

    setup() {
        super.setup();
    }
}

// ====================================
// TEMPLATE POUR L'ACTION
// ====================================

DashboardAction.template = owl.tags.xml`
    <div class="h-100">
        <Dashboard />
    </div>
`;

// ====================================
// ENREGISTREMENT DE L'ACTION
// ====================================

import { registry } from "@web/core/registry";
const actionRegistry = registry.category("actions");
actionRegistry.add("dashboard_owl_action", DashboardAction);