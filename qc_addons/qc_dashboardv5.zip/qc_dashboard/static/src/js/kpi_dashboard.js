/** @odoo-module **/
import { registry } from "@web/core/registry";
import { useService } from "@web/core/utils/hooks";
//import { KpiCard } from "./kpi_card"; // Import correct du composant

const { Component } = owl;
const { useState, onMounted, useRef } = owl.hooks;

console.log("Chargement de kpi_dashboard.js");
console.log("Plotly disponible ?", typeof Plotly !== 'undefined');

export class UserKPIDashboard extends Component {
    // Définition des composants AVANT setup()
//    static components = { KpiCard };

    setup() {
        console.log("Initialisation du composant UserKPIDashboard");
        this.state = useState({
            kpiData: {
                title: "Nombre d'utilisateurs",
                value: 0,
                description: "Total des utilisateurs dans Odoo.",
            },
            chartData: null,
            loading: true,
            error: null,
            activeUsers: 0,
            newUsers: 0,
            currentFilter: 'all',
            rawData: null
        });
        this.rpc = useService("rpc");
        this.chartRef = useRef("plotly-chart");

        onMounted(() => {
            this.loadDashboardData();
        });
    }

    async loadDashboardData(filterType = 'all') {
        try {
            console.log("Chargement des données du dashboard avec filtre:", filterType);
            this.state.loading = true;
            this.state.error = null;

            const result = await this.rpc("/dashboard/user_analytics", {
                filter_type: filterType
            });

            console.log("Réponse du serveur:", result);

            if (result.error) {
                this.state.error = result.message;
                console.error("Erreur retournée par le serveur:", result.message);
                return;
            }

            let title = "Nombre d'utilisateurs";
            let description = "Total des utilisateurs dans Odoo.";

            if (filterType === 'active') {
                title = "Utilisateurs actifs";
                description = "Total des utilisateurs actifs dans Odoo.";
            } else if (filterType === 'inactive') {
                title = "Utilisateurs inactifs";
                description = "Total des utilisateurs inactifs dans Odoo.";
            }

            this.state.kpiData.title = title;
            this.state.kpiData.description = description;
            this.state.kpiData.value = result.total_users;
            this.state.activeUsers = result.active_users;
            this.state.newUsers = result.new_users;
            this.state.currentFilter = filterType;
            this.state.rawData = result;
            this.state.chartData = result.chart_data;

            console.log("Données du dashboard chargées:", result);
            console.log("État du composant mis à jour:", this.state);

            setTimeout(() => {
                this.renderChart();
            }, 100);

        } catch (error) {
            console.error("Erreur lors du chargement des données:", error);
            this.state.error = "Erreur lors du chargement des données: " + error.message;
        } finally {
            this.state.loading = false;
        }
    }

    async onFilterChange(event) {
        const filterValue = event.target.value;
        console.log("Changement de filtre vers:", filterValue);
        await this.loadDashboardData(filterValue);
    }

    renderChart() {
        if (!this.state.chartData || !this.chartRef.el) {
            console.warn("Données du graphique ou élément DOM manquants");
            return;
        }

        if (typeof Plotly === 'undefined') {
            console.warn("Plotly non disponible");
            this.state.error = "Plotly n'est pas chargé";
            return;
        }

        try {
            const data = [{
                x: this.state.chartData.labels,
                y: this.state.chartData.values,
                type: 'bar',
                marker: {
                    color: ['#3B82F6', '#EF4444', '#10B981', '#8B5CF6', '#F59E0B'],
                    opacity: 0.8
                },
                text: this.state.chartData.values.map(v => v.toString()),
                textposition: 'auto',
            }];

            let chartTitle = 'Analytics des Utilisateurs';
            if (this.state.currentFilter === 'active') {
                chartTitle = 'Analytics des Utilisateurs Actifs';
            } else if (this.state.currentFilter === 'inactive') {
                chartTitle = 'Analytics des Utilisateurs Inactifs';
            }

            const layout = {
                title: {
                    text: chartTitle,
                    font: { size: 18, color: '#1F2937' }
                },
                xaxis: {
                    title: 'Catégories',
                    tickangle: -45
                },
                yaxis: {
                    title: 'Nombre d\'utilisateurs'
                },
                plot_bgcolor: '#F9FAFB',
                paper_bgcolor: '#FFFFFF',
                margin: { t: 60, r: 30, b: 100, l: 60 },
                height: 400,
                responsive: true
            };

            const config = {
                displayModeBar: true,
                displaylogo: false,
                modeBarButtonsToRemove: ['pan2d', 'lasso2d', 'select2d']
            };

            Plotly.newPlot(this.chartRef.el, data, layout, config);
            console.log("Graphique Plotly rendu avec succès");

        } catch (error) {
            console.error("Erreur lors du rendu du graphique:", error);
            this.state.error = "Erreur lors du rendu du graphique: " + error.message;
        }
    }
}

// Assignation du template APRÈS la définition de la classe
UserKPIDashboard.template = "qc_dashboard.UserKPIDashboard";

console.log("Enregistrement de l'action qc_dashboard.action_user_dashboard");
registry.category('actions').add('qc_dashboard.action_user_dashboard', UserKPIDashboard);