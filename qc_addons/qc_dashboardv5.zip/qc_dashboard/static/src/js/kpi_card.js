/** @odoo-module **/

const { Component } = owl;

export class KpiCard extends Component {
    setup() {
        console.log("KpiCard component initialized with props:", this.props);
    }

    get formattedValue() {
        if (typeof this.props.value === 'number') {
            return this.props.value.toLocaleString();
        }
        return this.props.value || '0';
    }
}

KpiCard.template = "qc_dashboard.KPICard";
KpiCard.props = {
    title: { type: String },
    value: { type: [Number, String] },
    description: { type: String, optional: true },
    color: { type: String, optional: true },
    badge: { type: String, optional: true }
};