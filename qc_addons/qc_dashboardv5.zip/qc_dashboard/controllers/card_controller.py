# # -*- coding: utf-8 -*-
# from odoo import http
# from odoo.http import request
# import logging
# import pandas as pd
#
# _logger = logging.getLogger(__name__)
#
#
# class WorkProgramDashboardController(http.Controller):
#
#     @http.route('/dashboard/work_program_count', type='json', auth='public', methods=['POST'], csrf=False)
#     def get_work_program_count(self, year=None, month=None, week=None, department_id=None, responsible_id=None):
#         """
#         Récupère le nombre total de tâches avec filtres
#         Paramètres de filtrage:
#         - year: Année (ex: 2025) ou None pour toutes les années
#         - month: Mois en français (ex: 'janvier', 'février', etc.)
#         - week: Semaine au format YYYY-MM-DD (début de semaine)
#         - department_id: ID du département
#         - responsible_id: ID de l'employé responsable
#         """
#         try:
#             _logger.info(
#                 f"Début de get_work_program_count avec filtres: year={year}, month={month}, week={week}, dept={department_id}, resp={responsible_id}")
#
#             # ✅ CORRECTION: Ne plus forcer l'année courante si year=None
#             # Garde year=None pour récupérer toutes les années
#             if year is not None:
#                 _logger.info(f"Filtre sur l'année: {year}")
#             else:
#                 _logger.info("Aucun filtre année - récupération de toutes les années")
#
#             # Récupération de toutes les tâches
#             tasks = request.env['work.program'].sudo().search([])
#             _logger.info(f"Trouvé {len(tasks)} tâches au total")
#
#             if not tasks:
#                 return {'total_tasks': 0, 'error': False}
#
#             # Création d'un DataFrame pandas pour faciliter le traitement
#             task_data_list = []
#
#             for task in tasks:
#                 # Extraction de l'année depuis my_week_of (format: YYYY-MM-DD)
#                 task_year = None
#                 if task.my_week_of:
#                     try:
#                         task_year = int(task.my_week_of.split('-')[0])
#                     except:
#                         task_year = None
#
#                 task_data_list.append({
#                     'id': task.id,
#                     'year': task_year,
#                     'my_month': task.my_month,
#                     'my_week_of': task.my_week_of,
#                     'work_programm_department_id': task.work_programm_department_id.id if task.work_programm_department_id else None,
#                     'responsible_id': task.responsible_id.id if task.responsible_id else None,
#                 })
#
#             # Création du DataFrame
#             df = pd.DataFrame(task_data_list)
#
#             if df.empty:
#                 return {'total_tasks': 0, 'error': False}
#
#             # Application des filtres
#             filtered_df = self._apply_filters(df, year, month, week, department_id, responsible_id)
#
#             # Calcul du nombre total de tâches
#             total_tasks = len(filtered_df)
#
#             _logger.info(f"Nombre de tâches après filtres: {total_tasks}")
#
#             return {
#                 'total_tasks': total_tasks,
#                 'error': False
#             }
#
#         except Exception as e:
#             _logger.error(f"Erreur dans get_work_program_count: {str(e)}", exc_info=True)
#             return {
#                 'error': True,
#                 'message': str(e),
#                 'total_tasks': 0
#             }
#
#
#     @http.route('/dashboard/work_program_projects_count', type='json', auth='public', methods=['POST'], csrf=False)
#     def get_work_program_projects_count(self, year=None, month=None, week=None, department_id=None,
#                                         responsible_id=None):
#         """
#         Récupère le nombre distinct de projets avec les mêmes filtres
#         """
#         try:
#             _logger.info(
#                 f"Début de get_work_program_projects_count avec filtres: year={year}, month={month}, week={week}, dept={department_id}, resp={responsible_id}")
#
#             if year is not None:
#                 _logger.info(f"Filtre sur l'année: {year}")
#             else:
#                 _logger.info("Aucun filtre année - récupération de toutes les années")
#
#             # Récupération de toutes les tâches
#             tasks = request.env['work.program'].sudo().search([])
#             _logger.info(f"Trouvé {len(tasks)} tâches au total")
#
#             if not tasks:
#                 return {'total_projects': 0, 'error': False}
#
#             # Création d'un DataFrame pandas pour faciliter le traitement
#             task_data_list = []
#
#             for task in tasks:
#                 # Extraction de l'année depuis my_week_of (format: YYYY-MM-DD)
#                 task_year = None
#                 if task.my_week_of:
#                     try:
#                         task_year = int(task.my_week_of.split('-')[0])
#                     except:
#                         task_year = None
#
#                 task_data_list.append({
#                     'id': task.id,
#                     'year': task_year,
#                     'my_month': task.my_month,
#                     'my_week_of': task.my_week_of,
#                     'work_programm_department_id': task.work_programm_department_id.id if task.work_programm_department_id else None,
#                     'responsible_id': task.responsible_id.id if task.responsible_id else None,
#                     'project_id': task.project_id.id if task.project_id else None,
#                 })
#
#             # Création du DataFrame
#             df = pd.DataFrame(task_data_list)
#
#             if df.empty:
#                 return {'total_projects': 0, 'error': False}
#
#             # Application des filtres
#             filtered_df = self._apply_filters(df, year, month, week, department_id, responsible_id)
#
#             # Calcul du nombre distinct de projets
#             nb_projets = filtered_df['project_id'].nunique()
#
#             _logger.info(f"Nombre de projets distincts après filtres: {nb_projets}")
#
#             return {
#                 'total_projects': nb_projets,
#                 'error': False
#             }
#
#         except Exception as e:
#             _logger.error(f"Erreur dans get_work_program_projects_count: {str(e)}", exc_info=True)
#             return {
#                 'error': True,
#                 'message': str(e),
#                 'total_projects': 0
#             }
#
#     @http.route('/dashboard/work_program_total_reports', type='json', auth='public', methods=['POST'], csrf=False)
#     def get_work_program_total_reports(self, year=None, month=None, week=None, department_id=None,
#                                        responsible_id=None):
#         """
#         Récupère le nombre total de reports (nb_postpones) avec les mêmes filtres
#         """
#         try:
#             _logger.info(
#                 f"Début de get_work_program_total_reports avec filtres: year={year}, month={month}, week={week}, dept={department_id}, resp={responsible_id}")
#
#             # Récupération de toutes les tâches
#             tasks = request.env['work.program'].sudo().search([])
#             _logger.info(f"Trouvé {len(tasks)} tâches au total")
#
#             if not tasks:
#                 return {'total_reports': 0, 'error': False}
#
#             # Création d'un DataFrame pandas pour faciliter le traitement
#             task_data_list = []
#
#             for task in tasks:
#                 # Extraction de l'année depuis my_week_of (format: YYYY-MM-DD)
#                 task_year = None
#                 if task.my_week_of:
#                     try:
#                         task_year = int(task.my_week_of.split('-')[0])
#                     except:
#                         task_year = None
#
#                 task_data_list.append({
#                     'id': task.id,
#                     'year': task_year,
#                     'my_month': task.my_month,
#                     'my_week_of': task.my_week_of,
#                     'work_programm_department_id': task.work_programm_department_id.id if task.work_programm_department_id else None,
#                     'responsible_id': task.responsible_id.id if task.responsible_id else None,
#                     'nb_postpones': task.nb_postpones or 0,
#                 })
#
#             # Création du DataFrame
#             df = pd.DataFrame(task_data_list)
#
#             if df.empty:
#                 return {'total_reports': 0, 'error': False}
#
#             # Application des filtres
#             filtered_df = self._apply_filters(df, year, month, week, department_id, responsible_id)
#
#             # Calcul du nombre total de reports
#             total_reports = int(filtered_df['nb_postpones'].sum())
#
#             _logger.info(f"Nombre total de reports après filtres: {total_reports}")
#
#             return {
#                 'total_reports': total_reports,
#                 'error': False
#             }
#
#         except Exception as e:
#             _logger.error(f"Erreur dans get_work_program_total_reports: {str(e)}", exc_info=True)
#             return {
#                 'error': True,
#                 'message': str(e),
#                 'total_reports': 0
#             }
#
#     @http.route('/dashboard/work_program_completion_mean', type='json', auth='public', methods=['POST'], csrf=False)
#     def get_work_program_completion_mean(self, year=None, month=None, week=None, department_id=None,
#                                          responsible_id=None):
#         """
#         Récupère le pourcentage moyen de complétion des tâches avec les mêmes filtres
#         """
#         try:
#             _logger.info(
#                 f"Début de get_work_program_completion_mean avec filtres: year={year}, month={month}, week={week}, dept={department_id}, resp={responsible_id}")
#
#             # Récupération de toutes les tâches
#             tasks = request.env['work.program'].sudo().search([])
#             _logger.info(f"Trouvé {len(tasks)} tâches au total")
#
#             if not tasks:
#                 return {'completion_mean': 0, 'error': False}
#
#             # Création d'un DataFrame pandas pour faciliter le traitement
#             task_data_list = []
#
#             for task in tasks:
#                 # Extraction de l'année depuis my_week_of (format: YYYY-MM-DD)
#                 task_year = None
#                 if task.my_week_of:
#                     try:
#                         task_year = int(task.my_week_of.split('-')[0])
#                     except:
#                         task_year = None
#
#                 task_data_list.append({
#                     'id': task.id,
#                     'year': task_year,
#                     'my_month': task.my_month,
#                     'my_week_of': task.my_week_of,
#                     'work_programm_department_id': task.work_programm_department_id.id if task.work_programm_department_id else None,
#                     'responsible_id': task.responsible_id.id if task.responsible_id else None,
#                     'completion_percentage': task.completion_percentage or 0,
#                 })
#
#             # Création du DataFrame
#             df = pd.DataFrame(task_data_list)
#
#             if df.empty:
#                 return {'completion_mean': 0, 'error': False}
#
#             # Application des filtres
#             filtered_df = self._apply_filters(df, year, month, week, department_id, responsible_id)
#
#             # Calcul de la moyenne des pourcentages de complétion
#             completion_mean = round(float(filtered_df['completion_percentage'].mean() or 0), 2)
#
#             _logger.info(f"Pourcentage moyen de complétion après filtres: {completion_mean}%")
#
#             return {
#                 'completion_mean': completion_mean,
#                 'error': False
#             }
#
#         except Exception as e:
#             _logger.error(f"Erreur dans get_work_program_completion_mean: {str(e)}", exc_info=True)
#             return {
#                 'error': True,
#                 'message': str(e),
#                 'completion_mean': 0
#             }
#



# -*- coding: utf-8 -*-
from odoo import http
from odoo.http import request
import logging
import pandas as pd

_logger = logging.getLogger(__name__)


class WorkProgramDashboardController(http.Controller):

    @http.route('/dashboard/work_program_count', type='json', auth='public', methods=['POST'], csrf=False)
    def get_work_program_count(self, year=None, month=None, week=None, department_id=None, responsible_id=None):
        """
        Récupère le nombre total de tâches avec filtres
        Paramètres de filtrage:
        - year: Année (ex: 2025) ou None pour toutes les années
        - month: Mois en français (ex: 'janvier', 'février', etc.)
        - week: Semaine au format YYYY-MM-DD (début de semaine)
        - department_id: ID du département
        - responsible_id: ID de l'employé responsable
        """
        try:
            _logger.info(
                f"Début de get_work_program_count avec filtres: year={year}, month={month}, week={week}, dept={department_id}, resp={responsible_id}")

            # ✅ CORRECTION: Ne plus forcer l'année courante si year=None
            # Garde year=None pour récupérer toutes les années
            if year is not None:
                _logger.info(f"Filtre sur l'année: {year}")
            else:
                _logger.info("Aucun filtre année - récupération de toutes les années")

            # Récupération de toutes les tâches
            tasks = request.env['work.program'].sudo().search([])
            _logger.info(f"Trouvé {len(tasks)} tâches au total")

            if not tasks:
                return {'total_tasks': 0, 'error': False}

            # Création d'un DataFrame pandas pour faciliter le traitement
            task_data_list = []

            for task in tasks:
                # Extraction de l'année depuis my_week_of (format: YYYY-MM-DD)
                task_year = None
                if task.my_week_of:
                    try:
                        task_year = int(task.my_week_of.split('-')[0])
                    except:
                        task_year = None

                task_data_list.append({
                    'id': task.id,
                    'year': task_year,
                    'my_month': task.my_month,
                    'my_week_of': task.my_week_of,
                    'work_programm_department_id': task.work_programm_department_id.id if task.work_programm_department_id else None,
                    'responsible_id': task.responsible_id.id if task.responsible_id else None,
                })

            # Création du DataFrame
            df = pd.DataFrame(task_data_list)

            if df.empty:
                return {'total_tasks': 0, 'error': False}

            # Application des filtres
            filtered_df = self._apply_filters(df, year, month, week, department_id, responsible_id)

            # Calcul du nombre total de tâches
            total_tasks = len(filtered_df)

            _logger.info(f"Nombre de tâches après filtres: {total_tasks}")

            return {
                'total_tasks': total_tasks,
                'error': False
            }

        except Exception as e:
            _logger.error(f"Erreur dans get_work_program_count: {str(e)}", exc_info=True)
            return {
                'error': True,
                'message': str(e),
                'total_tasks': 0
            }


    @http.route('/dashboard/work_program_projects_count', type='json', auth='public', methods=['POST'], csrf=False)
    def get_work_program_projects_count(self, year=None, month=None, week=None, department_id=None,
                                        responsible_id=None):
        """
        Récupère le nombre distinct de projets avec les mêmes filtres
        """
        try:
            _logger.info(
                f"Début de get_work_program_projects_count avec filtres: year={year}, month={month}, week={week}, dept={department_id}, resp={responsible_id}")

            if year is not None:
                _logger.info(f"Filtre sur l'année: {year}")
            else:
                _logger.info("Aucun filtre année - récupération de toutes les années")

            # Récupération de toutes les tâches
            tasks = request.env['work.program'].sudo().search([])
            _logger.info(f"Trouvé {len(tasks)} tâches au total")

            if not tasks:
                return {'total_projects': 0, 'error': False}

            # Création d'un DataFrame pandas pour faciliter le traitement
            task_data_list = []

            for task in tasks:
                # Extraction de l'année depuis my_week_of (format: YYYY-MM-DD)
                task_year = None
                if task.my_week_of:
                    try:
                        task_year = int(task.my_week_of.split('-')[0])
                    except:
                        task_year = None

                task_data_list.append({
                    'id': task.id,
                    'year': task_year,
                    'my_month': task.my_month,
                    'my_week_of': task.my_week_of,
                    'work_programm_department_id': task.work_programm_department_id.id if task.work_programm_department_id else None,
                    'responsible_id': task.responsible_id.id if task.responsible_id else None,
                    'project_id': task.project_id.id if task.project_id else None,
                })

            # Création du DataFrame
            df = pd.DataFrame(task_data_list)

            if df.empty:
                return {'total_projects': 0, 'error': False}

            # Application des filtres
            filtered_df = self._apply_filters(df, year, month, week, department_id, responsible_id)

            # ✅ CORRECTION: Vérifier si le DataFrame filtré est vide
            if filtered_df.empty:
                _logger.info("Aucune tâche après filtres - retour de 0 projets")
                return {'total_projects': 0, 'error': False}

            # Calcul du nombre distinct de projets
            nb_projets = filtered_df['project_id'].nunique()

            _logger.info(f"Nombre de projets distincts après filtres: {nb_projets}")

            return {
                'total_projects': nb_projets,
                'error': False
            }

        except Exception as e:
            _logger.error(f"Erreur dans get_work_program_projects_count: {str(e)}", exc_info=True)
            return {
                'error': True,
                'message': str(e),
                'total_projects': 0
            }

    @http.route('/dashboard/work_program_total_reports', type='json', auth='public', methods=['POST'], csrf=False)
    def get_work_program_total_reports(self, year=None, month=None, week=None, department_id=None,
                                       responsible_id=None):
        """
        Récupère le nombre total de reports (nb_postpones) avec les mêmes filtres
        """
        try:
            _logger.info(
                f"Début de get_work_program_total_reports avec filtres: year={year}, month={month}, week={week}, dept={department_id}, resp={responsible_id}")

            # Récupération de toutes les tâches
            tasks = request.env['work.program'].sudo().search([])
            _logger.info(f"Trouvé {len(tasks)} tâches au total")

            if not tasks:
                return {'total_reports': 0, 'error': False}

            # Création d'un DataFrame pandas pour faciliter le traitement
            task_data_list = []

            for task in tasks:
                # Extraction de l'année depuis my_week_of (format: YYYY-MM-DD)
                task_year = None
                if task.my_week_of:
                    try:
                        task_year = int(task.my_week_of.split('-')[0])
                    except:
                        task_year = None

                task_data_list.append({
                    'id': task.id,
                    'year': task_year,
                    'my_month': task.my_month,
                    'my_week_of': task.my_week_of,
                    'work_programm_department_id': task.work_programm_department_id.id if task.work_programm_department_id else None,
                    'responsible_id': task.responsible_id.id if task.responsible_id else None,
                    'nb_postpones': task.nb_postpones or 0,
                })

            # Création du DataFrame
            df = pd.DataFrame(task_data_list)

            if df.empty:
                return {'total_reports': 0, 'error': False}

            # Application des filtres
            filtered_df = self._apply_filters(df, year, month, week, department_id, responsible_id)

            # ✅ CORRECTION: Vérifier si le DataFrame filtré est vide
            if filtered_df.empty:
                _logger.info("Aucune tâche après filtres - retour de 0 reports")
                return {'total_reports': 0, 'error': False}

            # Calcul du nombre total de reports
            total_reports = int(filtered_df['nb_postpones'].sum())

            _logger.info(f"Nombre total de reports après filtres: {total_reports}")

            return {
                'total_reports': total_reports,
                'error': False
            }

        except Exception as e:
            _logger.error(f"Erreur dans get_work_program_total_reports: {str(e)}", exc_info=True)
            return {
                'error': True,
                'message': str(e),
                'total_reports': 0
            }

    @http.route('/dashboard/work_program_completion_mean', type='json', auth='public', methods=['POST'], csrf=False)
    def get_work_program_completion_mean(self, year=None, month=None, week=None, department_id=None,
                                         responsible_id=None):
        """
        Récupère le pourcentage moyen de complétion des tâches avec les mêmes filtres
        """
        try:
            _logger.info(
                f"Début de get_work_program_completion_mean avec filtres: year={year}, month={month}, week={week}, dept={department_id}, resp={responsible_id}")

            # Récupération de toutes les tâches
            tasks = request.env['work.program'].sudo().search([])
            _logger.info(f"Trouvé {len(tasks)} tâches au total")

            if not tasks:
                return {'completion_mean': 0, 'error': False}

            # Création d'un DataFrame pandas pour faciliter le traitement
            task_data_list = []

            for task in tasks:
                # Extraction de l'année depuis my_week_of (format: YYYY-MM-DD)
                task_year = None
                if task.my_week_of:
                    try:
                        task_year = int(task.my_week_of.split('-')[0])
                    except:
                        task_year = None

                task_data_list.append({
                    'id': task.id,
                    'year': task_year,
                    'my_month': task.my_month,
                    'my_week_of': task.my_week_of,
                    'work_programm_department_id': task.work_programm_department_id.id if task.work_programm_department_id else None,
                    'responsible_id': task.responsible_id.id if task.responsible_id else None,
                    'completion_percentage': task.completion_percentage or 0,
                })

            # Création du DataFrame
            df = pd.DataFrame(task_data_list)

            if df.empty:
                return {'completion_mean': 0, 'error': False}

            # Application des filtres
            filtered_df = self._apply_filters(df, year, month, week, department_id, responsible_id)

            # ✅ CORRECTION PRINCIPALE: Vérifier si le DataFrame filtré est vide
            if filtered_df.empty:
                _logger.info("Aucune tâche après filtres - retour de 0% pour completion_mean")
                return {'completion_mean': 0, 'error': False}

            # Calcul de la moyenne des pourcentages de complétion
            completion_mean = round(float(filtered_df['completion_percentage'].mean() or 0), 2)

            _logger.info(f"Pourcentage moyen de complétion après filtres: {completion_mean}%")

            return {
                'completion_mean': completion_mean,
                'error': False
            }

        except Exception as e:
            _logger.error(f"Erreur dans get_work_program_completion_mean: {str(e)}", exc_info=True)
            return {
                'error': True,
                'message': str(e),
                'completion_mean': 0
            }

    @http.route('/dashboard/work_program_grid', type='json', auth='user', methods=['POST'], csrf=False)
    def get_work_program_grid(self, year=None, month=None, week=None, department_id=None, responsible_id=None):
        """
        Renvoie les données filtrées pour AG Grid, sans calcul.
        """
        try:
            tasks = request.env['work.program'].sudo().search([])
            task_data_list = []

            for task in tasks:
                task_year = None
                if task.my_week_of:
                    try:
                        task_year = int(task.my_week_of.split('-')[0])
                    except:
                        task_year = None

                task_data_list.append({
                    'id': task.id,
                    'year': task_year,
                    'month': task.my_month,
                    'week_of': task.my_week_of,
                    'department': task.work_programm_department_id.name if task.work_programm_department_id else None,
                    'responsible': task.responsible_id.name if task.responsible_id else None,
                })

            import pandas as pd
            df = pd.DataFrame(task_data_list)
            filtered_df = self._apply_filters(df, year, month, week, department_id, responsible_id)

            return {
                'data': filtered_df.to_dict('records'),
                'error': False
            }

        except Exception as e:
            _logger.error(f"Erreur dans get_work_program_grid: {str(e)}",
                          exc_info=True)  # ✅ Correction de la faute de frappe
            return {
                'data': [],
                'error': True,
                'message': str(e)
            }

    @http.route('/dashboard/work_program_tasks_by_date', type='json', auth='public', methods=['POST'], csrf=False)
    def get_work_program_tasks_by_date(self, year=None, month=None, week=None, department_id=None, responsible_id=None):
        """Récupère le nombre de tâches par date d'assignation pour le graphique line chart"""
        try:
            tasks = request.env['work.program'].sudo().search([])
            if not tasks:
                return {'chart_data': {'labels': [], 'values': []}, 'error': False}

            task_data_list = []
            for task in tasks:
                task_year = None
                if task.my_week_of:
                    try:
                        task_year = int(task.my_week_of.split('-')[0])
                    except:
                        task_year = None

                task_data_list.append({
                    'id': task.id,
                    'year': task_year,
                    'my_month': task.my_month,
                    'my_week_of': task.my_week_of,
                    'work_programm_department_id': task.work_programm_department_id.id if task.work_programm_department_id else None,
                    'responsible_id': task.responsible_id.id if task.responsible_id else None,
                    'assignment_date': task.my_week_of,
                })

            df = pd.DataFrame(task_data_list)
            if df.empty:
                return {'chart_data': {'labels': [], 'values': []}, 'error': False}

            filtered_df = self._apply_filters(df, year, month, week, department_id, responsible_id)
            if filtered_df.empty:
                return {'chart_data': {'labels': [], 'values': []}, 'error': False}

            filtered_df['assignment_date'] = pd.to_datetime(filtered_df['assignment_date'], errors='coerce')
            filtered_df = filtered_df.dropna(subset=['assignment_date'])

            if filtered_df.empty:
                return {'chart_data': {'labels': [], 'values': []}, 'error': False}

            tasks_per_day = filtered_df.groupby(filtered_df['assignment_date'].dt.date).size().reset_index()
            tasks_per_day.columns = ['date', 'count']
            tasks_per_day = tasks_per_day.sort_values('date')

            chart_data = {
                'labels': [date.strftime('%Y-%m-%d') for date in tasks_per_day['date']],
                'values': tasks_per_day['count'].tolist()
            }

            return {'chart_data': chart_data, 'error': False}

        except Exception as e:
            _logger.error(f"Erreur dans get_work_program_tasks_by_date: {str(e)}", exc_info=True)
            return {'error': True, 'message': str(e), 'chart_data': {'labels': [], 'values': []}}

    def _apply_filters(self, df, year, month, week, department_id, responsible_id):
        """Applique les filtres sur le DataFrame"""
        filtered_df = df.copy()

        try:
            # ✅ CORRECTION: Filtre par année seulement si year n'est pas None
            if year is not None:
                year = int(year)
                filtered_df = filtered_df[filtered_df['year'] == year]
                _logger.info(f"Filtre année {year}: {len(filtered_df)} tâches restantes")
            else:
                _logger.info(f"Pas de filtre année - {len(filtered_df)} tâches pour toutes les années")

            # Filtre par mois
            if month:
                filtered_df = filtered_df[filtered_df['my_month'] == month]
                _logger.info(f"Filtre mois {month}: {len(filtered_df)} tâches restantes")

            # Filtre par semaine
            if week:
                filtered_df = filtered_df[filtered_df['my_week_of'] == week]
                _logger.info(f"Filtre semaine {week}: {len(filtered_df)} tâches restantes")

            # Filtre par département
            if department_id:
                department_id = int(department_id)
                filtered_df = filtered_df[filtered_df['work_programm_department_id'] == department_id]
                _logger.info(f"Filtre département {department_id}: {len(filtered_df)} tâches restantes")

            # Filtre par responsable
            if responsible_id:
                responsible_id = int(responsible_id)
                filtered_df = filtered_df[filtered_df['responsible_id'] == responsible_id]
                _logger.info(f"Filtre responsable {responsible_id}: {len(filtered_df)} tâches restantes")

            return filtered_df

        except Exception as e:
            _logger.error(f"Erreur dans _apply_filters: {str(e)}")
            return df

