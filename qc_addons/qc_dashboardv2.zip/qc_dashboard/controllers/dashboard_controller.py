# -*- coding: utf-8 -*-
from odoo import http
from odoo.http import request
import json
from datetime import datetime, timedelta
import logging
import pandas as pd

_logger = logging.getLogger(__name__)

class DashboardController(http.Controller):
    
    @http.route('/dashboard/user_analytics', type='json', auth='user', methods=['POST'], csrf=False)
    def get_user_analytics(self, filter_type='all'):
        """
        Récupère et traite les données des utilisateurs avec pandas
        filter_type: 'all', 'active', 'inactive'
        """
        try:
            _logger.info(f"Début de get_user_analytics avec filtre: {filter_type}")
            
            # Récupération des données utilisateurs
            users = request.env['res.users'].sudo().search([])
            _logger.info(f"Trouvé {len(users)} utilisateurs")
            
            # Création d'un DataFrame pandas pour faciliter le traitement
            user_data_list = []
            now = datetime.now()
            thirty_days_ago = now - timedelta(days=30)
            
            for user in users:
                create_date = user.create_date
                if create_date:
                    # Conversion en datetime si nécessaire
                    if hasattr(create_date, 'replace'):
                        create_date = create_date.replace(tzinfo=None)
                
                is_new = create_date and create_date >= thirty_days_ago
                groups_count = len(user.groups_id)
                
                user_data_list.append({
                    'id': user.id,
                    'name': user.name,
                    'login': user.login,
                    'active': user.active,
                    'create_date': create_date,
                    'login_date': user.login_date,
                    'groups_count': groups_count,
                    'company_id': user.company_id.name if user.company_id else 'Aucune',
                    'is_new': is_new
                })
            
            # Création du DataFrame
            df = pd.DataFrame(user_data_list)
            
            if df.empty:
                return self._empty_result()
            
            # Application du filtre
            if filter_type == 'active':
                filtered_df = df[df['active'] == True]
                filter_label = "Actifs"
            elif filter_type == 'inactive':
                filtered_df = df[df['active'] == False]
                filter_label = "Inactifs"
            else:
                filtered_df = df
                filter_label = "Tous"
            
            # Calculs avec pandas
            total_all_users = len(df)
            total_filtered_users = len(filtered_df)
            active_users_count = len(df[df['active'] == True])
            inactive_users_count = len(df[df['active'] == False])
            new_users_count = len(df[df['is_new'] == True])
            users_with_groups = len(df[df['groups_count'] > 0])
            users_without_groups = len(df[df['groups_count'] == 0])
            recent_login_count = len(df[df['login_date'].notna()])
            
            # Statistiques avancées avec pandas
            stats = self._calculate_advanced_stats(df, filtered_df)
            
            # Préparation des données pour le graphique selon le filtre
            chart_data = self._prepare_chart_data(filtered_df, filter_type, {
                'active': len(filtered_df[filtered_df['active'] == True]) if not filtered_df.empty else 0,
                'inactive': len(filtered_df[filtered_df['active'] == False]) if not filtered_df.empty else 0,
                'new': len(filtered_df[filtered_df['is_new'] == True]) if not filtered_df.empty else 0,
                'with_groups': len(filtered_df[filtered_df['groups_count'] > 0]) if not filtered_df.empty else 0,
                'without_groups': len(filtered_df[filtered_df['groups_count'] == 0]) if not filtered_df.empty else 0
            })
            
            result = {
                'total_users': total_filtered_users,
                'active_users': len(filtered_df[filtered_df['active'] == True]) if not filtered_df.empty else 0,
                'new_users': len(filtered_df[filtered_df['is_new'] == True]) if not filtered_df.empty else 0,
                'chart_data': chart_data,
                'filter_applied': filter_type,
                'filter_label': filter_label,
                'analytics_summary': {
                    'total_all': total_all_users,
                    'active_users': active_users_count,
                    'inactive_users': inactive_users_count,
                    'users_with_recent_login': recent_login_count,
                    'active_percentage': round((active_users_count / total_all_users * 100), 2) if total_all_users > 0 else 0,
                    'new_users_percentage': round((new_users_count / total_all_users * 100), 2) if total_all_users > 0 else 0,
                    'average_groups_per_user': round(df['groups_count'].mean(), 2) if not df.empty else 0,
                    'median_groups_per_user': df['groups_count'].median() if not df.empty else 0,
                    **stats
                },
                'error': False
            }
            
            _logger.info(f"Analytics traité avec filtre '{filter_type}': {total_filtered_users}/{total_all_users} utilisateurs")
            return result
            
        except Exception as e:
            _logger.error(f"Erreur dans get_user_analytics: {str(e)}", exc_info=True)
            return {
                'error': True,
                'message': str(e),
                'total_users': 0,
                'active_users': 0,
                'new_users': 0,
                'chart_data': {'labels': [], 'values': []},
                'filter_applied': filter_type,
                'analytics_summary': {}
            }
    
    def _calculate_advanced_stats(self, df_all, df_filtered):
        """Calcule des statistiques avancées avec pandas"""
        try:
            if df_all.empty or df_filtered.empty:
                return {}
            
            # Analyse par période de création
            df_all['create_month'] = pd.to_datetime(df_all['create_date']).dt.to_period('M')
            monthly_creation = df_all.groupby('create_month').size().to_dict()
            
            # Analyse des groupes
            group_stats = {
                'users_with_multiple_groups': len(df_filtered[df_filtered['groups_count'] > 1]),
                'max_groups_per_user': int(df_filtered['groups_count'].max()) if not df_filtered.empty else 0,
                'users_with_no_groups': len(df_filtered[df_filtered['groups_count'] == 0])
            }
            
            # Analyse des connexions récentes (si login_date disponible)
            recent_logins = df_filtered[df_filtered['login_date'].notna()]
            if not recent_logins.empty:
                recent_logins['login_date_clean'] = pd.to_datetime(recent_logins['login_date'])
                last_30_days_logins = recent_logins[
                    recent_logins['login_date_clean'] >= (datetime.now() - timedelta(days=30))
                ]
                group_stats['recent_login_users'] = len(last_30_days_logins)
            else:
                group_stats['recent_login_users'] = 0
            
            return group_stats
            
        except Exception as e:
            _logger.error(f"Erreur dans _calculate_advanced_stats: {str(e)}")
            return {}
    
    def _prepare_chart_data(self, df, filter_type, counts):
        """Prépare les données du graphique selon le filtre appliqué"""
        try:
            if filter_type == 'active':
                # Graphique spécifique aux utilisateurs actifs
                labels = [
                    f"Nouveaux actifs (30j) ({counts['new']})",
                    f"Avec groupes ({counts['with_groups']})",
                    f"Sans groupes ({counts['without_groups']})",
                    f"Connexion récente ({len(df[df['login_date'].notna()]) if not df.empty else 0})"
                ]
                values = [
                    counts['new'],
                    counts['with_groups'], 
                    counts['without_groups'],
                    len(df[df['login_date'].notna()]) if not df.empty else 0
                ]
            
            elif filter_type == 'inactive':
                # Graphique spécifique aux utilisateurs inactifs
                labels = [
                    f"Inactifs récents (30j) ({counts['new']})",
                    f"Avec groupes ({counts['with_groups']})",
                    f"Sans groupes ({counts['without_groups']})",
                    f"Anciens comptes ({len(df) - counts['new'] if not df.empty else 0})"
                ]
                values = [
                    counts['new'],
                    counts['with_groups'],
                    counts['without_groups'],
                    len(df) - counts['new'] if not df.empty else 0
                ]
            
            else:
                # Graphique général (tous les utilisateurs)
                labels = [
                    f"Actifs ({counts['active']})",
                    f"Inactifs ({counts['inactive']})",
                    f"Nouveaux (30j) ({counts['new']})",
                    f"Avec groupes ({counts['with_groups']})",
                    f"Sans groupes ({counts['without_groups']})"
                ]
                values = [
                    counts['active'],
                    counts['inactive'],
                    counts['new'],
                    counts['with_groups'],
                    counts['without_groups']
                ]
            
            return {
                'labels': labels,
                'values': values
            }
            
        except Exception as e:
            _logger.error(f"Erreur dans _prepare_chart_data: {str(e)}")
            return {'labels': [], 'values': []}
    
    def _empty_result(self):
        """Retourne un résultat vide en cas d'absence de données"""
        return {
            'total_users': 0,
            'active_users': 0,
            'new_users': 0,
            'chart_data': {'labels': [], 'values': []},
            'analytics_summary': {},
            'error': False
        }