{
    'name': 'QC Dashboard',
    'version': '15.0.1.0.0',
    'category': 'Dashboard',
    'summary': 'Simple Dashboard with KPI Cards',
    'depends': ['base', 'web'],
    'data': [
        'views/dashboard_views.xml',
    ],
    'assets': {
        'web.assets_backend': [
            'qc_dashboard/static/src/css/dist/output.css',
            'qc_dashboard/static/src/js/dashboard.js',
            'qc_dashboard/static/src/xml/dashboard_template.xml',
        ],
    },
    'installable': True,
    'auto_install': False,
}