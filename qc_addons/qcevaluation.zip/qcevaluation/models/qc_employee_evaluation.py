from odoo import api, fields, models
from odoo.exceptions import ValidationError
import math
from dateutil.relativedelta import relativedelta
from datetime import datetime, timedelta

class EmployeeEvaluation(models.Model):
    _name = "employee.evaluation"
    _description = "Évaluation des employés"
    _order = "evaluation_start desc, employee_name"

    # name = fields.Char(string="Nom de l'évaluation", required=True)
    employee_id = fields.Many2one("hr.employee", string="Employé évalué", required=True, index=True,
    domain="[('parent_id.user_id', '=', uid)]")
    parent_id = fields.Many2one("hr.employee", string="Évaluateur", required=True, index=True,default=lambda self: self.env['hr.employee'].search([('user_id', '=', self.env.user.id)], limit=1),
    readonly=True)
    department_id = fields.Many2one("hr.department", string="Département", compute="_compute_employee_details", store=True)
    job_title = fields.Char(string="Poste", compute="_compute_employee_details", store=True)
    image_1920 = fields.Binary(string="Photo", compute="_compute_employee_details", store=True)
    evaluation_start = fields.Date(string="Date de début", required=True)
    evaluation_end = fields.Date(string="Date de fin", required=True)
    strengths = fields.Text(string="Points forts")
    improvement_areas = fields.Text(string="Axes d'amélioration")
    employee_name = fields.Char(string="Nom Employé", compute="_compute_employee_name", store=True)
    evaluator_name = fields.Char(string="Nom Évaluateur", compute="_compute_evaluator_name", store=True)
    niveau_performance = fields.Selection(
        [('a_risque', 'À risque'), ('satisfaisant', 'Satisfaisant'), ('performant', 'Performant'), ('haut_potentiel', 'Haut potentiel')],
        string="Niveau de performance", compute="_compute_niveau_performance", store=True, readonly=True
    )

    # Champs de evaluation.technical
    maitrise_outils = fields.Selection(
        selection=[('1', 'Insuffisant'), ('2', 'Acceptable'), ('3', 'Bon'), ('4', 'Très bon'), ('5', 'Excellent')],
        string="Maîtrise des outils, méthodologies et normes", required=True
    )
    maitrise_outils_comment = fields.Text(string="Commentaire maîtrise des outils")
    resoudre_problemes = fields.Selection(
        selection=[('1', 'Insuffisant'), ('2', 'Acceptable'), ('3', 'Bon'), ('4', 'Très bon'), ('5', 'Excellent')],
        string="Capacité à résoudre des problèmes techniques complexes", required=True
    )
    resoudre_problemes_comment = fields.Text(string="Commentaire résolution de problèmes")
    precision_rigueur = fields.Selection(
        selection=[('1', 'Insuffisant'), ('2', 'Acceptable'), ('3', 'Bon'), ('4', 'Très bon'), ('5', 'Excellent')],
        string="Précision, rigueur et respect des délais", required=True
    )
    precision_rigueur_comment = fields.Text(string="Commentaire précision et rigueur")
    qualite_travail = fields.Selection(
        selection=[('1', 'Insuffisant'), ('2', 'Acceptable'), ('3', 'Bon'), ('4', 'Très bon'), ('5', 'Excellent')],
        string="Capacité à produire un travail de haute qualité", required=True
    )
    qualite_travail_comment = fields.Text(string="Commentaire qualité du travail")
    participation_innovation = fields.Selection(
        selection=[('1', 'Insuffisant'), ('2', 'Acceptable'), ('3', 'Bon'), ('4', 'Très bon'), ('5', 'Excellent')],
        string="Participation active et esprit d'innovation", required=True
    )
    participation_innovation_comment = fields.Text(string="Commentaire participation et innovation")
    gestion_priorites = fields.Selection(
        selection=[('1', 'Insuffisant'), ('2', 'Acceptable'), ('3', 'Bon'), ('4', 'Très bon'), ('5', 'Excellent')],
        string="Gestion des priorités et contribution", required=True
    )
    gestion_priorites_comment = fields.Text(string="Commentaire gestion des priorités")
    evaluation_operationnelle = fields.Float(
        string="Score opérationnel", compute="_compute_evaluation_operationnelle", store=True
    )

    # Champs de evaluation.transversal
    autonomie_initiative = fields.Selection(
        selection=[('1', 'Insuffisant'), ('2', 'Acceptable'), ('3', 'Bon'), ('4', 'Très bon'), ('5', 'Excellent')],
        string="Autonomie et prise d’initiative", required=True
    )
    autonomie_initiative_comment = fields.Text(string="Commentaire autonomie et initiative")
    responsabilite_gestion = fields.Selection(
        selection=[('1', 'Insuffisant'), ('2', 'Acceptable'), ('3', 'Bon'), ('4', 'Très bon'), ('5', 'Excellent')],
        string="Responsabilité et gestion", required=True
    )
    responsabilite_gestion_comment = fields.Text(string="Commentaire responsabilité et gestion")
    communication = fields.Selection(
        selection=[('1', 'Insuffisant'), ('2', 'Acceptable'), ('3', 'Bon'), ('4', 'Très bon'), ('5', 'Excellent')],
        string="Communication", required=True
    )
    communication_comment = fields.Text(string="Commentaire communication")
    travail_equipe = fields.Selection(
        selection=[('1', 'Insuffisant'), ('2', 'Acceptable'), ('3', 'Bon'), ('4', 'Très bon'), ('5', 'Excellent')],
        string="Travail d’équipe", required=True
    )
    travail_equipe_comment = fields.Text(string="Commentaire travail d’équipe")
    bilinguisme = fields.Selection(
        selection=[('1', 'Insuffisant'), ('2', 'Acceptable'), ('3', 'Bon'), ('4', 'Très bon'), ('5', 'Excellent')],
        string="Bilinguisme", required=True
    )
    bilinguisme_comment = fields.Text(string="Commentaire bilinguisme")
    adaptabilite = fields.Selection(
        selection=[('1', 'Insuffisant'), ('2', 'Acceptable'), ('3', 'Bon'), ('4', 'Très bon'), ('5', 'Excellent')],
        string="Adaptabilité", required=True
    )
    adaptabilite_comment = fields.Text(string="Commentaire adaptabilité")
    conformite = fields.Selection(
        selection=[('1', 'Insuffisant'), ('2', 'Acceptable'), ('3', 'Bon'), ('4', 'Très bon'), ('5', 'Excellent')],
        string="Conformité", required=True
    )
    conformite_comment = fields.Text(string="Commentaire conformité")
    reporting = fields.Selection(
        selection=[('1', 'Insuffisant'), ('2', 'Acceptable'), ('3', 'Bon'), ('4', 'Très bon'), ('5', 'Excellent')],
        string="Reporting", required=True
    )
    reporting_comment = fields.Text(string="Commentaire reporting")
    competences_transversales_score = fields.Float(
        string="Score transversal", compute="_compute_competences_transversales_score", store=True
    )

    # Champs de evaluation.development
    curiosite_apprentissage = fields.Selection(
        selection=[('1', 'Insuffisant'), ('2', 'Acceptable'), ('3', 'Bon'), ('4', 'Très bon'), ('5', 'Excellent')],
        string="Curiosité et apprentissage", required=True
    )
    curiosite_apprentissage_comment = fields.Text(string="Commentaire curiosité et apprentissage")
    force_proposition_ia = fields.Selection(
        selection=[('1', 'Insuffisant'), ('2', 'Acceptable'), ('3', 'Bon'), ('4', 'Très bon'), ('5', 'Excellent')],
        string="Force de proposition et IA", required=True
    )
    force_proposition_ia_comment = fields.Text(string="Commentaire force de proposition et IA")
    engagement_developpement = fields.Selection(
        selection=[('1', 'Insuffisant'), ('2', 'Acceptable'), ('3', 'Bon'), ('4', 'Très bon'), ('5', 'Excellent')],
        string="Engagement dans le développement", required=True
    )
    engagement_developpement_comment = fields.Text(string="Commentaire engagement dans le développement")
    application_competences = fields.Selection(
        selection=[('1', 'Insuffisant'), ('2', 'Acceptable'), ('3', 'Bon'), ('4', 'Très bon'), ('5', 'Excellent')],
        string="Application des compétences", required=True
    )
    application_competences_comment = fields.Text(string="Commentaire application des compétences")
    recherche_proactive = fields.Selection(
        selection=[('1', 'Insuffisant'), ('2', 'Acceptable'), ('3', 'Bon'), ('4', 'Très bon'), ('5', 'Excellent')],
        string="Recherche proactive", required=True
    )
    recherche_proactive_comment = fields.Text(string="Commentaire recherche proactive")
    contribution_amelioration = fields.Selection(
        selection=[('1', 'Insuffisant'), ('2', 'Acceptable'), ('3', 'Bon'), ('4', 'Très bon'), ('5', 'Excellent')],
        string="Contribution à l’amélioration", required=True
    )
    contribution_amelioration_comment = fields.Text(string="Commentaire contribution à l’amélioration")
    evaluation_developpement = fields.Float(
        string="Score développement", compute="_compute_evaluation_developpement", store=True
    )

    evaluation_period = fields.Char(
        string="Période d'évaluation",
        compute="_compute_evaluation_period",
        store=True
    )


    @api.onchange('evaluation_start')
    def _onchange_evaluation_start(self):
        if self.evaluation_start:
            try:
                # Convertir en datetime si nécessaire
                start_date = self.evaluation_start
                if isinstance(start_date, str):
                    start_date = fields.Date.from_string(start_date)

                # Calculer le début du trimestre
                month = start_date.month
                quarter_start_month = ((month - 1) // 3) * 3 + 1
                start_of_quarter = start_date.replace(month=quarter_start_month, day=1)

                # Calculer la fin du trimestre
                end_of_quarter = start_of_quarter + relativedelta(months=3, days=-1)

                # Assigner les valeurs
                self.evaluation_start = start_of_quarter
                self.evaluation_end = end_of_quarter
            except Exception as e:
                self.evaluation_end = start_date + relativedelta(months=3, days=-1)
                return {
                    'warning': {
                        'title': 'Erreur de calcul des dates',
                        'message': f'Impossible de calculer les dates du trimestre. Une période de 3 mois a été appliquée : {str(e)}'
                    }
                }
        else:
            self.evaluation_end = False

    @api.model
    def create(self, vals):
        # S'assurer que evaluation_end est défini avant la création
        if 'evaluation_start' in vals and vals['evaluation_start'] and 'evaluation_end' not in vals or not vals.get('evaluation_end'):
            start_date = vals['evaluation_start']
            if isinstance(start_date, str):
                start_date = fields.Date.from_string(start_date)
            month = start_date.month
            quarter_start_month = ((month - 1) // 3) * 3 + 1
            start_of_quarter = start_date.replace(month=quarter_start_month, day=1)
            vals['evaluation_start'] = start_of_quarter
            vals['evaluation_end'] = start_of_quarter + relativedelta(months=3, days=-1)
        return super(EmployeeEvaluation, self).create(vals)

    def write(self, vals):
        # S'assurer que evaluation_end est défini avant la mise à jour
        if 'evaluation_start' in vals and vals['evaluation_start']:
            start_date = vals['evaluation_start']
            if isinstance(start_date, str):
                start_date = fields.Date.from_string(start_date)
            month = start_date.month
            quarter_start_month = ((month - 1) // 3) * 3 + 1
            start_of_quarter = start_date.replace(month=quarter_start_month, day=1)
            vals['evaluation_start'] = start_of_quarter
            vals['evaluation_end'] = start_of_quarter + relativedelta(months=3, days=-1)
        return super(EmployeeEvaluation, self).write(vals)

    @api.depends("evaluation_start")
    def _compute_evaluation_period(self):
        for rec in self:
            if rec.evaluation_start:
                # Déterminer le trimestre et l'année
                month = rec.evaluation_start.month
                year = rec.evaluation_start.year
                quarter = math.ceil(month / 3)  # Calcule le trimestre (1 à 4)
                rec.evaluation_period = f"Q{quarter} {year}"
            else:
                rec.evaluation_period = False


    @api.depends("employee_id")
    def _compute_employee_name(self):
        for rec in self:
            rec.employee_name = rec.employee_id.name_get()[0][1] if rec.employee_id else False

    @api.depends("parent_id")
    def _compute_evaluator_name(self):
        for rec in self:
            rec.evaluator_name = rec.parent_id.name_get()[0][1] if rec.parent_id else False

    @api.depends("employee_id")
    def _compute_employee_details(self):
        for rec in self:
            rec.department_id = rec.employee_id.department_id if rec.employee_id else False
            rec.job_title = rec.employee_id.job_id.name if rec.employee_id and rec.employee_id.job_id else False
            rec.image_1920 = rec.employee_id.image_1920 if rec.employee_id else False

    @api.onchange('employee_id')
    def _onchange_employee_id(self):
        if self.employee_id:
            # self.parent_id = self.employee_id.parent_id or False
            self.department_id = self.employee_id.department_id or False
            self.job_title = self.employee_id.job_id.name or False
            self.image_1920 = self.employee_id.image_1920 or False
        else:
            # self.parent_id = False
            self.department_id = False
            self.job_title = False
            self.image_1920 = False

    # @api.onchange('evaluation_start')
    # def _onchange_evaluation_start(self):
    #     if self.evaluation_start:
    #         try:
    #             start_of_quarter = fields.Date.start_of(self.evaluation_start, 'quarter')
    #             end_of_quarter = fields.Date.end_of(self.evaluation_start, 'quarter')
    #             self.evaluation_start = start_of_quarter
    #             self.evaluation_end = end_of_quarter
    #         except Exception as e:
    #             self.evaluation_end = False
    #             raise ValidationError(f"Erreur lors du calcul des dates : {str(e)}")
    #     else:
    #         self.evaluation_end = False

    @api.constrains("evaluation_start", "evaluation_end", "employee_id")
    def _check_dates(self):
        for rec in self:
            if rec.evaluation_start and rec.evaluation_end:
                # Vérification de la validité des dates
                if rec.evaluation_start > rec.evaluation_end:
                    raise ValidationError("La date de début doit précéder la date de fin.")
                if rec.evaluation_start > fields.Date.today():
                    raise ValidationError("La date de début ne peut pas être dans le futur.")
                expected_start = fields.Date.start_of(rec.evaluation_end, 'quarter')
                expected_end = fields.Date.end_of(rec.evaluation_start, 'quarter')
                if rec.evaluation_start != expected_start or rec.evaluation_end != expected_end:
                    raise ValidationError(
                        "La période doit correspondre à un trimestre complet (par exemple, 1er janvier au 31 mars)."
                    )
                # Vérification d'unicité pour l'employé et la période
                existing_evaluation = self.env['employee.evaluation'].search([
                    ('employee_id', '=', rec.employee_id.id),
                    ('evaluation_start', '=', rec.evaluation_start),
                    ('evaluation_end', '=', rec.evaluation_end),
                    ('id', '!=', rec.id),  # Exclure l'enregistrement actuel
                ])
                if existing_evaluation:
                    raise ValidationError(
                        f"Une évaluation existe déjà pour l'employé {rec.employee_id.name} pour la période du "
                        f"{rec.evaluation_start} au {rec.evaluation_end}."
                    )
                
    @api.depends(
        "maitrise_outils", "resoudre_problemes", "precision_rigueur",
        "qualite_travail", "participation_innovation", "gestion_priorites"
    )
    def _compute_evaluation_operationnelle(self):
        for rec in self:
            scores = [
                int(rec.maitrise_outils or 0),
                int(rec.resoudre_problemes or 0),
                int(rec.precision_rigueur or 0),
                int(rec.qualite_travail or 0),
                int(rec.participation_innovation or 0),
                int(rec.gestion_priorites or 0)
            ]
            rec.evaluation_operationnelle = sum(scores)

    @api.depends(
        "autonomie_initiative", "responsabilite_gestion", "communication",
        "travail_equipe", "bilinguisme", "adaptabilite",
        "conformite", "reporting"
    )
    def _compute_competences_transversales_score(self):
        for rec in self:
            scores = [
                int(rec.autonomie_initiative or 0),
                int(rec.responsabilite_gestion or 0),
                int(rec.communication or 0),
                int(rec.travail_equipe or 0),
                int(rec.bilinguisme or 0),
                int(rec.adaptabilite or 0),
                int(rec.conformite or 0),
                int(rec.reporting or 0)
            ]
            rec.competences_transversales_score = sum(scores)

    @api.depends(
        "curiosite_apprentissage", "force_proposition_ia", "engagement_developpement",
        "application_competences", "recherche_proactive", "contribution_amelioration"
    )
    def _compute_evaluation_developpement(self):
        for rec in self:
            scores = [
                int(rec.curiosite_apprentissage or 0),
                int(rec.force_proposition_ia or 0),
                int(rec.engagement_developpement or 0),
                int(rec.application_competences or 0),
                int(rec.recherche_proactive or 0),
                int(rec.contribution_amelioration or 0)
            ]
            rec.evaluation_developpement = sum(scores)

    @api.depends(
        "evaluation_operationnelle", "competences_transversales_score", "evaluation_developpement"
    )
    def _compute_niveau_performance(self):
        for rec in self:
            total = (rec.evaluation_operationnelle or 0) + \
                    (rec.competences_transversales_score or 0) + \
                    (rec.evaluation_developpement or 0)
            if total < 60:
                rec.niveau_performance = 'a_risque'
            elif 60 <= total <= 74:
                rec.niveau_performance = 'satisfaisant'
            elif 75 <= total <= 89:
                rec.niveau_performance = 'performant'
            else:
                rec.niveau_performance = 'haut_potentiel'