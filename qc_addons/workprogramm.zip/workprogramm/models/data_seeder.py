# -*- coding: utf-8 -*-
import logging
from datetime import datetime, timedelta
import random
from odoo import api, models

_logger = logging.getLogger(__name__)

class DataSeeder(models.Model):
    _name = 'data.seeder'
    _description = 'Générateur de données de test basé sur données existantes'

    @api.model
    def seed_all_test_data(self):
        """Point d'entrée principal"""
        _logger.info("=== DÉBUT GÉNÉRATION DONNÉES EXISTANTES ===")
        try:
            activities = self.create_workflow_structures()
            self.seed_work_programs_from_existing_data(activities)
            self.env.cr.commit()
            _logger.info("=== GÉNÉRATION TERMINÉE AVEC SUCCÈS ===")
            return {'status': 'success', 'message': 'Données générées avec succès'}
        except Exception as e:
            _logger.error(f"ERREUR GÉNÉRALE: {e}")
            self.env.cr.rollback()
            raise

    @api.model
    def create_workflow_structures(self):
        """Crée la structure workflow uniquement pour SUPPORT"""
        _logger.info("Création des structures workflow SUPPORT...")
        models_to_check = [
            'workflow.domain', 'workflow.process', 'workflow.subprocess',
            'workflow.activity', 'workflow.procedure', 'workflow.task.formulation',
            'workflow.deliverable'
        ]
        missing_models = [m for m in models_to_check if m not in self.env]
        if missing_models:
            _logger.warning(f"Modèles workflow manquants: {missing_models}")
            return {}

        workflows_config = {
            'SUPPORT': {
                'processes': [
                    {
                        'name': 'PR5. Capacity Management (Staffing)',
                        'sub_processes': [
                            {
                                'name': 'PR5.1: Establish contracts',
                                'activities': [
                                    {
                                        'name': 'PR5.1_A1: Estimate intervention time',
                                        'procedures': [
                                            'PR5.1_A1_P1: Time estimation and planning',
                                            'PR5.1_A1_P2: Resource plan validation'
                                        ],
                                        'deliverables': ['PR5.1_A1_L1: Resource plan'],
                                        'task_formulations': [
                                            'Estimate intervention time and prepare plan',
                                            'Validate the resource plan'
                                        ]
                                    }
                                ]
                            }
                        ]
                    }
                ]
            }
        }

        created_activities = {}
        for domain_name, workflow_data in workflows_config.items():
            Domain = self.env['workflow.domain']
            domain = Domain.search([('name', '=', domain_name)], limit=1)
            if not domain:
                domain = Domain.create({'name': domain_name, 'dpt_type': 'internal'})

            for process_data in workflow_data['processes']:
                Process = self.env['workflow.process']
                process = Process.search([('name', '=', process_data['name'])], limit=1)
                if not process:
                    process = Process.create({'name': process_data['name'], 'domain_id': domain.id})

                for subprocess_data in process_data['sub_processes']:
                    SubProcess = self.env['workflow.subprocess']
                    subprocess = SubProcess.search([('name', '=', subprocess_data['name'])], limit=1)
                    if not subprocess:
                        subprocess = SubProcess.create({'name': subprocess_data['name'], 'process_id': process.id})

                    for activity_data in subprocess_data['activities']:
                        Activity = self.env['workflow.activity']
                        activity = Activity.search([('name', '=', activity_data['name'])], limit=1)
                        if not activity:
                            activity = Activity.create({'name': activity_data['name'], 'sub_process_id': subprocess.id})
                            created_activities[activity.name] = activity

                        Procedure = self.env['workflow.procedure']
                        TaskForm = self.env['workflow.task.formulation']
                        Deliverable = self.env['workflow.deliverable']

                        for procedure_name in activity_data['procedures']:
                            procedure = Procedure.search([('name', '=', procedure_name)], limit=1)
                            if not procedure:
                                procedure = Procedure.create({'name': procedure_name, 'activity_id': activity.id})

                            for task_form in activity_data['task_formulations']:
                                if not TaskForm.search([('name', '=', task_form)], limit=1):
                                    TaskForm.create({'name': task_form, 'procedure_id': procedure.id})

                        for deliverable_name in activity_data['deliverables']:
                            if not Deliverable.search([('name', '=', deliverable_name)], limit=1):
                                Deliverable.create({'name': deliverable_name, 'activity_id': activity.id})

        return created_activities

    @api.model
    def seed_work_programs_from_existing_data(self, activities=None):
        """Génère des WorkPrograms pour tous les employés et projets existants"""
        _logger.info("=== DÉBUT GÉNÉRATION WORK.PROGRAMS (EXISTANTS) ===")

        WorkProgram = self.env['work.program']

        projects = list(self.env['project.project'].search([]))
        employees = list(self.env['hr.employee'].search([]))

        if not projects or not employees:
            _logger.warning("Projets ou employés inexistants, génération annulée")
            return

        base_date = datetime.now()
        activities_list = list(activities.values()) if activities else []

        for i, employee in enumerate(employees):
            department_name = employee.department_id.name if employee.department_id else 'GENERIC'
            project = projects[i % len(projects)]
            activity = activities_list[i % len(activities_list)] if activities_list else None
            assignment_date = base_date - timedelta(days=random.randint(5, 30))
            initial_deadline = assignment_date + timedelta(days=random.randint(7, 21))
            status = ['draft', 'ongoing', 'done', 'cancelled'][i % 4]
            nb_postpones = 0
            actual_deadline = initial_deadline
            if status in ['ongoing', 'done'] and random.random() < 0.4:
                nb_postpones = random.randint(1, 2)
                actual_deadline = initial_deadline + timedelta(days=nb_postpones * 5)
            completion_map = {'draft': 0.0, 'ongoing': 45.0, 'done': 100.0, 'cancelled': 25.0}

            program_data = {
                'name': f'{department_name}-Program-{i+1}-{project.name[:20]}',
                'week_of': 35 + i,
                'project_id': project.id,
                'priority': ['low', 'medium', 'high'][i % 3],
                'complexity': ['low', 'medium', 'high'][i % 3],
                'duration_effort': 8.0 + (i * 4),
                'status': status,
                'completion_percentage': completion_map[status],
                'assignment_date': assignment_date.date(),
                'initial_deadline': initial_deadline.date(),
                'actual_deadline': actual_deadline.date(),
                'nb_postpones': nb_postpones,
                'responsible_id': employee.id,
                'comments': f'Program for {department_name} - {project.name}',
            }

            if activity:
                program_data['activity_id'] = activity.id

            try:
                WorkProgram.create(program_data)
            except Exception as e:
                _logger.error(f"Erreur création WorkProgram {employee.name}: {e}")

        _logger.info("=== FIN GÉNÉRATION WORK.PROGRAMS ===")
