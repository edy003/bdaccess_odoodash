# -*- coding: utf-8 -*-
{
    'name': "QC Employee Evaluation",
    'summary': "Évaluation des employés par les managers",
    'description': """
        Module pour la gestion des évaluations des employés :
        - Les managers peuvent noter les employés
        - Ajout de commentaires et feedback
        - Intégration avec hr.employee
    """,
    'author': "Qualisys Consulting",
    'website': "http://www.qualisys-consulting.com",
    'category': 'Human Resources',
    'version': '1.0.0',
    'license': 'LGPL-3',

    # Dépendances
    'depends': ['base','hr'],

    # Données chargées au démarrage
    'data': [
        'views/evaluations.xml',
'security/employee_evaluation_security.xml',
        'security/ir.model.access.csv',


        # tu peux ajouter d'autres vues plus tard
    ],

    # Installation
    'installable': True,
    'application': True,
    'auto_install': False,
}
