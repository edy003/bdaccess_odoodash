/** @odoo-module **/
import { registry } from "@web/core/registry";
import { useService } from "@web/core/utils/hooks";

const { Component } = owl;
const { useState, onMounted, useRef } = owl.hooks;

console.log("Chargement de work_program_dashboard.js");

export class UserKPIDashboard extends Component {
    setup() {
        console.log("Initialisation du composant UserKPIDashboard principal");

        this.state = useState({
            // État de chargement global
            loading: false,
            error: null,

            // Filtres sélectionnés (partagés par tous les composants)
            selectedYear: new Date().getFullYear(),
            selectedMonth: null,
            selectedWeek: null,
            selectedDepartmentId: null,
            selectedResponsibleId: null,

            // Options pour les filtres
            availableYears: [],
            availableMonths: [],
            availableWeeks: [],
            availableDepartments: [],
            availableEmployees: [],

            // Filtres en cascade
            monthsForYear: [],
            weeksForMonth: [],
            employeesForDepartment: [],

            // Données des KPIs
            totalTasks: 0,
            totalProjects: 0,
            totalReports: 0,
            completionMean: 0,
            inProgressTasks: 0,

            // Données des graphiques
            chartData: {
                tasksByDate: { labels: [], values: [] },
                tasksByMonth: [],
                tasksByDepartment: []
            },

            // Données des tables
            tableData: []
        });

        this.rpc = useService("rpc");
        this.orm = useService("orm");
        this.chartRef = useRef("tasks-by-date-chart");
        this.gridRef = useRef("tasks-grid");

        // Stockage de l'instance AG Grid
        this.gridApi = null;
        this.gridColumnApi = null;
        this.gridInitialized = false; // AJOUT: Flag pour savoir si la grille est initialisée

        onMounted(async () => {
            await this.loadInitialData();
            // CORRECTION: Initialiser la grille après le chargement des données
            setTimeout(() => {
                this.initializeGrid();
            }, 100);
        });
    }

    // ===== MÉTHODES DE CHARGEMENT INITIAL =====
    async loadInitialData() {
        this.state.loading = true;
        try {
            console.log("Chargement des données initiales...");

            // Charger les options de base
            await Promise.all([
                this.loadAvailableYears(),
                this.loadDepartments(),
                this.loadEmployees()
            ]);

            // Charger les mois pour l'année courante
            await this.loadMonthsForYear(this.state.selectedYear);

            // Charger toutes les données
            await this.loadAllData();

        } catch (error) {
            console.error("Erreur lors du chargement initial:", error);
            this.state.error = error.message;
        } finally {
            this.state.loading = false;
        }
    }

    async loadAvailableYears() {
        try {
            const tasks = await this.orm.searchRead("work.program", [], ["my_week_of"]);
            const years = new Set();

            tasks.forEach(task => {
                if (task.my_week_of) {
                    const year = parseInt(task.my_week_of.split('-')[0]);
                    if (!isNaN(year)) {
                        years.add(year);
                    }
                }
            });

            this.state.availableYears = Array.from(years).sort((a, b) => b - a);
            console.log("Années disponibles:", this.state.availableYears);
        } catch (error) {
            console.error("Erreur lors du chargement des années:", error);
        }
    }

    async loadMonthsForYear(year) {
        if (!year) {
            try {
                const tasks = await this.orm.searchRead("work.program", [], ["my_month"]);
                const monthsSet = new Set();

                tasks.forEach(task => {
                    if (task.my_month) {
                        monthsSet.add(task.my_month);
                    }
                });

                this.state.monthsForYear = Array.from(monthsSet);
                console.log("Tous les mois disponibles:", this.state.monthsForYear);
            } catch (error) {
                console.error("Erreur lors du chargement de tous les mois:", error);
            }
            return;
        }

        try {
            const tasks = await this.orm.searchRead("work.program", [], ["my_week_of", "my_month"]);
            const monthsSet = new Set();

            tasks.forEach(task => {
                if (task.my_week_of && task.my_month) {
                    const taskYear = parseInt(task.my_week_of.split('-')[0]);
                    if (taskYear === year) {
                        monthsSet.add(task.my_month);
                    }
                }
            });

            this.state.monthsForYear = Array.from(monthsSet);
            console.log(`Mois disponibles pour ${year}:`, this.state.monthsForYear);
        } catch (error) {
            console.error("Erreur lors du chargement des mois:", error);
        }
    }

    async loadWeeksForMonth(year, month) {
        if (!month) {
            this.state.weeksForMonth = [];
            return;
        }

        if (!year) {
            try {
                const tasks = await this.orm.searchRead("work.program", [], ["my_week_of", "my_month"]);
                const weeksSet = new Set();

                tasks.forEach(task => {
                    if (task.my_week_of && task.my_month === month) {
                        weeksSet.add(task.my_week_of);
                    }
                });

                this.state.weeksForMonth = Array.from(weeksSet).sort();
                console.log(`Toutes les semaines disponibles pour ${month}:`, this.state.weeksForMonth);
            } catch (error) {
                console.error("Erreur lors du chargement de toutes les semaines:", error);
            }
            return;
        }

        try {
            const tasks = await this.orm.searchRead("work.program", [], ["my_week_of", "my_month"]);
            const weeksSet = new Set();

            tasks.forEach(task => {
                if (task.my_week_of && task.my_month) {
                    const taskYear = parseInt(task.my_week_of.split('-')[0]);
                    if (taskYear === year && task.my_month === month) {
                        weeksSet.add(task.my_week_of);
                    }
                }
            });

            this.state.weeksForMonth = Array.from(weeksSet).sort();
            console.log(`Semaines disponibles pour ${month} ${year}:`, this.state.weeksForMonth);
        } catch (error) {
            console.error("Erreur lors du chargement des semaines:", error);
        }
    }

    async loadDepartments() {
        try {
            const departments = await this.orm.searchRead("hr.department", [], ["name"]);
            this.state.availableDepartments = departments;
            this.state.employeesForDepartment = await this.orm.searchRead("hr.employee", [], ["name"]);
            console.log("Départements chargés:", departments.length);
        } catch (error) {
            console.error("Erreur lors du chargement des départements:", error);
        }
    }

    async loadEmployees() {
        try {
            const employees = await this.orm.searchRead("hr.employee", [], ["name"]);
            this.state.availableEmployees = employees;
            console.log("Employés chargés:", employees.length);
        } catch (error) {
            console.error("Erreur lors du chargement des employés:", error);
        }
    }

    async loadEmployeesForDepartment(departmentId) {
        if (!departmentId) {
            this.state.employeesForDepartment = this.state.availableEmployees;
            return;
        }

        try {
            const employees = await this.orm.searchRead("hr.employee",
                [["department_id", "=", departmentId]],
                ["name"]
            );
            this.state.employeesForDepartment = employees;
            console.log(`Employés pour département ${departmentId}:`, employees.length);
        } catch (error) {
            console.error("Erreur lors du chargement des employés par département:", error);
            this.state.employeesForDepartment = [];
        }
    }

    // ===== MÉTHODES DE CHARGEMENT DES DONNÉES =====
    async loadAllData() {
        console.log("Chargement de toutes les données...");

        const params = {
            year: this.state.selectedYear || null,
            month: this.state.selectedMonth,
            week: this.state.selectedWeek,
            department_id: this.state.selectedDepartmentId,
            responsible_id: this.state.selectedResponsibleId
        };

        console.log("Paramètres envoyés au serveur:", params);

        await Promise.all([
            this.loadKPIData(params),
            this.loadChartData(params),
            this.loadTableData(params)
        ]);

        // CORRECTION: Mettre à jour les composants après chargement des données
        setTimeout(() => {
            this.renderChart();
            if (this.gridInitialized) {
                this.updateGridData(); // CORRECTION: Nouvelle méthode pour mettre à jour les données uniquement
            }
        }, 200);
    }

    async loadKPIData(params) {
        try {
            console.log("Chargement des données KPI...");

            // KPI 1: Total des tâches
            const totalResult = await this.rpc("/dashboard/work_program_count", params);
            if (totalResult.error) {
                this.state.error = totalResult.message;
            } else {
                this.state.totalTasks = totalResult.total_tasks;
            }

            // KPI 2: Total des projets distincts
            const projectsResult = await this.rpc("/dashboard/work_program_projects_count", params);
            if (projectsResult.error) {
                this.state.error = projectsResult.message;
            } else {
                this.state.totalProjects = projectsResult.total_projects;
            }

            // KPI 3: Tâches reportées
            const reportsResult = await this.rpc("/dashboard/work_program_total_reports", params);
            if (reportsResult.error) {
                this.state.error = reportsResult.message;
            } else {
                this.state.totalReports = reportsResult.total_reports;
            }

            // KPI 4: Pourcentage de complétion moyen
            const completionResult = await this.rpc("/dashboard/work_program_completion_mean", params);
            if (completionResult.error) {
                this.state.error = completionResult.message;
            } else {
                this.state.completionMean = completionResult.completion_mean;
            }

            // KPI 5: Tâches en cours
            await this.loadInProgressTasks(params);

        } catch (error) {
            console.error("Erreur lors du chargement des KPIs:", error);
            this.state.error = "Erreur lors du chargement des KPIs: " + error.message;
        }
    }

    async loadInProgressTasks(params) {
        console.log("Chargement des tâches en cours - À implémenter");
        this.state.inProgressTasks = 0;
    }

    async loadChartData(params) {
        try {
            console.log("Chargement des données des graphiques...");
            await this.loadTasksByDate(params);
            await this.loadTasksByMonth(params);
            await this.loadTasksByDepartment(params);
        } catch (error) {
            console.error("Erreur lors du chargement des graphiques:", error);
        }
    }

    async loadTasksByDate(params) {
        try {
            console.log("Chargement du graphique tâches par date...");

            const result = await this.rpc("/dashboard/work_program_tasks_by_date", params);

            if (result.error) {
                console.error("Erreur lors du chargement des tâches par date:", result.message);
                this.state.chartData.tasksByDate = { labels: [], values: [] };
            } else {
                this.state.chartData.tasksByDate = result.chart_data;
                console.log("Données du graphique par date chargées:", result.chart_data);
            }
        } catch (error) {
            console.error("Erreur lors du chargement des tâches par date:", error);
            this.state.chartData.tasksByDate = { labels: [], values: [] };
        }
    }

    async loadTasksByMonth(params) {
        console.log("Chargement du graphique tâches par mois - À implémenter");
        this.state.chartData.tasksByMonth = [];
    }

    async loadTasksByDepartment(params) {
        console.log("Chargement du graphique tâches par département - À implémenter");
        this.state.chartData.tasksByDepartment = [];
    }

    async loadTableData(params) {
        try {
            console.log("Chargement des données du tableau...");

            const result = await this.rpc("/dashboard/work_program_grid", params);

            if (result.error) {
                console.error("Erreur lors du chargement du tableau:", result.message);
                this.state.tableData = [];
            } else {
                this.state.tableData = result.data;
                console.log("Données du tableau chargées:", result.data.length, "lignes");
            }
        } catch (error) {
            console.error("Erreur lors du chargement du tableau:", error);
            this.state.tableData = [];
        }
    }

    // ===== MÉTHODES DE RENDU =====
    renderChart() {
        console.log("Tentative de rendu du graphique...", {
            chartRef: this.chartRef.el,
            hasData: this.state.chartData.tasksByDate.labels.length > 0,
            data: this.state.chartData.tasksByDate
        });

        if (!this.chartRef.el) {
            console.warn("Élément DOM du graphique introuvable");
            return;
        }

        if (!this.state.chartData.tasksByDate.labels.length) {
            console.warn("Aucune donnée pour le graphique");
            this.chartRef.el.innerHTML = '<div class="text-center p-4 text-gray-500">Aucune donnée à afficher pour les filtres sélectionnés</div>';
            return;
        }

        if (typeof Plotly === 'undefined') {
            console.warn("Plotly non disponible");
            this.state.error = "Plotly n'est pas chargé. Assurez-vous que la librairie est incluse.";
            return;
        }

        try {
            const data = [{
                x: this.state.chartData.tasksByDate.labels,
                y: this.state.chartData.tasksByDate.values,
                type: 'scatter',
                mode: 'lines+markers',
                line: {
                    color: '#3B82F6',
                    width: 3
                },
                marker: {
                    color: '#1E40AF',
                    size: 8,
                    symbol: 'circle'
                },
                name: 'Nombre de tâches'
            }];

            const layout = {
                xaxis: {
                    title: 'Date d\'assignation',
                    tickangle: -45,
                    showgrid: false,
                    gridcolor: '#E5E7EB'
                },
                yaxis: {
                    title: 'Nombre de tâches',
                    showgrid: false,
                    gridcolor: '#E5E7EB'
                },
                plot_bgcolor: '#F9FAFB',
                paper_bgcolor: '#FFFFFF',
                margin: { t: 0, r: 0, b: 30, l: 0 },
                showlegend: false,
                responsive: true,
                hovermode: 'x unified'
            };

            const config = {
                displayModeBar: false,
                displaylogo: false,
                modeBarButtonsToRemove: ['pan2d', 'lasso2d', 'select2d', 'autoScale2d']
            };

            Plotly.newPlot(this.chartRef.el, data, layout, config);
            console.log("Graphique line chart rendu avec succès");

        } catch (error) {
            console.error("Erreur lors du rendu du graphique:", error);
            this.state.error = "Erreur lors du rendu du graphique: " + error.message;
        }
    }

    // CORRECTION MAJEURE : Initialisation unique de la grille
    initializeGrid() {
        console.log("Initialisation unique de la grille AG Grid...");

        if (!this.gridRef.el) {
            console.warn("Élément DOM de la table introuvable");
            return;
        }

        if (typeof agGrid === 'undefined') {
            console.error("AG Grid n'est pas chargé");
            this.gridRef.el.innerHTML = '<div class="text-center p-4 text-red-500">AG Grid n\'est pas disponible</div>';
            return;
        }

        try {
            // Vider le conteneur
            this.gridRef.el.innerHTML = '';

            // Configuration des colonnes
            const columnDefs = [
                {
                    field: "id",
                    headerName: "ID",
                    width: 80,
                    cellClass: 'text-center'
                },
                {
                    field: "year",
                    headerName: "Année",
                    width: 100,
                    cellClass: 'text-center'
                },
                {
                    field: "month",
                    headerName: "Mois",
                    width: 120,
                    filter: true
                },
                {
                    field: "week_of",
                    headerName: "Semaine",
                    width: 120,
                    cellClass: 'text-center'
                },
                {
                    field: "department",
                    headerName: "Département",
                    flex: 1,
                    filter: true
                },
                {
                    field: "responsible",
                    headerName: "Responsable",
                    flex: 1,
                    filter: true
                }
            ];

            // Configuration de la grille
            const gridOptions = {
                rowData: this.state.tableData, // Données initiales
                columnDefs: columnDefs,
                defaultColDef: {
                    sortable: true,
                    filter: 'agTextColumnFilter',
                    resizable: true,
                    minWidth: 80
                },
                animateRows: true,
                pagination: true,
                paginationPageSize: 25,
                rowSelection: 'multiple',
                suppressRowClickSelection: true,
                rowHeight: 45,
                headerHeight: 50,
                suppressCellFocus: true,
                onGridReady: (params) => {
                    console.log("AG Grid est prêt");
                    this.gridApi = params.api;
                    this.gridColumnApi = params.columnApi;
                    this.gridInitialized = true; // IMPORTANT: Marquer comme initialisé

                    setTimeout(() => {
                        if (this.gridApi) {
                            this.gridApi.sizeColumnsToFit();
                        }
                    }, 100);
                }
            };

            // Créer la grille
            this.gridInstance = agGrid.createGrid(this.gridRef.el, gridOptions);
            console.log("AG Grid créée avec succès");

        } catch (error) {
            console.error("Erreur lors de la création de la grille:", error);
            this.state.error = "Erreur lors de la création de la grille: " + error.message;
        }
    }

    // CORRECTION MAJEURE : Méthode dédiée uniquement à la mise à jour des données
    updateGridData() {
        console.log("Mise à jour des données de la grille...", {
            hasGridApi: !!this.gridApi,
            dataLength: this.state.tableData.length,
            initialized: this.gridInitialized
        });

        if (!this.gridApi || !this.gridInitialized) {
            console.warn("Grille non initialisée, impossible de mettre à jour les données");
            return;
        }

        try {
            // Mettre à jour uniquement les données
            this.gridApi.setGridOption('rowData', this.state.tableData);
            console.log(`✅ Données mises à jour: ${this.state.tableData.length} lignes`);

            // Auto-ajuster les colonnes après mise à jour
            setTimeout(() => {
                if (this.gridApi) {
                    this.gridApi.sizeColumnsToFit();
                }
            }, 100);

        } catch (error) {
            console.error("❌ Erreur lors de la mise à jour des données de la grille:", error);
            // En cas d'erreur critique, réinitialiser
            this.reinitializeGrid();
        }
    }

    // AJOUT: Méthode de réinitialisation en cas de problème
    reinitializeGrid() {
        console.log("Réinitialisation de la grille suite à une erreur...");
        this.destroyGrid();
        setTimeout(() => {
            this.initializeGrid();
        }, 100);
    }

    // ===== GESTIONNAIRES D'ÉVÉNEMENTS POUR LES FILTRES EN CASCADE =====
    async onYearChange(event) {
        const yearValue = event.target.value;
        const year = yearValue === "" ? null : parseInt(yearValue);
        console.log("Changement d'année vers:", year);

        this.state.selectedYear = year;
        this.state.selectedMonth = null;
        this.state.selectedWeek = null;

        await this.loadMonthsForYear(year);
        this.state.weeksForMonth = [];
    }

    async onMonthChange(event) {
        const month = event.target.value || null;
        console.log("Changement de mois vers:", month);

        this.state.selectedMonth = month;
        this.state.selectedWeek = null;

        if (month) {
            await this.loadWeeksForMonth(this.state.selectedYear, month);
        } else {
            this.state.weeksForMonth = [];
        }
    }

    onWeekChange(event) {
        const week = event.target.value || null;
        console.log("Changement de semaine vers:", week);
        this.state.selectedWeek = week;
    }

    async onDepartmentChange(event) {
        const deptId = parseInt(event.target.value) || null;
        console.log("Changement de département vers:", deptId);

        this.state.selectedDepartmentId = deptId;
        this.state.selectedResponsibleId = null;

        await this.loadEmployeesForDepartment(deptId);
    }

    onResponsibleChange(event) {
        const respId = parseInt(event.target.value) || null;
        console.log("Changement de responsable vers:", respId);
        this.state.selectedResponsibleId = respId;
    }

    // ===== ACTIONS DES BOUTONS =====
    async onApplyFilters() {
        console.log("🔄 Application des filtres...");
        this.state.loading = true;
        this.state.error = null;

        try {
            await this.loadAllData(); // Cette méthode met automatiquement à jour la grille
            console.log("✅ Filtres appliqués avec succès");
        } catch (error) {
            console.error("❌ Erreur lors de l'application des filtres:", error);
            this.state.error = error.message;
        } finally {
            this.state.loading = false;
        }
    }

    async onResetFilters() {
        console.log("🔄 Réinitialisation des filtres...");
        this.state.loading = true;

        try {
            // Réinitialiser les valeurs
            this.state.selectedYear = new Date().getFullYear();
            this.state.selectedMonth = null;
            this.state.selectedWeek = null;
            this.state.selectedDepartmentId = null;
            this.state.selectedResponsibleId = null;

            // Recharger les options en cascade
            await this.loadMonthsForYear(this.state.selectedYear);
            this.state.weeksForMonth = [];
            this.state.employeesForDepartment = this.state.availableEmployees;

            // Recharger toutes les données avec les filtres par défaut
            await this.loadAllData();
            console.log("✅ Filtres réinitialisés avec succès");

        } catch (error) {
            console.error("❌ Erreur lors de la réinitialisation:", error);
            this.state.error = error.message;
        } finally {
            this.state.loading = false;
        }
    }

    // ===== MÉTHODES UTILITAIRES =====
    // Méthode pour détruire proprement la grille (si nécessaire)
    destroyGrid() {
        console.log("🗑️ Destruction de la grille...");

        if (this.gridInstance && typeof this.gridInstance.destroy === 'function') {
            this.gridInstance.destroy();
        }

        this.gridInstance = null;
        this.gridApi = null;
        this.gridColumnApi = null;
        this.gridInitialized = false;

        console.log("✅ Grille détruite");
    }

    // AJOUT: Méthode de debug pour vérifier l'état
    debugGridState() {
        console.log("🔍 État de la grille:", {
            gridInitialized: this.gridInitialized,
            hasGridApi: !!this.gridApi,
            hasGridElement: !!this.gridRef.el,
            dataLength: this.state.tableData.length,
            currentFilters: {
                year: this.state.selectedYear,
                month: this.state.selectedMonth,
                week: this.state.selectedWeek,
                department: this.state.selectedDepartmentId,
                responsible: this.state.selectedResponsibleId
            }
        });
    }
}

// Template du composant
UserKPIDashboard.template = "qc_dashboard.UserKPIDashboard";

console.log("Enregistrement de l'action qc_dashboard.action_user_dashboard");
registry.category('actions').add('qc_dashboard.action_user_dashboard', UserKPIDashboard);