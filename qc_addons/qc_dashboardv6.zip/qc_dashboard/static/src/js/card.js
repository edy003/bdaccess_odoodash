/** @odoo-module **/
import { registry } from "@web/core/registry";
import { useService } from "@web/core/utils/hooks";

const { Component } = owl;
const { useState, onMounted, useRef } = owl.hooks;

console.log("Chargement de work_program_dashboard.js");

export class KpiCard extends Component {
    setup() {
        console.log("Initialisation du composant WorkProgramDashboard");

        this.state = useState({
            // Données principales
            totalTasks: 0,
            loading: false,
            error: null,

            // Filtres sélectionnés
            selectedYear: new Date().getFullYear(),
            selectedMonth: null,
            selectedWeek: null,
            selectedDepartmentId: null,
            selectedResponsibleId: null,

            // Options pour les filtres
            availableYears: [],
            availableMonths: [],
            availableWeeks: [],
            availableDepartments: [],
            availableEmployees: [],

            // Filtres en cascade
            monthsForYear: [],
            weeksForMonth: [],
            employeesForDepartment: []
        });

        this.rpc = useService("rpc");
        this.orm = useService("orm");

        onMounted(async () => {
            await this.loadInitialData();
        });
    }

    async loadInitialData() {
        this.state.loading = true;
        try {
            console.log("Chargement des données initiales...");

            // Charger les options de base
            await Promise.all([
                this.loadAvailableYears(),
                this.loadDepartments(),
                this.loadEmployees()
            ]);

            // Charger les mois pour l'année courante
            await this.loadMonthsForYear(this.state.selectedYear);

            // Charger le nombre de tâches initial (année courante)
            await this.loadTaskCount();

        } catch (error) {
            console.error("Erreur lors du chargement initial:", error);
            this.state.error = error.message;
        } finally {
            this.state.loading = false;
        }
    }

    async loadAvailableYears() {
        try {
            // Récupérer toutes les tâches pour extraire les années disponibles
            const tasks = await this.orm.searchRead("work.program", [], ["my_week_of"]);
            const years = new Set();

            tasks.forEach(task => {
                if (task.my_week_of) {
                    const year = parseInt(task.my_week_of.split('-')[0]);
                    if (!isNaN(year)) {
                        years.add(year);
                    }
                }
            });

            this.state.availableYears = Array.from(years).sort((a, b) => b - a); // Tri décroissant
            console.log("Années disponibles:", this.state.availableYears);
        } catch (error) {
            console.error("Erreur lors du chargement des années:", error);
        }
    }

    async loadMonthsForYear(year) {
        if (!year) return;

        try {
            const tasks = await this.orm.searchRead("work.program", [], ["my_week_of", "my_month"]);
            const monthsSet = new Set();

            tasks.forEach(task => {
                if (task.my_week_of && task.my_month) {
                    const taskYear = parseInt(task.my_week_of.split('-')[0]);
                    if (taskYear === year) {
                        monthsSet.add(task.my_month);
                    }
                }
            });

            this.state.monthsForYear = Array.from(monthsSet);
            console.log(`Mois disponibles pour ${year}:`, this.state.monthsForYear);
        } catch (error) {
            console.error("Erreur lors du chargement des mois:", error);
        }
    }

    async loadWeeksForMonth(year, month) {
        if (!year || !month) return;

        try {
            const tasks = await this.orm.searchRead("work.program", [], ["my_week_of", "my_month"]);
            const weeksSet = new Set();

            tasks.forEach(task => {
                if (task.my_week_of && task.my_month) {
                    const taskYear = parseInt(task.my_week_of.split('-')[0]);
                    if (taskYear === year && task.my_month === month) {
                        weeksSet.add(task.my_week_of);
                    }
                }
            });

            this.state.weeksForMonth = Array.from(weeksSet).sort();
            console.log(`Semaines disponibles pour ${month} ${year}:`, this.state.weeksForMonth);
        } catch (error) {
            console.error("Erreur lors du chargement des semaines:", error);
        }
    }

    async loadDepartments() {
        try {
            const departments = await this.orm.searchRead("hr.department", [], ["name"]);
            this.state.availableDepartments = departments;
            this.state.employeesForDepartment = await this.orm.searchRead("hr.employee", [], ["name"]);
            console.log("Départements chargés:", departments.length);
        } catch (error) {
            console.error("Erreur lors du chargement des départements:", error);
        }
    }

    async loadEmployees() {
        try {
            const employees = await this.orm.searchRead("hr.employee", [], ["name"]);
            this.state.availableEmployees = employees;
            console.log("Employés chargés:", employees.length);
        } catch (error) {
            console.error("Erreur lors du chargement des employés:", error);
        }
    }

    async loadEmployeesForDepartment(departmentId) {
        if (!departmentId) {
            this.state.employeesForDepartment = this.state.availableEmployees;
            return;
        }

        try {
            const employees = await this.orm.searchRead("hr.employee",
                [["department_id", "=", departmentId]],
                ["name"]
            );
            this.state.employeesForDepartment = employees;
            console.log(`Employés pour département ${departmentId}:`, employees.length);
        } catch (error) {
            console.error("Erreur lors du chargement des employés par département:", error);
            this.state.employeesForDepartment = [];
        }
    }

    async loadTaskCount() {
        this.state.loading = true;
        try {
            console.log("Chargement du nombre de tâches...");

            const params = {
                year: this.state.selectedYear,
                month: this.state.selectedMonth,
                week: this.state.selectedWeek,
                department_id: this.state.selectedDepartmentId,
                responsible_id: this.state.selectedResponsibleId
            };

            console.log("Paramètres envoyés:", params);

            const result = await this.rpc("/dashboard/work_program_count", params);
            console.log("Réponse du serveur:", result);

            if (result.error) {
                this.state.error = result.message;
                console.error("Erreur retournée par le serveur:", result.message);
            } else {
                this.state.totalTasks = result.total_tasks;
                this.state.error = null;
                console.log("Nombre de tâches chargé:", result.total_tasks);
            }

        } catch (error) {
            console.error("Erreur lors du chargement du nombre de tâches:", error);
            this.state.error = "Erreur lors du chargement des données: " + error.message;
        } finally {
            this.state.loading = false;
        }
    }

    // Gestionnaires d'événements pour les filtres en cascade
    async onYearChange(event) {
        const year = parseInt(event.target.value) || null;
        console.log("Changement d'année vers:", year);

        this.state.selectedYear = year;
        this.state.selectedMonth = null;
        this.state.selectedWeek = null;

        if (year) {
            await this.loadMonthsForYear(year);
        } else {
            this.state.monthsForYear = [];
        }
        this.state.weeksForMonth = [];
    }

    async onMonthChange(event) {
        const month = event.target.value || null;
        console.log("Changement de mois vers:", month);

        this.state.selectedMonth = month;
        this.state.selectedWeek = null;

        if (month && this.state.selectedYear) {
            await this.loadWeeksForMonth(this.state.selectedYear, month);
        } else {
            this.state.weeksForMonth = [];
        }
    }

    onWeekChange(event) {
        const week = event.target.value || null;
        console.log("Changement de semaine vers:", week);
        this.state.selectedWeek = week;
    }

    async onDepartmentChange(event) {
        const deptId = parseInt(event.target.value) || null;
        console.log("Changement de département vers:", deptId);

        this.state.selectedDepartmentId = deptId;
        this.state.selectedResponsibleId = null;

        await this.loadEmployeesForDepartment(deptId);
    }

    onResponsibleChange(event) {
        const respId = parseInt(event.target.value) || null;
        console.log("Changement de responsable vers:", respId);
        this.state.selectedResponsibleId = respId;
    }

    // Actions des boutons
    async onApplyFilters() {
        console.log("Application des filtres...");
        await this.loadTaskCount();
    }

    async onResetFilters() {
        console.log("Réinitialisation des filtres...");

        this.state.selectedYear = new Date().getFullYear();
        this.state.selectedMonth = null;
        this.state.selectedWeek = null;
        this.state.selectedDepartmentId = null;
        this.state.selectedResponsibleId = null;

        // Recharger les données
        await this.loadMonthsForYear(this.state.selectedYear);
        this.state.weeksForMonth = [];
        this.state.employeesForDepartment = this.state.availableEmployees;

        await this.loadTaskCount();
    }
}

