/** @odoo-module **/
import { registry } from "@web/core/registry";
import { useService } from "@web/core/utils/hooks";

const { Component } = owl;
const { useState, onMounted, useRef } = owl.hooks;

console.log("Chargement de kpi_dashboard.js");
console.log("Plotly disponible ?", typeof Plotly !== 'undefined');

export class UserKPIDashboard extends Component {
    setup() {
        console.log("Initialisation du composant UserKPIDashboard");
        this.state = useState({
            kpiData: {
                title: "Nombre d'utilisateurs",
                value: 0,
                description: "Total des utilisateurs dans Odoo.",
            },
            chartData: null,
            loading: true,
            error: null,
            activeUsers: 0,
            newUsers: 0,
            currentFilter: 'all', // Ajout du filtre
            rawData: null // Ajout pour stocker toutes les données
        });
        this.rpc = useService("rpc");
        this.chartRef = useRef("plotly-chart");
        
        onMounted(() => {
            this.loadDashboardData();
        });
    }
    
    async loadDashboardData() {
        try {
            console.log("Chargement des données du dashboard");
            this.state.loading = true;
            this.state.error = null;
            
            // Appel au contrôleur Python avec le filtre
            const result = await this.rpc("/dashboard/user_analytics", {
                filter: this.state.currentFilter
            });
            
            console.log("Réponse du serveur:", result);
            
            if (result.error) {
                this.state.error = result.message;
                console.error("Erreur retournée par le serveur:", result.message);
                return;
            }
            
            // Mise à jour du titre selon le filtre
            this.updateKPITitle();
            
            // Mise à jour des données KPI
            this.state.kpiData.value = result.total_users;
            this.state.activeUsers = result.active_users;
            this.state.newUsers = result.new_users;
            
            // Mise à jour des données du graphique
            this.state.chartData = result.chart_data;
            this.state.rawData = result; // Stocker toutes les données
            
            console.log("Données du dashboard chargées:", result);
            console.log("État du composant mis à jour:", this.state);
            
            // Petit délai pour s'assurer que le DOM est prêt
            setTimeout(() => {
                this.renderChart();
            }, 100);
            
        } catch (error) {
            console.error("Erreur lors du chargement des données:", error);
            this.state.error = "Erreur lors du chargement des données: " + error.message;
        } finally {
            this.state.loading = false;
        }
    }
    
    // Nouvelle méthode pour mettre à jour le titre selon le filtre
    updateKPITitle() {
        switch (this.state.currentFilter) {
            case 'active':
                this.state.kpiData.title = "Utilisateurs Actifs";
                this.state.kpiData.description = "Utilisateurs avec statut actif dans Odoo.";
                break;
            case 'inactive':
                this.state.kpiData.title = "Utilisateurs Inactifs";
                this.state.kpiData.description = "Utilisateurs avec statut inactif dans Odoo.";
                break;
            default:
                this.state.kpiData.title = "Nombre d'utilisateurs";
                this.state.kpiData.description = "Total des utilisateurs dans Odoo.";
        }
    }
    
    // Nouvelle méthode pour gérer le changement de filtre
    async onFilterChange(event) {
        const newFilter = event.target.value;
        console.log("Changement de filtre vers:", newFilter);
        
        if (newFilter !== this.state.currentFilter) {
            this.state.currentFilter = newFilter;
            await this.loadDashboardData();
        }
    }
    
    renderChart() {
        if (!this.state.chartData || !this.chartRef.el) {
            console.warn("Données du graphique ou élément DOM manquants");
            return;
        }
        
        if (typeof Plotly === 'undefined') {
            console.warn("Plotly non disponible");
            this.state.error = "Plotly n'est pas chargé";
            return;
        }
        
        try {
            const data = [{
                x: this.state.chartData.labels,
                y: this.state.chartData.values,
                type: 'bar',
                marker: {
                    color: ['#3B82F6', '#EF4444', '#10B981', '#8B5CF6', '#F59E0B'],
                    opacity: 0.8
                },
                text: this.state.chartData.values.map(v => v.toString()),
                textposition: 'auto',
            }];
            
            const layout = {
                title: {
                    text: this.getChartTitle(),
                    font: { size: 18, color: '#1F2937' }
                },
                xaxis: {
                    title: 'Catégories',
                    tickangle: -45
                },
                yaxis: {
                    title: 'Nombre d\'utilisateurs'
                },
                plot_bgcolor: '#F9FAFB',
                paper_bgcolor: '#FFFFFF',
                margin: { t: 60, r: 30, b: 100, l: 60 },
                height: 400,
                responsive: true
            };
            
            const config = {
                displayModeBar: true,
                displaylogo: false,
                modeBarButtonsToRemove: ['pan2d', 'lasso2d', 'select2d']
            };
            
            Plotly.newPlot(this.chartRef.el, data, layout, config);
            console.log("Graphique Plotly rendu avec succès");
            
        } catch (error) {
            console.error("Erreur lors du rendu du graphique:", error);
            this.state.error = "Erreur lors du rendu du graphique: " + error.message;
        }
    }
    
    // Nouvelle méthode pour le titre du graphique
    getChartTitle() {
        switch (this.state.currentFilter) {
            case 'active':
                return 'Analytics des Utilisateurs Actifs';
            case 'inactive':
                return 'Analytics des Utilisateurs Inactifs';
            default:
                return 'Analytics des Utilisateurs';
        }
    }
}

// Template avec design full-screen et scrollable
UserKPIDashboard.template = owl.tags.xml`
    <div class="o_content h-100" style="background-color: #f8f9fa; overflow-y: auto;">
        <div class="container-fluid py-4">
            <!-- Header avec titre et filtres -->
            <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap">
                <h1 class="h2 text-dark mb-0">Dashboard Utilisateurs</h1>
                
                <!-- Dropdown de filtrage -->
                <div class="d-flex align-items-center">
                    <label class="form-label mb-0 me-2 text-muted">Filtrer par statut:</label>
                    <select 
                        class="form-select form-select-sm"
                        style="min-width: 200px;"
                        t-on-change="onFilterChange"
                        t-att-value="state.currentFilter"
                    >
                        <option value="all">Tous les utilisateurs</option>
                        <option value="active">Utilisateurs actifs uniquement</option>
                        <option value="inactive">Utilisateurs inactifs uniquement</option>
                    </select>
                </div>
            </div>
            
            <!-- Message d'erreur -->
            <div t-if="state.error" class="alert alert-danger mb-4">
                <strong>Erreur:</strong> <t t-esc="state.error"/>
            </div>
            
            <!-- Indicateur de filtre actif -->
            <div t-if="state.currentFilter !== 'all'" class="alert alert-info mb-4 d-flex align-items-center">
                <i class="fa fa-filter me-2"></i>
                <span>
                    Filtre actif: 
                    <span t-if="state.currentFilter === 'active'" class="fw-bold">Utilisateurs actifs seulement</span>
                    <span t-if="state.currentFilter === 'inactive'" class="fw-bold">Utilisateurs inactifs seulement</span>
                </span>
            </div>
            
            <!-- Section KPI -->
            <div class="row mb-4">
                <div class="col-md-4 mb-3">
                    <div class="card shadow-sm h-100">
                        <div class="card-body">
                            <h5 class="card-title text-muted mb-2">
                                <t t-esc="state.kpiData.title"/>
                            </h5>
                            <h2 class="text-primary fw-bold mb-2">
                                <t t-esc="state.kpiData.value"/>
                            </h2>
                            <p class="card-text text-muted small mb-0">
                                <t t-esc="state.kpiData.description"/>
                            </p>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-4 mb-3">
                    <div class="card shadow-sm h-100">
                        <div class="card-body">
                            <h5 class="card-title text-muted mb-2">Utilisateurs Actifs</h5>
                            <h2 class="text-success fw-bold mb-2">
                                <t t-esc="state.activeUsers"/>
                            </h2>
                            <p class="card-text text-muted small mb-0">Utilisateurs avec statut actif</p>
                            <div t-if="state.rawData and state.rawData.analytics_summary" class="mt-2">
                                <small class="badge bg-success">
                                    <t t-esc="state.rawData.analytics_summary.active_percentage"/>% du total
                                </small>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-4 mb-3">
                    <div class="card shadow-sm h-100">
                        <div class="card-body">
                            <h5 class="card-title text-muted mb-2">Nouveaux Utilisateurs</h5>
                            <h2 class="text-warning fw-bold mb-2">
                                <t t-esc="state.newUsers"/>
                            </h2>
                            <p class="card-text text-muted small mb-0">Créés dans les 30 derniers jours</p>
                            <div t-if="state.rawData and state.rawData.analytics_summary" class="mt-2">
                                <small class="badge bg-warning">
                                    <t t-esc="state.rawData.analytics_summary.new_users_percentage"/>% du total
                                </small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Section Statistiques détaillées -->
            <div t-if="state.rawData and state.rawData.analytics_summary" class="row mb-4">
                <div class="col-md-3 col-sm-6 mb-3">
                    <div class="card shadow-sm text-center">
                        <div class="card-body py-3">
                            <h4 class="text-info mb-1">
                                <t t-esc="state.rawData.analytics_summary.users_with_recent_login || 0"/>
                            </h4>
                            <small class="text-muted">Connexions récentes</small>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-3 col-sm-6 mb-3">
                    <div class="card shadow-sm text-center">
                        <div class="card-body py-3">
                            <h4 class="text-secondary mb-1">
                                <t t-esc="state.rawData.analytics_summary.average_groups_per_user || 0"/>
                            </h4>
                            <small class="text-muted">Groupes moyens/utilisateur</small>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-3 col-sm-6 mb-3">
                    <div class="card shadow-sm text-center">
                        <div class="card-body py-3">
                            <h4 class="text-primary mb-1">
                                <t t-esc="state.rawData.analytics_summary.users_with_multiple_groups || 0"/>
                            </h4>
                            <small class="text-muted">Multi-groupes</small>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-3 col-sm-6 mb-3">
                    <div class="card shadow-sm text-center">
                        <div class="card-body py-3">
                            <h4 class="text-danger mb-1">
                                <t t-esc="state.rawData.analytics_summary.max_groups_per_user || 0"/>
                            </h4>
                            <small class="text-muted">Max groupes</small>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Section Graphique -->
            <div class="card shadow-sm">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">
                        <t t-if="state.currentFilter === 'active'">Analytics des Utilisateurs Actifs</t>
                        <t t-elif="state.currentFilter === 'inactive'">Analytics des Utilisateurs Inactifs</t>
                        <t t-else="">Analytics des Utilisateurs</t>
                    </h5>
                    <div t-if="state.rawData" class="badge bg-secondary">
                        Filtre: <t t-esc="state.rawData.filter_label"/>
                    </div>
                </div>
                
                <div class="card-body">
                    <t t-if="state.loading">
                        <div class="d-flex justify-content-center align-items-center" style="height: 400px;">
                            <div class="text-center">
                                <div class="spinner-border text-primary mb-3"></div>
                                <div class="text-muted">Chargement des données...</div>
                            </div>
                        </div>
                    </t>
                    <t t-elif="state.error">
                        <div class="d-flex justify-content-center align-items-center text-danger" style="height: 400px;">
                            <div class="text-center">
                                <i class="fa fa-exclamation-triangle fa-3x mb-3"></i>
                                <p>Impossible de charger le graphique</p>
                                <small><t t-esc="state.error"/></small>
                            </div>
                        </div>
                    </t>
                    <t t-else="">
                        <div t-ref="plotly-chart" style="min-height: 400px;"></div>
                        <div t-if="!state.chartData" class="d-flex justify-content-center align-items-center text-muted" style="height: 400px;">
                            <div class="text-center">
                                <i class="fa fa-chart-bar fa-3x mb-3"></i>
                                <p>Aucune donnée à afficher</p>
                            </div>
                        </div>
                    </t>
                </div>
            </div>
            
            <!-- Section Résumé -->
            <div t-if="state.rawData and state.rawData.analytics_summary" class="card shadow-sm mt-4">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0">Résumé des Analytics</h5>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-3 col-sm-6 mb-3">
                            <div class="text-center">
                                <h4 class="text-dark">
                                    <t t-esc="state.rawData.analytics_summary.total_all"/>
                                </h4>
                                <small class="text-muted">Total des utilisateurs</small>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-6 mb-3">
                            <div class="text-center">
                                <h4 class="text-success">
                                    <t t-esc="state.rawData.analytics_summary.active_percentage"/>%
                                </h4>
                                <small class="text-muted">Pourcentage actifs</small>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-6 mb-3">
                            <div class="text-center">
                                <h4 class="text-danger">
                                    <t t-esc="state.rawData.analytics_summary.inactive_users"/>
                                </h4>
                                <small class="text-muted">Utilisateurs inactifs</small>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-6 mb-3">
                            <div class="text-center">
                                <h4 class="text-warning">
                                    <t t-esc="state.rawData.analytics_summary.new_users_percentage"/>%
                                </h4>
                                <small class="text-muted">Nouveaux (30j)</small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
`;

console.log("Enregistrement de l'action qc_dashboard.action_user_dashboard");
registry.category('actions').add('qc_dashboard.action_user_dashboard', UserKPIDashboard);