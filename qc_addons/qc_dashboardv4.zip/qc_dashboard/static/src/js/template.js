/** @odoo-module **/
import { registry } from "@web/core/registry";
import { useService } from "@web/core/utils/hooks";

const { Component } = owl;
const { useState, onMounted, useRef } = owl.hooks;

console.log("Chargement de work_program_dashboard.js");

export class UserKPIDashboard extends Component {
    setup() {
        console.log("Initialisation du composant UserKPIDashboard principal");

        this.state = useState({
            // État de chargement global
            loading: false,
            error: null,

            // Filtres sélectionnés (partagés par tous les composants)
            selectedYear: new Date().getFullYear(),
            selectedMonth: null,
            selectedWeek: null,
            selectedDepartmentId: null,
            selectedResponsibleId: null,

            // Options pour les filtres
            availableYears: [],
            availableMonths: [],
            availableWeeks: [],
            availableDepartments: [],
            availableEmployees: [],

            // Filtres en cascade
            monthsForYear: [],
            weeksForMonth: [],
            employeesForDepartment: [],

            // Données des KPIs
            totalTasks: 0,
            completedTasks: 0,
            pendingTasks: 0,
            overdueTasks: 0,
            inProgressTasks: 0,

            // Données des graphiques
            chartData: {
                tasksByMonth: [],
                tasksByDepartment: [],
            },

            // Données des tables
            tableData: []
        });

        this.rpc = useService("rpc");
        this.orm = useService("orm");

        onMounted(async () => {
            await this.loadInitialData();
        });
    }

    // ===== MÉTHODES DE CHARGEMENT INITIAL =====
    async loadInitialData() {
        this.state.loading = true;
        try {
            console.log("Chargement des données initiales...");

            // Charger les options de base
            await Promise.all([
                this.loadAvailableYears(),
                this.loadDepartments(),
                this.loadEmployees()
            ]);

            // Charger les mois pour l'année courante
            await this.loadMonthsForYear(this.state.selectedYear);

            // Charger toutes les données
            await this.loadAllData();

        } catch (error) {
            console.error("Erreur lors du chargement initial:", error);
            this.state.error = error.message;
        } finally {
            this.state.loading = false;
        }
    }

    async loadAvailableYears() {
        try {
            const tasks = await this.orm.searchRead("work.program", [], ["my_week_of"]);
            const years = new Set();

            tasks.forEach(task => {
                if (task.my_week_of) {
                    const year = parseInt(task.my_week_of.split('-')[0]);
                    if (!isNaN(year)) {
                        years.add(year);
                    }
                }
            });

            this.state.availableYears = Array.from(years).sort((a, b) => b - a);
            console.log("Années disponibles:", this.state.availableYears);
        } catch (error) {
            console.error("Erreur lors du chargement des années:", error);
        }
    }

    async loadMonthsForYear(year) {
        if (!year) {
            // Si aucune année spécifiée, charger tous les mois
            try {
                const tasks = await this.orm.searchRead("work.program", [], ["my_month"]);
                const monthsSet = new Set();

                tasks.forEach(task => {
                    if (task.my_month) {
                        monthsSet.add(task.my_month);
                    }
                });

                this.state.monthsForYear = Array.from(monthsSet);
                console.log("Tous les mois disponibles:", this.state.monthsForYear);
            } catch (error) {
                console.error("Erreur lors du chargement de tous les mois:", error);
            }
            return;
        }

        try {
            const tasks = await this.orm.searchRead("work.program", [], ["my_week_of", "my_month"]);
            const monthsSet = new Set();

            tasks.forEach(task => {
                if (task.my_week_of && task.my_month) {
                    const taskYear = parseInt(task.my_week_of.split('-')[0]);
                    if (taskYear === year) {
                        monthsSet.add(task.my_month);
                    }
                }
            });

            this.state.monthsForYear = Array.from(monthsSet);
            console.log(`Mois disponibles pour ${year}:`, this.state.monthsForYear);
        } catch (error) {
            console.error("Erreur lors du chargement des mois:", error);
        }
    }

    async loadWeeksForMonth(year, month) {
        if (!month) {
            this.state.weeksForMonth = [];
            return;
        }

        if (!year) {
            // Si aucune année spécifiée, charger toutes les semaines pour ce mois
            try {
                const tasks = await this.orm.searchRead("work.program", [], ["my_week_of", "my_month"]);
                const weeksSet = new Set();

                tasks.forEach(task => {
                    if (task.my_week_of && task.my_month === month) {
                        weeksSet.add(task.my_week_of);
                    }
                });

                this.state.weeksForMonth = Array.from(weeksSet).sort();
                console.log(`Toutes les semaines disponibles pour ${month}:`, this.state.weeksForMonth);
            } catch (error) {
                console.error("Erreur lors du chargement de toutes les semaines:", error);
            }
            return;
        }

        try {
            const tasks = await this.orm.searchRead("work.program", [], ["my_week_of", "my_month"]);
            const weeksSet = new Set();

            tasks.forEach(task => {
                if (task.my_week_of && task.my_month) {
                    const taskYear = parseInt(task.my_week_of.split('-')[0]);
                    if (taskYear === year && task.my_month === month) {
                        weeksSet.add(task.my_week_of);
                    }
                }
            });

            this.state.weeksForMonth = Array.from(weeksSet).sort();
            console.log(`Semaines disponibles pour ${month} ${year}:`, this.state.weeksForMonth);
        } catch (error) {
            console.error("Erreur lors du chargement des semaines:", error);
        }
    }

    async loadDepartments() {
        try {
            const departments = await this.orm.searchRead("hr.department", [], ["name"]);
            this.state.availableDepartments = departments;
            this.state.employeesForDepartment = await this.orm.searchRead("hr.employee", [], ["name"]);
            console.log("Départements chargés:", departments.length);
        } catch (error) {
            console.error("Erreur lors du chargement des départements:", error);
        }
    }

    async loadEmployees() {
        try {
            const employees = await this.orm.searchRead("hr.employee", [], ["name"]);
            this.state.availableEmployees = employees;
            console.log("Employés chargés:", employees.length);
        } catch (error) {
            console.error("Erreur lors du chargement des employés:", error);
        }
    }

    async loadEmployeesForDepartment(departmentId) {
        if (!departmentId) {
            this.state.employeesForDepartment = this.state.availableEmployees;
            return;
        }

        try {
            const employees = await this.orm.searchRead("hr.employee",
                [["department_id", "=", departmentId]],
                ["name"]
            );
            this.state.employeesForDepartment = employees;
            console.log(`Employés pour département ${departmentId}:`, employees.length);
        } catch (error) {
            console.error("Erreur lors du chargement des employés par département:", error);
            this.state.employeesForDepartment = [];
        }
    }

    // ===== MÉTHODES DE CHARGEMENT DES DONNÉES =====
    async loadAllData() {
        console.log("Chargement de toutes les données...");

        const params = {
            year: this.state.selectedYear || null, // ✅ CORRECTION: Envoie null si aucune année sélectionnée
            month: this.state.selectedMonth,
            week: this.state.selectedWeek,
            department_id: this.state.selectedDepartmentId,
            responsible_id: this.state.selectedResponsibleId
        };

        console.log("Paramètres envoyés au serveur:", params);

        await Promise.all([
            this.loadKPIData(params),
            this.loadChartData(params),
            this.loadTableData(params)
        ]);
    }

    async loadKPIData(params) {
        try {
            console.log("Chargement des données KPI...");

            // KPI 1: Total des tâches (existant)
            const totalResult = await this.rpc("/dashboard/work_program_count", params);
            if (totalResult.error) {
                this.state.error = totalResult.message;
            } else {
                this.state.totalTasks = totalResult.total_tasks;
            }

            // KPI 2: Tâches terminées
            await this.loadCompletedTasks(params);

            // KPI 3: Tâches en attente
            await this.loadPendingTasks(params);

            // KPI 4: Tâches en retard
            await this.loadOverdueTasks(params);

            // KPI 5: Tâches en cours
            await this.loadInProgressTasks(params);

        } catch (error) {
            console.error("Erreur lors du chargement des KPIs:", error);
            this.state.error = "Erreur lors du chargement des KPIs: " + error.message;
        }
    }

    // Fonctions simples pour les autres KPIs (à développer selon vos besoins)
    async loadCompletedTasks(params) {
        // TODO: Implémenter la logique pour les tâches terminées
        // Exemple simple:
        // const result = await this.rpc("/dashboard/completed_tasks_count", params);
        // this.state.completedTasks = result.count;
        console.log("Chargement des tâches terminées - À implémenter");
        this.state.completedTasks = 0;
    }

    async loadPendingTasks(params) {
        // TODO: Implémenter la logique pour les tâches en attente
        console.log("Chargement des tâches en attente - À implémenter");
        this.state.pendingTasks = 0;
    }

    async loadOverdueTasks(params) {
        // TODO: Implémenter la logique pour les tâches en retard
        console.log("Chargement des tâches en retard - À implémenter");
        this.state.overdueTasks = 0;
    }

    async loadInProgressTasks(params) {
        // TODO: Implémenter la logique pour les tâches en cours
        console.log("Chargement des tâches en cours - À implémenter");
        this.state.inProgressTasks = 0;
    }

    async loadChartData(params) {
        try {
            console.log("Chargement des données des graphiques...");

            // Graphique 1: Tâches par mois
            await this.loadTasksByMonth(params);

            // Graphique 2: Tâches par département
            await this.loadTasksByDepartment(params);

        } catch (error) {
            console.error("Erreur lors du chargement des graphiques:", error);
        }
    }

    async loadTasksByMonth(params) {
        // TODO: Implémenter la logique pour le graphique des tâches par mois
        console.log("Chargement du graphique tâches par mois - À implémenter");
        this.state.chartData.tasksByMonth = [];
    }

    async loadTasksByDepartment(params) {
        // TODO: Implémenter la logique pour le graphique des tâches par département
        console.log("Chargement du graphique tâches par département - À implémenter");
        this.state.chartData.tasksByDepartment = [];
    }

    async loadTableData(params) {
        try {
            console.log("Chargement des données du tableau...");
            // TODO: Implémenter la logique pour la table de données
            this.state.tableData = [];
        } catch (error) {
            console.error("Erreur lors du chargement du tableau:", error);
        }
    }

    // ===== GESTIONNAIRES D'ÉVÉNEMENTS POUR LES FILTRES EN CASCADE =====
    async onYearChange(event) {
        const yearValue = event.target.value;
        const year = yearValue === "" ? null : parseInt(yearValue); // ✅ CORRECTION: null si "Toutes"
        console.log("Changement d'année vers:", year);

        this.state.selectedYear = year;
        this.state.selectedMonth = null;
        this.state.selectedWeek = null;

        // Charger les mois pour l'année sélectionnée (ou tous si year est null)
        await this.loadMonthsForYear(year);
        this.state.weeksForMonth = [];
    }

    async onMonthChange(event) {
        const month = event.target.value || null;
        console.log("Changement de mois vers:", month);

        this.state.selectedMonth = month;
        this.state.selectedWeek = null;

        if (month) {
            await this.loadWeeksForMonth(this.state.selectedYear, month);
        } else {
            this.state.weeksForMonth = [];
        }
    }

    onWeekChange(event) {
        const week = event.target.value || null;
        console.log("Changement de semaine vers:", week);
        this.state.selectedWeek = week;
    }

    async onDepartmentChange(event) {
        const deptId = parseInt(event.target.value) || null;
        console.log("Changement de département vers:", deptId);

        this.state.selectedDepartmentId = deptId;
        this.state.selectedResponsibleId = null;

        await this.loadEmployeesForDepartment(deptId);
    }

    onResponsibleChange(event) {
        const respId = parseInt(event.target.value) || null;
        console.log("Changement de responsable vers:", respId);
        this.state.selectedResponsibleId = respId;
    }

    // ===== ACTIONS DES BOUTONS =====
    async onApplyFilters() {
        console.log("Application des filtres...");
        this.state.loading = true;
        try {
            await this.loadAllData();
        } catch (error) {
            console.error("Erreur lors de l'application des filtres:", error);
            this.state.error = error.message;
        } finally {
            this.state.loading = false;
        }
    }

    async onResetFilters() {
        console.log("Réinitialisation des filtres...");

        this.state.selectedYear = new Date().getFullYear();
        this.state.selectedMonth = null;
        this.state.selectedWeek = null;
        this.state.selectedDepartmentId = null;
        this.state.selectedResponsibleId = null;

        // Recharger les données
        await this.loadMonthsForYear(this.state.selectedYear);
        this.state.weeksForMonth = [];
        this.state.employeesForDepartment = this.state.availableEmployees;

        await this.loadAllData();
    }
}

// Template du composant
UserKPIDashboard.template = "qc_dashboard.UserKPIDashboard";

console.log("Enregistrement de l'action qc_dashboard.action_user_dashboard");
registry.category('actions').add('qc_dashboard.action_user_dashboard', UserKPIDashboard);