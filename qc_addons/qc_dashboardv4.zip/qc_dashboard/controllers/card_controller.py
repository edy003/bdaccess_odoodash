# -*- coding: utf-8 -*-
from odoo import http
from odoo.http import request
import logging
import pandas as pd

_logger = logging.getLogger(__name__)


class WorkProgramDashboardController(http.Controller):

    @http.route('/dashboard/work_program_count', type='json', auth='public', methods=['POST'], csrf=False)
    def get_work_program_count(self, year=None, month=None, week=None, department_id=None, responsible_id=None):
        """
        Récupère le nombre total de tâches avec filtres
        Paramètres de filtrage:
        - year: Année (ex: 2025) ou None pour toutes les années
        - month: Mois en français (ex: 'janvier', 'février', etc.)
        - week: Semaine au format YYYY-MM-DD (début de semaine)
        - department_id: ID du département
        - responsible_id: ID de l'employé responsable
        """
        try:
            _logger.info(
                f"Début de get_work_program_count avec filtres: year={year}, month={month}, week={week}, dept={department_id}, resp={responsible_id}")

            # ✅ CORRECTION: Ne plus forcer l'année courante si year=None
            # Garde year=None pour récupérer toutes les années
            if year is not None:
                _logger.info(f"Filtre sur l'année: {year}")
            else:
                _logger.info("Aucun filtre année - récupération de toutes les années")

            # Récupération de toutes les tâches
            tasks = request.env['work.program'].sudo().search([])
            _logger.info(f"Trouvé {len(tasks)} tâches au total")

            if not tasks:
                return {'total_tasks': 0, 'error': False}

            # Création d'un DataFrame pandas pour faciliter le traitement
            task_data_list = []

            for task in tasks:
                # Extraction de l'année depuis my_week_of (format: YYYY-MM-DD)
                task_year = None
                if task.my_week_of:
                    try:
                        task_year = int(task.my_week_of.split('-')[0])
                    except:
                        task_year = None

                task_data_list.append({
                    'id': task.id,
                    'year': task_year,
                    'my_month': task.my_month,
                    'my_week_of': task.my_week_of,
                    'work_programm_department_id': task.work_programm_department_id.id if task.work_programm_department_id else None,
                    'responsible_id': task.responsible_id.id if task.responsible_id else None,
                })

            # Création du DataFrame
            df = pd.DataFrame(task_data_list)

            if df.empty:
                return {'total_tasks': 0, 'error': False}

            # Application des filtres
            filtered_df = self._apply_filters(df, year, month, week, department_id, responsible_id)

            # Calcul du nombre total de tâches
            total_tasks = len(filtered_df)

            _logger.info(f"Nombre de tâches après filtres: {total_tasks}")

            return {
                'total_tasks': total_tasks,
                'error': False
            }

        except Exception as e:
            _logger.error(f"Erreur dans get_work_program_count: {str(e)}", exc_info=True)
            return {
                'error': True,
                'message': str(e),
                'total_tasks': 0
            }

    def _apply_filters(self, df, year, month, week, department_id, responsible_id):
        """Applique les filtres sur le DataFrame"""
        filtered_df = df.copy()

        try:
            # ✅ CORRECTION: Filtre par année seulement si year n'est pas None
            if year is not None:
                year = int(year)
                filtered_df = filtered_df[filtered_df['year'] == year]
                _logger.info(f"Filtre année {year}: {len(filtered_df)} tâches restantes")
            else:
                _logger.info(f"Pas de filtre année - {len(filtered_df)} tâches pour toutes les années")

            # Filtre par mois
            if month:
                filtered_df = filtered_df[filtered_df['my_month'] == month]
                _logger.info(f"Filtre mois {month}: {len(filtered_df)} tâches restantes")

            # Filtre par semaine
            if week:
                filtered_df = filtered_df[filtered_df['my_week_of'] == week]
                _logger.info(f"Filtre semaine {week}: {len(filtered_df)} tâches restantes")

            # Filtre par département
            if department_id:
                department_id = int(department_id)
                filtered_df = filtered_df[filtered_df['work_programm_department_id'] == department_id]
                _logger.info(f"Filtre département {department_id}: {len(filtered_df)} tâches restantes")

            # Filtre par responsable
            if responsible_id:
                responsible_id = int(responsible_id)
                filtered_df = filtered_df[filtered_df['responsible_id'] == responsible_id]
                _logger.info(f"Filtre responsable {responsible_id}: {len(filtered_df)} tâches restantes")

            return filtered_df

        except Exception as e:
            _logger.error(f"Erreur dans _apply_filters: {str(e)}")
            return df