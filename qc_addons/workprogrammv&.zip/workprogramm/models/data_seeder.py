# import logging
# from datetime import datetime, timedelta
# import random
# from odoo import api, models
#
# _logger = logging.getLogger(__name__)
#
#
# class DataSeeder(models.Model):
#     _name = 'data.seeder'
#     _description = 'Générateur exhaustif de données de test basé sur workflows réels'
#
#     @api.model
#     def seed_all_test_data(self):
#         """Point d'entrée principal pour générer toutes les données"""
#         _logger.info("=== DÉBUT GÉNÉRATION DONNÉES EXHAUSTIVES ===")
#         try:
#             # Créer les structures workflow pour SUPPORT et CONSULTING
#             activities = self.create_complete_workflow_structures()
#
#             # Générer des WorkPrograms exhaustifs
#             self.seed_comprehensive_work_programs(activities)
#
#             self.env.cr.commit()
#             _logger.info("=== GÉNÉRATION TERMINÉE AVEC SUCCÈS ===")
#             return {'status': 'success', 'message': 'Données exhaustives générées avec succès'}
#         except Exception as e:
#             _logger.error(f"ERREUR GÉNÉRALE: {e}")
#             self.env.cr.rollback()
#             raise
#
#     @api.model
#     def create_complete_workflow_structures(self):
#         """Crée les structures workflow complètes pour SUPPORT et CONSULTING"""
#         _logger.info("Création des structures workflow complètes...")
#
#         # Vérifier que tous les modèles nécessaires existent
#         models_to_check = [
#             'workflow.domain', 'workflow.process', 'workflow.subprocess',
#             'workflow.activity', 'workflow.procedure', 'workflow.task.formulation',
#             'workflow.deliverable'
#         ]
#         missing_models = [m for m in models_to_check if m not in self.env]
#         if missing_models:
#             _logger.warning(f"Modèles workflow manquants: {missing_models}")
#             return {}
#
#         workflows_config = self._get_complete_workflows_config()
#         created_activities = {}
#
#         for domain_name, workflow_data in workflows_config.items():
#             domain = self._create_or_get_domain(domain_name, workflow_data.get('type', 'internal'))
#
#             for process_data in workflow_data['processes']:
#                 process = self._create_or_get_process(process_data['name'], domain.id)
#
#                 for subprocess_data in process_data.get('sub_processes', []):
#                     subprocess = self._create_or_get_subprocess(subprocess_data['name'], process.id)
#
#                     for activity_data in subprocess_data.get('activities', []):
#                         activity = self._create_or_get_activity(activity_data['name'], subprocess.id)
#                         created_activities[activity.name] = activity
#
#                         # Créer les procédures
#                         for procedure_name in activity_data.get('procedures', []):
#                             procedure = self._create_or_get_procedure(procedure_name, activity.id)
#
#                             # Créer les formulations de tâches pour cette procédure
#                             for task_form in activity_data.get('task_formulations', []):
#                                 self._create_or_get_task_formulation(task_form, procedure.id)
#
#                         # Créer les livrables
#                         for deliverable_name in activity_data.get('deliverables', []):
#                             self._create_or_get_deliverable(deliverable_name, activity.id)
#
#         return created_activities
#
#     def _get_complete_workflows_config(self):
#         """Configuration complète des workflows pour SUPPORT et CONSULTING"""
#         return {
#             'Support': {
#                 'type': 'internal',
#                 'processes': [
#                     {
#                         'name': 'PS4. Gestion du système d\'information',
#                         'sub_processes': [
#                             {
#                                 'name': 'PS4.1: Gérer le parc informatique et bureautique',
#                                 'activities': [
#                                     {
#                                         'name': 'PS4.1_A1: Gérer les entrées / sorties d\'équipements informatiques',
#                                         'procedures': [
#                                             'PS4.1_A1_P1: Identifier les besoins en equipement TIC',
#                                             'PS4.1_A1_P2: Valider, transmettre le besoin en equipement TIC',
#                                             'PS4.1_A1_P3: Acquerir les equipements TIC',
#                                             'PS4.1_A1_P4: Mettre à disposition et suivre les equipements informatique'
#                                         ],
#                                         'deliverables': ['PS4.1_A1_L1: Registre des actifs informatiques'],
#                                         'task_formulations': [
#                                             'Identifier les besoins en equipement TIC et les references appropriées',
#                                             'Valider et transmettre le besoin en equipement TIC',
#                                             'Acquerir les equipements TIC',
#                                             'Mettre à disposition et suivre les equipements informatique'
#                                         ]
#                                     },
#                                     {
#                                         'name': 'PS4.1_A2: Gérer les licences et les abonnements',
#                                         'procedures': [
#                                             'PS4.1_A2_P1: Identifier et soumettre le besoin en license',
#                                             'PS4.1_A2_P2: Valider et transmettre le besoin en license',
#                                             'PS4.1_A2_P3: Effectuer l\'abonnement ou l\'acquisition du service',
#                                             'PS4.1_A2_P4: Suivre les licences et abonnements'
#                                         ],
#                                         'deliverables': ['PS4.1_A2_L2: Fiche de besoin de license / abonnement'],
#                                         'task_formulations': [
#                                             'Identifier et soumettre le besoin en license ou abonnement',
#                                             'Valider et transmettre le besoin en license ou abonnement',
#                                             'Effectuer l\'abonnement ou l\'acquisition du service',
#                                             'Suivre les licences et abonnements'
#                                         ]
#                                     },
#                                     {
#                                         'name': 'PS4.1_A3: Installer un équipement ou Logiciel',
#                                         'procedures': [
#                                             'PS4.1_A3_P1: Installer les équipements et systèmes TIC'
#                                         ],
#                                         'deliverables': [
#                                             'PS4.1_A3_L4: Guide d\'installation des equipements ou logiciel',
#                                             'PS4.1_A3_L5: Fiche d\'utilisation des outils',
#                                             'PS4.1_A3_L6: Requete de maintenance',
#                                             'PS4.1_A3_L7: Fiche de suivi de maintenance'
#                                         ],
#                                         'task_formulations': [
#                                             'Installer les équipements et systèmes TIC',
#                                             'Configurer les logiciels et applications',
#                                             'Tester le bon fonctionnement des installations'
#                                         ]
#                                     }
#                                 ]
#                             },
#                             {
#                                 'name': 'PS4.2: Gérer le système de Gestion de l\'entreprise',
#                                 'activities': [
#                                     {
#                                         'name': 'PS4.2_A1: Gérer les utilisateurs et leurs droits',
#                                         'procedures': [
#                                             'PS4.2_A1_P1: Créer et gérer les comptes utilisateurs',
#                                             'PS4.2_A1_P2: Attribuer et modifier les droits d\'accès'
#                                         ],
#                                         'deliverables': [
#                                             'PS4.2_A1_L1: Matrice des droits',
#                                             'PS4.2_A1_L2: Fiche de l\'utilisateur'
#                                         ],
#                                         'task_formulations': [
#                                             'Créer et configurer les comptes utilisateurs',
#                                             'Définir et attribuer les droits d\'accès',
#                                             'Maintenir la matrice des droits'
#                                         ]
#                                     },
#                                     {
#                                         'name': 'PS4.2_A2: Maintenir le système',
#                                         'procedures': [
#                                             'PS4.2_A2_P1: Effectuer la maintenance corrective',
#                                             'PS4.2_A2_P2: Effectuer la maintenance évolutive'
#                                         ],
#                                         'deliverables': ['PS4.2_A2_L3: Rapport de maintenance'],
#                                         'task_formulations': [
#                                             'Diagnostiquer et corriger les dysfonctionnements',
#                                             'Mettre à jour et améliorer le système',
#                                             'Documenter les interventions de maintenance'
#                                         ]
#                                     }
#                                 ]
#                             }
#                         ]
#                     },
#                     {
#                         'name': 'PR5. Gestion de la Capacité (Staffing)',
#                         'sub_processes': [
#                             {
#                                 'name': 'PR5.1: Etablir les contrats',
#                                 'activities': [
#                                     {
#                                         'name': 'PR5.1_A1: Estimer le temps d\'intervention',
#                                         'procedures': [
#                                             'PR5.1_A1_P1: Estimation temporelle et planification',
#                                             'PR5.1_A1_P2: Validation du plan de ressources'
#                                         ],
#                                         'deliverables': ['PR5.1_A1_L1: Plan de ressources'],
#                                         'task_formulations': [
#                                             'Estimer le temps d\'intervention et préparer le plan',
#                                             'Valider le plan de ressources',
#                                             'Ajuster la planification selon les contraintes'
#                                         ]
#                                     }
#                                 ]
#                             }
#                         ]
#                     }
#                 ]
#             },
#             'Consulting': {
#                 'type': 'external',
#                 'processes': [
#                     {
#                         'name': 'PR1. Faire des propositions',
#                         'sub_processes': [
#                             {
#                                 'name': 'PR1.1: Gérer le référentiel des consultants',
#                                 'activities': [
#                                     {
#                                         'name': 'PR1.1_A1: Gérer le BOOK CV',
#                                         'procedures': [
#                                             'PR1.1_A1_P1: Collecte de CV',
#                                             'PR1.1_A1_P2: Instruction de mise à jour du Book CV',
#                                             'PR1.1_A1_P3: Mise à jour du Book CV'
#                                         ],
#                                         'deliverables': [
#                                             'PR1.1_A1_L1: Modèles et Instructions CV (Français et anglais)',
#                                             'PR1.1_A1_L2: BOOK CVs suivant différents modèles'
#                                         ],
#                                         'task_formulations': [
#                                             'Collecter les CV',
#                                             'Donner les instructions de mise à jour du Book CV',
#                                             'Mettre à jour le Book CV (Insertion, Modification, Suppression)',
#                                             'Faire la revue et validation du Book CV'
#                                         ]
#                                     },
#                                     {
#                                         'name': 'PR1.1_A3: Gérer le BOOK Personnas',
#                                         'procedures': [
#                                             'PR1.1_A3_P1: Instruction de mise à jour du Book Persona',
#                                             'PR1.1_A3_P2: Mise à jour du Book Persona',
#                                             'PR1.1_A3_P3: Revue et Validation du Book Persona'
#                                         ],
#                                         'deliverables': [
#                                             'PR1.1_A2_L1: Modèle et Instructions Profile (Français et anglais)',
#                                             'PR1.1_A5_L2: Dossier expert'
#                                         ],
#                                         'task_formulations': [
#                                             'Donner les instructions de mise à jour du Book Persona',
#                                             'Faire la mise à jour du Book Persona (Insertion, Modification, Suppression)',
#                                             'Faire la revue et validation du Book Persona'
#                                         ]
#                                     }
#                                 ]
#                             },
#                             {
#                                 'name': 'PR1.2: Gérer les références/expériences',
#                                 'activities': [
#                                     {
#                                         'name': 'PR1.2_A1: Gérer le BOOK Références détaillés',
#                                         'procedures': [
#                                             'PR1.2_A1_P3: Mise à jour du Book Références',
#                                             'PR1.2_A1_P4: Revue et Validation du Book Références'
#                                         ],
#                                         'deliverables': [
#                                             'PR1.2_A1_L1: Modèles et Instructions Reference (Français et anglais)',
#                                             'PR1.2_A1_L2: BOOK Références détaillés suivant différents modèles'
#                                         ],
#                                         'task_formulations': [
#                                             'Mettre à jour le Book Références (Insertion, Modification, Suppression)',
#                                             'Faire la revue et validation du Book Références'
#                                         ]
#                                     },
#                                     {
#                                         'name': 'PR1.2_A2: Gérer le registre des expériences',
#                                         'procedures': [
#                                             'PR1.2_A2_P1: Instruction de mise à jour du Registre des Expériences',
#                                             'PR1.2_A2_P2: Mise à jour du Registre des expériences'
#                                         ],
#                                         'deliverables': [
#                                             'PR1.2_A2_L1: Modèles et Instructions Registre des expériences',
#                                             'PR1.2_A2_L2: Registre des expériences'
#                                         ],
#                                         'task_formulations': [
#                                             'Donner les instructions de mise à jour du Registre des Expériences',
#                                             'Mettre à jour le Registre des expériences (Insertion, Modification, Suppression)'
#                                         ]
#                                     }
#                                 ]
#                             }
#                         ]
#                     },
#                     {
#                         'name': 'PR2. Préparation des Missions',
#                         'sub_processes': [
#                             {
#                                 'name': 'PR2.1: Elaborer le plan projet',
#                                 'activities': [
#                                     {
#                                         'name': 'PR2.1_A1: Définir la méthodologie projet',
#                                         'procedures': [
#                                             'PR2.1_A1_P1: Analyser les exigences du projet',
#                                             'PR2.1_A1_P2: Sélectionner la méthodologie appropriée'
#                                         ],
#                                         'deliverables': ['PR2.1_A1_L1: Document de méthodologie projet'],
#                                         'task_formulations': [
#                                             'Analyser les exigences et contraintes du projet',
#                                             'Sélectionner et adapter la méthodologie appropriée',
#                                             'Documenter la méthodologie retenue'
#                                         ]
#                                     }
#                                 ]
#                             }
#                         ]
#                     }
#                 ]
#             }
#         }
#
#     def _create_or_get_domain(self, name, domain_type):
#         """Crée ou récupère un domaine"""
#         Domain = self.env['workflow.domain']
#         domain = Domain.search([('name', '=', name)], limit=1)
#         if not domain:
#             domain = Domain.create({'name': name, 'dpt_type': domain_type})
#         return domain
#
#     def _create_or_get_process(self, name, domain_id):
#         """Crée ou récupère un processus"""
#         Process = self.env['workflow.process']
#         process = Process.search([('name', '=', name)], limit=1)
#         if not process:
#             process = Process.create({'name': name, 'domain_id': domain_id})
#         return process
#
#     def _create_or_get_subprocess(self, name, process_id):
#         """Crée ou récupère un sous-processus"""
#         SubProcess = self.env['workflow.subprocess']
#         subprocess = SubProcess.search([('name', '=', name)], limit=1)
#         if not subprocess:
#             subprocess = SubProcess.create({'name': name, 'process_id': process_id})
#         return subprocess
#
#     def _create_or_get_activity(self, name, subprocess_id):
#         """Crée ou récupère une activité"""
#         Activity = self.env['workflow.activity']
#         activity = Activity.search([('name', '=', name)], limit=1)
#         if not activity:
#             activity = Activity.create({'name': name, 'sub_process_id': subprocess_id})
#         return activity
#
#     def _create_or_get_procedure(self, name, activity_id):
#         """Crée ou récupère une procédure"""
#         Procedure = self.env['workflow.procedure']
#         procedure = Procedure.search([('name', '=', name)], limit=1)
#         if not procedure:
#             procedure = Procedure.create({'name': name, 'activity_id': activity_id})
#         return procedure
#
#     def _create_or_get_task_formulation(self, name, procedure_id):
#         """Crée ou récupère une formulation de tâche"""
#         TaskForm = self.env['workflow.task.formulation']
#         task_form = TaskForm.search([('name', '=', name)], limit=1)
#         if not task_form:
#             task_form = TaskForm.create({'name': name, 'procedure_id': procedure_id})
#         return task_form
#
#     def _create_or_get_deliverable(self, name, activity_id):
#         """Crée ou récupère un livrable"""
#         Deliverable = self.env['workflow.deliverable']
#         deliverable = Deliverable.search([('name', '=', name)], limit=1)
#         if not deliverable:
#             deliverable = Deliverable.create({'name': name, 'activity_id': activity_id})
#         return deliverable
#
#     def _get_month_name_from_date(self, date_obj):
#         """Retourne le nom du mois en français à partir d'une date"""
#         months_fr = {
#             1: 'janvier', 2: 'février', 3: 'mars', 4: 'avril',
#             5: 'mai', 6: 'juin', 7: 'juillet', 8: 'août',
#             9: 'septembre', 10: 'octobre', 11: 'novembre', 12: 'décembre'
#         }
#         return months_fr.get(date_obj.month, 'janvier')
#
#     def _get_week_of_year(self, date_obj):
#         """Retourne le numéro de semaine dans l'année"""
#         return date_obj.isocalendar()[1]
#
#     @api.model
#     def seed_comprehensive_work_programs(self, activities):
#         """Génère des WorkPrograms exhaustifs et réalistes avec cohérence date/semaine"""
#         _logger.info("=== DÉBUT GÉNÉRATION WORK.PROGRAMS EXHAUSTIFS ===")
#
#         WorkProgram = self.env['work.program']
#
#         # Récupérer les données existantes
#         projects = list(self.env['project.project'].search([]))
#         employees = list(self.env['hr.employee'].search([]))
#         support_dept = self.env['hr.department'].search([('name', '=', 'Support')], limit=1)
#         consulting_dept = self.env['hr.department'].search([('name', '=', 'Consulting')], limit=1)
#
#         if not projects or not employees:
#             _logger.warning("Projets ou employés inexistants, génération annulée")
#             return
#
#         # Séparer les employés par département
#         support_employees = [emp for emp in employees if emp.department_id == support_dept]
#         consulting_employees = [emp for emp in employees if emp.department_id == consulting_dept]
#
#         # Séparer les activités par domaine
#         support_activities = [act for name, act in activities.items() if 'PS4' in name or 'PR5' in name]
#         consulting_activities = [act for name, act in activities.items() if 'PR1' in name or 'PR2' in name]
#
#         # CORRECTION : Base date fixe pour cohérence (1er septembre 2024)
#         base_date = datetime(2024, 9, 1)
#         program_counter = 1
#
#         # Générer pour les 6 derniers mois + 6 mois futurs
#         for month_offset in range(-6, 7):  # -6 à +6 mois
#             # CORRECTION : Calcul précis du mois cible
#             target_year = base_date.year
#             target_month = base_date.month + month_offset
#
#             # Ajuster année si nécessaire
#             while target_month <= 0:
#                 target_month += 12
#                 target_year -= 1
#             while target_month > 12:
#                 target_month -= 12
#                 target_year += 1
#
#             # Date du premier jour du mois cible
#             month_start = datetime(target_year, target_month, 1)
#             month_name = self._get_month_name_from_date(month_start)
#
#             # Calculer le dernier jour du mois
#             if target_month == 12:
#                 next_month_start = datetime(target_year + 1, 1, 1)
#             else:
#                 next_month_start = datetime(target_year, target_month + 1, 1)
#             month_end = next_month_start - timedelta(days=1)
#
#             # Générer 2-4 programmes par mois pour chaque département
#             nb_programs_per_month = random.randint(2, 4)
#
#             # Générer pour le département SUPPORT
#             if support_employees and support_activities:
#                 for i in range(nb_programs_per_month):
#                     employee = random.choice(support_employees)
#                     project = random.choice(projects)
#                     activity = random.choice(support_activities)
#
#                     # CORRECTION : Date d'assignation dans le mois cible
#                     day_in_month = random.randint(1, month_end.day)
#                     assignment_date = datetime(target_year, target_month, day_in_month)
#
#                     program_data = self._generate_program_data_with_relations(
#                         employee, project, activity, support_dept,
#                         assignment_date, program_counter, activities
#                     )
#
#                     try:
#                         WorkProgram.create(program_data)
#                         program_counter += 1
#                     except Exception as e:
#                         _logger.error(f"Erreur création WorkProgram SUPPORT {employee.name}: {e}")
#
#             # Générer pour le département CONSULTING
#             if consulting_employees and consulting_activities:
#                 for i in range(nb_programs_per_month):
#                     employee = random.choice(consulting_employees)
#                     project = random.choice(projects)
#                     activity = random.choice(consulting_activities)
#
#                     # CORRECTION : Date d'assignation dans le mois cible
#                     day_in_month = random.randint(1, month_end.day)
#                     assignment_date = datetime(target_year, target_month, day_in_month)
#
#                     program_data = self._generate_program_data_with_relations(
#                         employee, project, activity, consulting_dept,
#                         assignment_date, program_counter, activities
#                     )
#
#                     try:
#                         WorkProgram.create(program_data)
#                         program_counter += 1
#                     except Exception as e:
#                         _logger.error(f"Erreur création WorkProgram CONSULTING {employee.name}: {e}")
#
#         _logger.info(f"=== FIN GÉNÉRATION WORK.PROGRAMS - {program_counter - 1} programmes créés ===")
#
#     def _generate_program_data_with_relations(self, employee, project, activity, department,
#                                               assignment_date, counter, activities):
#         """Génère les données réalistes pour un WorkProgram avec toutes les relations"""
#
#         # CORRECTION : Calculs basés sur la date d'assignation réelle
#         month_name = self._get_month_name_from_date(assignment_date)
#         week_of_year = self._get_week_of_year(assignment_date)
#         initial_deadline = assignment_date + timedelta(days=random.randint(7, 28))
#
#         # Statuts réalistes avec distribution
#         status_weights = ['draft', 'ongoing', 'ongoing', 'done', 'done', 'done', 'cancelled']
#         status = random.choice(status_weights)
#
#         # Gestion des reports et dates réelles
#         nb_postpones = 0
#         actual_deadline = initial_deadline
#         if status in ['ongoing', 'done'] and random.random() < 0.3:
#             nb_postpones = random.randint(1, 3)
#             actual_deadline = initial_deadline + timedelta(days=nb_postpones * random.randint(3, 7))
#
#         # Pourcentages de completion réalistes
#         completion_map = {
#             'draft': random.randint(0, 15),
#             'ongoing': random.randint(20, 80),
#             'done': random.randint(95, 100),
#             'cancelled': random.randint(0, 40)
#         }
#
#         # Priorités et complexités variées
#         priorities = ['low', 'medium', 'high']
#         complexities = ['low', 'medium', 'high']
#
#         # Efforts variables selon le département
#         if department.name == 'Support':
#             base_effort = random.choice([4, 8, 12, 16, 24])
#         else:  # Consulting
#             base_effort = random.choice([8, 16, 24, 32, 40, 56])
#
#         # *** AJOUT DES RELATIONS MANQUANTES ***
#
#         # 1. Récupérer une procédure liée à l'activité
#         procedures = self.env['workflow.procedure'].search([('activity_id', '=', activity.id)])
#         procedure_id = procedures[0].id if procedures else False
#
#         # 2. Récupérer une formulation de tâche liée à la procédure
#         task_formulation_id = False
#         if procedure_id:
#             task_formulations = self.env['workflow.task.formulation'].search([('procedure_id', '=', procedure_id)])
#             task_formulation_id = task_formulations[0].id if task_formulations else False
#
#         # 3. Récupérer les livrables liés à l'activité
#         deliverables = self.env['workflow.deliverable'].search([('activity_id', '=', activity.id)])
#         deliverable_ids = [
#             (6, 0, [d.id for d in deliverables[:random.randint(1, min(3, len(deliverables)))] if deliverables])]
#
#         # 4. Ajouter du support (employés du même département, différents du responsable)
#         potential_support = [emp for emp in self.env['hr.employee'].search([('department_id', '=', department.id)])
#                              if emp.id != employee.id]
#         nb_support = random.randint(0, min(2, len(potential_support)))
#         support_ids = [
#             (6, 0, [emp.id for emp in random.sample(potential_support, nb_support)])] if potential_support else [
#             (5, 0, 0)]
#
#         # Commentaires variés selon le département
#         if department.name == 'Support':
#             comments_options = [
#                 f"Maintenance système {project.name} - Intervention technique",
#                 f"Support utilisateurs pour {activity.name}",
#                 f"Mise à jour infrastructure {project.name}",
#                 f"Résolution incident critique",
#                 f"Installation et configuration nouveau matériel"
#             ]
#         else:  # Consulting
#             comments_options = [
#                 f"Mission de conseil {project.name} - Phase {random.randint(1, 3)}",
#                 f"Préparation proposition commerciale",
#                 f"Analyse besoins client {project.name}",
#                 f"Formation équipe projet",
#                 f"Livrable {activity.name} en cours"
#             ]
#
#         program_data = {
#             'name': f'{department.name}-{counter:03d}-{project.name[:15]}-{month_name}',
#             'my_month': month_name,
#             'week_of': week_of_year,
#             'project_id': project.id,
#             'activity_id': activity.id,
#             'procedure_id': procedure_id,  # *** AJOUTÉ ***
#             'task_description_id': task_formulation_id,  # *** AJOUTÉ ***
#             'deliverable_ids': deliverable_ids,  # *** AJOUTÉ ***
#             'support_ids': support_ids,  # *** AJOUTÉ ***
#             'work_programm_department_id': department.id,
#             'priority': random.choice(priorities),
#             'complexity': random.choice(complexities),
#             'duration_effort': base_effort + random.randint(-4, 8),
#             'status': status,
#             'completion_percentage': completion_map[status],
#             'assignment_date': assignment_date.date(),
#             'initial_deadline': initial_deadline.date(),
#             'actual_deadline': actual_deadline.date(),
#             'nb_postpones': nb_postpones,
#             'responsible_id': employee.id,
#             'satisfaction_level': random.choice(['low', 'medium', 'high']) if status == 'done' else False,
#             'comments': random.choice(comments_options),
#             'champ1': f"Données spécifiques {department.name}" if department.dpt_type == 'external' else '',
#             'champ2': f"Informations complémentaires mission {counter}" if department.dpt_type == 'external' else ''
#         }
#
#         return program_data



import logging
from datetime import datetime, timedelta
import random
from odoo import api, models

_logger = logging.getLogger(__name__)


class DataSeeder(models.Model):
    _name = 'data.seeder'
    _description = 'Générateur exhaustif de données de test basé sur workflows réels'

    @api.model
    def seed_all_test_data(self):
        """Point d'entrée principal pour générer toutes les données"""
        _logger.info("=== DÉBUT GÉNÉRATION DONNÉES EXHAUSTIVES ===")
        try:
            # Créer les structures workflow pour SUPPORT et CONSULTING
            activities = self.create_complete_workflow_structures()

            # Générer des WorkPrograms exhaustifs
            self.seed_comprehensive_work_programs(activities)

            self.env.cr.commit()
            _logger.info("=== GÉNÉRATION TERMINÉE AVEC SUCCÈS ===")
            return {'status': 'success', 'message': 'Données exhaustives générées avec succès'}
        except Exception as e:
            _logger.error(f"ERREUR GÉNÉRALE: {e}")
            self.env.cr.rollback()
            raise

    @api.model
    def create_complete_workflow_structures(self):
        """Crée les structures workflow complètes pour SUPPORT et CONSULTING"""
        _logger.info("Création des structures workflow complètes...")

        # Vérifier que tous les modèles nécessaires existent
        models_to_check = [
            'workflow.domain', 'workflow.process', 'workflow.subprocess',
            'workflow.activity', 'workflow.procedure', 'workflow.task.formulation',
            'workflow.deliverable'
        ]
        missing_models = [m for m in models_to_check if m not in self.env]
        if missing_models:
            _logger.warning(f"Modèles workflow manquants: {missing_models}")
            return {}

        workflows_config = self._get_complete_workflows_config()
        created_activities = {}

        for domain_name, workflow_data in workflows_config.items():
            domain = self._create_or_get_domain(domain_name, workflow_data.get('type', 'internal'))

            for process_data in workflow_data['processes']:
                process = self._create_or_get_process(process_data['name'], domain.id)

                for subprocess_data in process_data.get('sub_processes', []):
                    subprocess = self._create_or_get_subprocess(subprocess_data['name'], process.id)

                    for activity_data in subprocess_data.get('activities', []):
                        activity = self._create_or_get_activity(activity_data['name'], subprocess.id)
                        created_activities[activity.name] = activity

                        # Créer les procédures
                        for procedure_name in activity_data.get('procedures', []):
                            procedure = self._create_or_get_procedure(procedure_name, activity.id)

                            # Créer les formulations de tâches pour cette procédure
                            for task_form in activity_data.get('task_formulations', []):
                                self._create_or_get_task_formulation(task_form, procedure.id)

                        # Créer les livrables
                        for deliverable_name in activity_data.get('deliverables', []):
                            self._create_or_get_deliverable(deliverable_name, activity.id)

        return created_activities

    def _get_complete_workflows_config(self):
        """Configuration complète des workflows pour SUPPORT et CONSULTING"""
        return {
            'Support': {
                'type': 'internal',
                'processes': [
                    {
                        'name': 'PS4. Gestion du système d\'information',
                        'sub_processes': [
                            {
                                'name': 'PS4.1: Gérer le parc informatique et bureautique',
                                'activities': [
                                    {
                                        'name': 'PS4.1_A1: Gérer les entrées / sorties d\'équipements informatiques',
                                        'procedures': [
                                            'PS4.1_A1_P1: Identifier les besoins en equipement TIC',
                                            'PS4.1_A1_P2: Valider, transmettre le besoin en equipement TIC',
                                            'PS4.1_A1_P3: Acquerir les equipements TIC',
                                            'PS4.1_A1_P4: Mettre à disposition et suivre les equipements informatique'
                                        ],
                                        'deliverables': ['PS4.1_A1_L1: Registre des actifs informatiques'],
                                        'task_formulations': [
                                            'Identifier les besoins en equipement TIC et les references appropriées',
                                            'Valider et transmettre le besoin en equipement TIC',
                                            'Acquerir les equipements TIC',
                                            'Mettre à disposition et suivre les equipements informatique'
                                        ]
                                    },
                                    {
                                        'name': 'PS4.1_A2: Gérer les licences et les abonnements',
                                        'procedures': [
                                            'PS4.1_A2_P1: Identifier et soumettre le besoin en license',
                                            'PS4.1_A2_P2: Valider et transmettre le besoin en license',
                                            'PS4.1_A2_P3: Effectuer l\'abonnement ou l\'acquisition du service',
                                            'PS4.1_A2_P4: Suivre les licences et abonnements'
                                        ],
                                        'deliverables': ['PS4.1_A2_L2: Fiche de besoin de license / abonnement'],
                                        'task_formulations': [
                                            'Identifier et soumettre le besoin en license ou abonnement',
                                            'Valider et transmettre le besoin en license ou abonnement',
                                            'Effectuer l\'abonnement ou l\'acquisition du service',
                                            'Suivre les licences et abonnements'
                                        ]
                                    },
                                    {
                                        'name': 'PS4.1_A3: Installer un équipement ou Logiciel',
                                        'procedures': [
                                            'PS4.1_A3_P1: Installer les équipements et systèmes TIC'
                                        ],
                                        'deliverables': [
                                            'PS4.1_A3_L4: Guide d\'installation des equipements ou logiciel',
                                            'PS4.1_A3_L5: Fiche d\'utilisation des outils',
                                            'PS4.1_A3_L6: Requete de maintenance',
                                            'PS4.1_A3_L7: Fiche de suivi de maintenance'
                                        ],
                                        'task_formulations': [
                                            'Installer les équipements et systèmes TIC',
                                            'Configurer les logiciels et applications',
                                            'Tester le bon fonctionnement des installations'
                                        ]
                                    }
                                ]
                            },
                            {
                                'name': 'PS4.2: Gérer le système de Gestion de l\'entreprise',
                                'activities': [
                                    {
                                        'name': 'PS4.2_A1: Gérer les utilisateurs et leurs droits',
                                        'procedures': [
                                            'PS4.2_A1_P1: Créer et gérer les comptes utilisateurs',
                                            'PS4.2_A1_P2: Attribuer et modifier les droits d\'accès'
                                        ],
                                        'deliverables': [
                                            'PS4.2_A1_L1: Matrice des droits',
                                            'PS4.2_A1_L2: Fiche de l\'utilisateur'
                                        ],
                                        'task_formulations': [
                                            'Créer et configurer les comptes utilisateurs',
                                            'Définir et attribuer les droits d\'accès',
                                            'Maintenir la matrice des droits'
                                        ]
                                    },
                                    {
                                        'name': 'PS4.2_A2: Maintenir le système',
                                        'procedures': [
                                            'PS4.2_A2_P1: Effectuer la maintenance corrective',
                                            'PS4.2_A2_P2: Effectuer la maintenance évolutive'
                                        ],
                                        'deliverables': ['PS4.2_A2_L3: Rapport de maintenance'],
                                        'task_formulations': [
                                            'Diagnostiquer et corriger les dysfonctionnements',
                                            'Mettre à jour et améliorer le système',
                                            'Documenter les interventions de maintenance'
                                        ]
                                    }
                                ]
                            }
                        ]
                    },
                    {
                        'name': 'PR5. Gestion de la Capacité (Staffing)',
                        'sub_processes': [
                            {
                                'name': 'PR5.1: Etablir les contrats',
                                'activities': [
                                    {
                                        'name': 'PR5.1_A1: Estimer le temps d\'intervention',
                                        'procedures': [
                                            'PR5.1_A1_P1: Estimation temporelle et planification',
                                            'PR5.1_A1_P2: Validation du plan de ressources'
                                        ],
                                        'deliverables': ['PR5.1_A1_L1: Plan de ressources'],
                                        'task_formulations': [
                                            'Estimer le temps d\'intervention et préparer le plan',
                                            'Valider le plan de ressources',
                                            'Ajuster la planification selon les contraintes'
                                        ]
                                    }
                                ]
                            }
                        ]
                    }
                ]
            },
            'Consulting': {
                'type': 'external',
                'processes': [
                    {
                        'name': 'PR1. Faire des propositions',
                        'sub_processes': [
                            {
                                'name': 'PR1.1: Gérer le référentiel des consultants',
                                'activities': [
                                    {
                                        'name': 'PR1.1_A1: Gérer le BOOK CV',
                                        'procedures': [
                                            'PR1.1_A1_P1: Collecte de CV',
                                            'PR1.1_A1_P2: Instruction de mise à jour du Book CV',
                                            'PR1.1_A1_P3: Mise à jour du Book CV'
                                        ],
                                        'deliverables': [
                                            'PR1.1_A1_L1: Modèles et Instructions CV (Français et anglais)',
                                            'PR1.1_A1_L2: BOOK CVs suivant différents modèles'
                                        ],
                                        'task_formulations': [
                                            'Collecter les CV',
                                            'Donner les instructions de mise à jour du Book CV',
                                            'Mettre à jour le Book CV (Insertion, Modification, Suppression)',
                                            'Faire la revue et validation du Book CV'
                                        ]
                                    },
                                    {
                                        'name': 'PR1.1_A3: Gérer le BOOK Personnas',
                                        'procedures': [
                                            'PR1.1_A3_P1: Instruction de mise à jour du Book Persona',
                                            'PR1.1_A3_P2: Mise à jour du Book Persona',
                                            'PR1.1_A3_P3: Revue et Validation du Book Persona'
                                        ],
                                        'deliverables': [
                                            'PR1.1_A2_L1: Modèle et Instructions Profile (Français et anglais)',
                                            'PR1.1_A5_L2: Dossier expert'
                                        ],
                                        'task_formulations': [
                                            'Donner les instructions de mise à jour du Book Persona',
                                            'Faire la mise à jour du Book Persona (Insertion, Modification, Suppression)',
                                            'Faire la revue et validation du Book Persona'
                                        ]
                                    }
                                ]
                            },
                            {
                                'name': 'PR1.2: Gérer les références/expériences',
                                'activities': [
                                    {
                                        'name': 'PR1.2_A1: Gérer le BOOK Références détaillés',
                                        'procedures': [
                                            'PR1.2_A1_P3: Mise à jour du Book Références',
                                            'PR1.2_A1_P4: Revue et Validation du Book Références'
                                        ],
                                        'deliverables': [
                                            'PR1.2_A1_L1: Modèles et Instructions Reference (Français et anglais)',
                                            'PR1.2_A1_L2: BOOK Références détaillés suivant différents modèles'
                                        ],
                                        'task_formulations': [
                                            'Mettre à jour le Book Références (Insertion, Modification, Suppression)',
                                            'Faire la revue et validation du Book Références'
                                        ]
                                    },
                                    {
                                        'name': 'PR1.2_A2: Gérer le registre des expériences',
                                        'procedures': [
                                            'PR1.2_A2_P1: Instruction de mise à jour du Registre des Expériences',
                                            'PR1.2_A2_P2: Mise à jour du Registre des expériences'
                                        ],
                                        'deliverables': [
                                            'PR1.2_A2_L1: Modèles et Instructions Registre des expériences',
                                            'PR1.2_A2_L2: Registre des expériences'
                                        ],
                                        'task_formulations': [
                                            'Donner les instructions de mise à jour du Registre des Expériences',
                                            'Mettre à jour le Registre des expériences (Insertion, Modification, Suppression)'
                                        ]
                                    }
                                ]
                            }
                        ]
                    },
                    {
                        'name': 'PR2. Préparation des Missions',
                        'sub_processes': [
                            {
                                'name': 'PR2.1: Elaborer le plan projet',
                                'activities': [
                                    {
                                        'name': 'PR2.1_A1: Définir la méthodologie projet',
                                        'procedures': [
                                            'PR2.1_A1_P1: Analyser les exigences du projet',
                                            'PR2.1_A1_P2: Sélectionner la méthodologie appropriée'
                                        ],
                                        'deliverables': ['PR2.1_A1_L1: Document de méthodologie projet'],
                                        'task_formulations': [
                                            'Analyser les exigences et contraintes du projet',
                                            'Sélectionner et adapter la méthodologie appropriée',
                                            'Documenter la méthodologie retenue'
                                        ]
                                    }
                                ]
                            }
                        ]
                    }
                ]
            }
        }

    def _create_or_get_domain(self, name, domain_type):
        """Crée ou récupère un domaine"""
        Domain = self.env['workflow.domain']
        domain = Domain.search([('name', '=', name)], limit=1)
        if not domain:
            domain = Domain.create({'name': name, 'dpt_type': domain_type})
        return domain

    def _create_or_get_process(self, name, domain_id):
        """Crée ou récupère un processus"""
        Process = self.env['workflow.process']
        process = Process.search([('name', '=', name)], limit=1)
        if not process:
            process = Process.create({'name': name, 'domain_id': domain_id})
        return process

    def _create_or_get_subprocess(self, name, process_id):
        """Crée ou récupère un sous-processus"""
        SubProcess = self.env['workflow.subprocess']
        subprocess = SubProcess.search([('name', '=', name)], limit=1)
        if not subprocess:
            subprocess = SubProcess.create({'name': name, 'process_id': process_id})
        return subprocess

    def _create_or_get_activity(self, name, subprocess_id):
        """Crée ou récupère une activité"""
        Activity = self.env['workflow.activity']
        activity = Activity.search([('name', '=', name)], limit=1)
        if not activity:
            activity = Activity.create({'name': name, 'sub_process_id': subprocess_id})
        return activity

    def _create_or_get_procedure(self, name, activity_id):
        """Crée ou récupère une procédure"""
        Procedure = self.env['workflow.procedure']
        procedure = Procedure.search([('name', '=', name)], limit=1)
        if not procedure:
            procedure = Procedure.create({'name': name, 'activity_id': activity_id})
        return procedure

    def _create_or_get_task_formulation(self, name, procedure_id):
        """Crée ou récupère une formulation de tâche"""
        TaskForm = self.env['workflow.task.formulation']
        task_form = TaskForm.search([('name', '=', name)], limit=1)
        if not task_form:
            task_form = TaskForm.create({'name': name, 'procedure_id': procedure_id})
        return task_form

    def _create_or_get_deliverable(self, name, activity_id):
        """Crée ou récupère un livrable"""
        Deliverable = self.env['workflow.deliverable']
        deliverable = Deliverable.search([('name', '=', name)], limit=1)
        if not deliverable:
            deliverable = Deliverable.create({'name': name, 'activity_id': activity_id})
        return deliverable

    def _get_month_name_from_date(self, date_obj):
        """Retourne le nom du mois en français à partir d'une date"""
        months_fr = {
            1: 'janvier', 2: 'février', 3: 'mars', 4: 'avril',
            5: 'mai', 6: 'juin', 7: 'juillet', 8: 'août',
            9: 'septembre', 10: 'octobre', 11: 'novembre', 12: 'décembre'
        }
        return months_fr.get(date_obj.month, 'janvier')

    def _get_week_of_year(self, date_obj):
        """Retourne le numéro de semaine dans l'année"""
        return date_obj.isocalendar()[1]

    def _get_monday_of_week(self, date_obj):
        """Retourne le lundi de la semaine pour une date donnée au format YYYY-MM-DD"""
        # Calculer le lundi de la semaine
        monday = date_obj - timedelta(days=date_obj.weekday())
        return monday.strftime("%Y-%m-%d")

    @api.model
    def seed_comprehensive_work_programs(self, activities):
        """Génère des WorkPrograms exhaustifs et réalistes avec cohérence date/semaine"""
        _logger.info("=== DÉBUT GÉNÉRATION WORK.PROGRAMS EXHAUSTIFS ===")

        WorkProgram = self.env['work.program']

        # Récupérer les données existantes
        projects = list(self.env['project.project'].search([]))
        employees = list(self.env['hr.employee'].search([]))
        support_dept = self.env['hr.department'].search([('name', '=', 'Support')], limit=1)
        consulting_dept = self.env['hr.department'].search([('name', '=', 'Consulting')], limit=1)

        if not projects or not employees:
            _logger.warning("Projets ou employés inexistants, génération annulée")
            return

        # Séparer les employés par département
        support_employees = [emp for emp in employees if emp.department_id == support_dept]
        consulting_employees = [emp for emp in employees if emp.department_id == consulting_dept]

        # Séparer les activités par domaine
        support_activities = [act for name, act in activities.items() if 'PS4' in name or 'PR5' in name]
        consulting_activities = [act for name, act in activities.items() if 'PR1' in name or 'PR2' in name]

        # Base date fixe pour cohérence (1er septembre 2024)
        base_date = datetime(2024, 9, 1)
        program_counter = 1

        # Générer pour les 6 derniers mois + 6 mois futurs
        for month_offset in range(-6, 7):  # -6 à +6 mois
            # Calcul précis du mois cible
            target_year = base_date.year
            target_month = base_date.month + month_offset

            # Ajuster année si nécessaire
            while target_month <= 0:
                target_month += 12
                target_year -= 1
            while target_month > 12:
                target_month -= 12
                target_year += 1

            # Date du premier jour du mois cible
            month_start = datetime(target_year, target_month, 1)
            month_name = self._get_month_name_from_date(month_start)

            # Calculer le dernier jour du mois
            if target_month == 12:
                next_month_start = datetime(target_year + 1, 1, 1)
            else:
                next_month_start = datetime(target_year, target_month + 1, 1)
            month_end = next_month_start - timedelta(days=1)

            # Générer 2-4 programmes par mois pour chaque département
            nb_programs_per_month = random.randint(2, 4)

            # Générer pour le département SUPPORT
            if support_employees and support_activities:
                for i in range(nb_programs_per_month):
                    employee = random.choice(support_employees)
                    project = random.choice(projects)
                    activity = random.choice(support_activities)

                    # Date d'assignation dans le mois cible
                    day_in_month = random.randint(1, month_end.day)
                    assignment_date = datetime(target_year, target_month, day_in_month)

                    program_data = self._generate_program_data_with_relations(
                        employee, project, activity, support_dept,
                        assignment_date, program_counter, activities
                    )

                    try:
                        WorkProgram.create(program_data)
                        program_counter += 1
                    except Exception as e:
                        _logger.error(f"Erreur création WorkProgram SUPPORT {employee.name}: {e}")

            # Générer pour le département CONSULTING
            if consulting_employees and consulting_activities:
                for i in range(nb_programs_per_month):
                    employee = random.choice(consulting_employees)
                    project = random.choice(projects)
                    activity = random.choice(consulting_activities)

                    # Date d'assignation dans le mois cible
                    day_in_month = random.randint(1, month_end.day)
                    assignment_date = datetime(target_year, target_month, day_in_month)

                    program_data = self._generate_program_data_with_relations(
                        employee, project, activity, consulting_dept,
                        assignment_date, program_counter, activities
                    )

                    try:
                        WorkProgram.create(program_data)
                        program_counter += 1
                    except Exception as e:
                        _logger.error(f"Erreur création WorkProgram CONSULTING {employee.name}: {e}")

        _logger.info(f"=== FIN GÉNÉRATION WORK.PROGRAMS - {program_counter - 1} programmes créés ===")

    def _generate_program_data_with_relations(self, employee, project, activity, department,
                                              assignment_date, counter, activities):
        """Génère les données réalistes pour un WorkProgram avec toutes les relations"""

        # Calculs basés sur la date d'assignation réelle
        month_name = self._get_month_name_from_date(assignment_date)
        week_of_year = self._get_week_of_year(assignment_date)
        # CORRECTION PRINCIPALE : Utiliser le format attendu par my_week_of
        monday_of_week = self._get_monday_of_week(assignment_date)
        initial_deadline = assignment_date + timedelta(days=random.randint(7, 28))

        # Statuts réalistes avec distribution
        status_weights = ['draft', 'ongoing', 'ongoing', 'done', 'done', 'done', 'cancelled']
        status = random.choice(status_weights)

        # Gestion des reports et dates réelles
        nb_postpones = 0
        actual_deadline = initial_deadline
        if status in ['ongoing', 'done'] and random.random() < 0.3:
            nb_postpones = random.randint(1, 3)
            actual_deadline = initial_deadline + timedelta(days=nb_postpones * random.randint(3, 7))

        # Pourcentages de completion réalistes
        completion_map = {
            'draft': random.randint(0, 15),
            'ongoing': random.randint(20, 80),
            'done': random.randint(95, 100),
            'cancelled': random.randint(0, 40)
        }

        # Priorités et complexités variées
        priorities = ['low', 'medium', 'high']
        complexities = ['low', 'medium', 'high']

        # Efforts variables selon le département
        if department.name == 'Support':
            base_effort = random.choice([4, 8, 12, 16, 24])
        else:  # Consulting
            base_effort = random.choice([8, 16, 24, 32, 40, 56])

        # Récupérer une procédure liée à l'activité
        procedures = self.env['workflow.procedure'].search([('activity_id', '=', activity.id)])
        procedure_id = procedures[0].id if procedures else False

        # Récupérer une formulation de tâche liée à la procédure
        task_formulation_id = False
        if procedure_id:
            task_formulations = self.env['workflow.task.formulation'].search([('procedure_id', '=', procedure_id)])
            task_formulation_id = task_formulations[0].id if task_formulations else False

        # Récupérer les livrables liés à l'activité
        deliverables = self.env['workflow.deliverable'].search([('activity_id', '=', activity.id)])
        deliverable_ids = [
            (6, 0, [d.id for d in deliverables[:random.randint(1, min(3, len(deliverables)))] if deliverables])]

        # Ajouter du support (employés du même département, différents du responsable)
        potential_support = [emp for emp in self.env['hr.employee'].search([('department_id', '=', department.id)])
                             if emp.id != employee.id]
        nb_support = random.randint(0, min(2, len(potential_support)))
        support_ids = [
            (6, 0, [emp.id for emp in random.sample(potential_support, nb_support)])] if potential_support else [
            (5, 0, 0)]

        # Commentaires variés selon le département
        if department.name == 'Support':
            comments_options = [
                f"Maintenance système {project.name} - Intervention technique",
                f"Support utilisateurs pour {activity.name}",
                f"Mise à jour infrastructure {project.name}",
                f"Résolution incident critique",
                f"Installation et configuration nouveau matériel"
            ]
        else:  # Consulting
            comments_options = [
                f"Mission de conseil {project.name} - Phase {random.randint(1, 3)}",
                f"Préparation proposition commerciale",
                f"Analyse besoins client {project.name}",
                f"Formation équipe projet",
                f"Livrable {activity.name} en cours"
            ]

        program_data = {
            'name': f'{department.name}-{counter:03d}-{project.name[:15]}-{month_name}',
            'my_month': month_name,
            'week_of': week_of_year,
            'my_week_of': monday_of_week,  # CORRECTION PRINCIPALE : Utiliser le bon champ
            'project_id': project.id,
            'activity_id': activity.id,
            'procedure_id': procedure_id,
            'task_description_id': task_formulation_id,
            'deliverable_ids': deliverable_ids,
            'support_ids': support_ids,
            'work_programm_department_id': department.id,
            'priority': random.choice(priorities),
            'complexity': random.choice(complexities),
            'duration_effort': base_effort + random.randint(-4, 8),
            'status': status,
            'completion_percentage': completion_map[status],
            'assignment_date': assignment_date.date(),
            'initial_deadline': initial_deadline.date(),
            'actual_deadline': actual_deadline.date(),
            'nb_postpones': nb_postpones,
            'responsible_id': employee.id,
            'satisfaction_level': random.choice(['low', 'medium', 'high']) if status == 'done' else False,
            'comments': random.choice(comments_options),
            'champ1': f"Données spécifiques {department.name}" if department.dpt_type == 'external' else '',
            'champ2': f"Informations complémentaires mission {counter}" if department.dpt_type == 'external' else ''
        }

        return program_data