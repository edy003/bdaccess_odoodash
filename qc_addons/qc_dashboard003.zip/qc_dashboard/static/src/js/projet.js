// /** @odoo-module **/
// import { registry } from "@web/core/registry";
// import { useService } from "@web/core/utils/hooks";
// const { Component } = owl;
// const { useState, onMounted, onWillUnmount, useRef } = owl.hooks;

// export class ProjectManagementDashboard extends Component {
//     setup() {
//         console.log("Initialisation du composant ProjectManagementDashboard");

//         // ===== ÉTAT PRINCIPAL =====
//         this.state = useState({
//             loading: false,
//             error: null,

//             // Filtres - ✅ Initialiser avec "" au lieu de null
//             selectedProjectType: "",
//             selectedPartnerId: "",
//             selectedProjectManagerId: "",
//             selectedDepartmentId: "",

//             // Listes déroulantes
//             projectTypes: [],
//             availablePartners: [],
//             availableProjectManagers: [],
//             availableDepartments: [],

//             // KPI
//             totalProjects: '--',
//             totalDueProjects: '--',
//             totalLateProjects: '--',
//             totalDepartments : '--',

//             // Tableau
//             tableData: [],
//         });

//         // ===== SERVICES =====
//         this.rpc = useService("rpc");
//         this.orm = useService("orm");
//         this.action = useService("action");
//         this.user = useService("user");

//         // ===== HOOKS =====
//         onMounted(async () => {
//             await this.loadInitialData();
//         });
//     }

//     // ===== CHARGEMENT INITIAL =====
//     async loadInitialData() {
//         this.state.loading = true;
//         try {
//             await Promise.all([
//                 this.loadProjectTypes(),
//                 this.loadPartners(),
//                 this.loadProjectManagers(),
//                 this.loadDepartments(),
                
//             ]);
//             await this.loadProjectCount();
//             await this.loadProjectsDue();
//             await this.loadProjectsLate();
//             await this.loadDepartmentsCount();

//         } catch (error) {
//             console.error("Erreur lors du chargement initial:", error);
//             this.state.error = error.message;
//         } finally {
//             this.state.loading = false;
//         }
//     }

//     // ===== CHARGEMENT DES LISTES =====
//     async loadProjectTypes() {
//         try {
//             const response = await this.rpc('/dashboard/project_types', {});
//             if (!response.error) {
//                 this.state.projectTypes = response.project_types || [];
//                 console.log("Types de projets chargés:", this.state.projectTypes);
//             }
//         } catch (error) {
//             console.error("Erreur lors du chargement des types de projets:", error);
//         }
//     }

//     async loadPartners() {
//         try {
//             const response = await this.rpc('/dashboard/partners', {});
//             if (!response.error) {
//                 this.state.availablePartners = response.partners || [];
//                 console.log("Partenaires chargés:", this.state.availablePartners);
//             }
//         } catch (error) {
//             console.error("Erreur lors du chargement des partenaires:", error);
//         }
//     }

//     async loadProjectManagers() {
//         try {
//             const response = await this.rpc('/dashboard/project_managers', {});
//             if (!response.error) {
//                 this.state.availableProjectManagers = response.managers || [];
//                 console.log("Chefs de projet chargés:", this.state.availableProjectManagers);
//             }
//         } catch (error) {
//             console.error("Erreur lors du chargement des chefs de projet:", error);
//         }
//     }

//     // ✅ DÉPARTEMENTS : Via ORM (pas d'endpoint nécessaire)
//     async loadDepartments() {
//         try {
//             const departments = await this.orm.searchRead(
//                 "hr.department",
//                 [],
//                 ["id", "name"]
//             );
//             this.state.availableDepartments = departments;
//             console.log("Départements chargés:", this.state.availableDepartments);
//         } catch (error) {
//             console.error("Erreur départements:", error);
//         }
//     }

//     // ===== CHARGEMENT DU KPI =====
//     async loadProjectCount() {
//         try {
//             console.log("Chargement du nombre de projets avec filtres:", {
//                 project_type: this.state.selectedProjectType,
//                 partner_id: this.state.selectedPartnerId,
//                 project_manager_id: this.state.selectedProjectManagerId,
//                 department_ids: this.state.selectedDepartmentId,
//             });

//             // ✅ Convertir department_id en tableau seulement si non vide
//             let departmentIds = null;
//             if (this.state.selectedDepartmentId && this.state.selectedDepartmentId !== "") {
//                 departmentIds = [parseInt(this.state.selectedDepartmentId)];
//             }

//             const response = await this.rpc('/dashboard/project_count', {
//                 // ✅ Envoyer null si chaîne vide, sinon la valeur
//                 project_type: this.state.selectedProjectType || null,
//                 partner_id: this.state.selectedPartnerId || null,
//                 project_manager_id: this.state.selectedProjectManagerId || null,
//                 department_ids: departmentIds,
//             });

//             if (!response.error) {
//                 this.state.totalProjects = response.total_projects;
//                 console.log("Nombre de projets chargé:", this.state.totalProjects);
//             } else {
//                 console.error("Erreur dans la réponse:", response.message);
//                 this.state.totalProjects = 0;
//             }
//         } catch (error) {
//             console.error("Erreur lors du chargement du nombre de projets:", error);
//             this.state.totalProjects = 0;
//         }
//     }

//     async loadProjectsDue() {
//     try {
//         console.log("Chargement des projets dont la date de fin <= aujourd'hui avec filtres:", {
//             project_type: this.state.selectedProjectType,
//             partner_id: this.state.selectedPartnerId,
//             project_manager_id: this.state.selectedProjectManagerId,
//             department_ids: this.state.selectedDepartmentId,
//         });

//         // Conversion du département en tableau
//         let departmentIds = null;
//         if (this.state.selectedDepartmentId && this.state.selectedDepartmentId !== "") {
//             departmentIds = [parseInt(this.state.selectedDepartmentId)];
//         }

//         const response = await this.rpc('/dashboard/projects_due', {
//             project_type: this.state.selectedProjectType || null,
//             partner_id: this.state.selectedPartnerId || null,
//             project_manager_id: this.state.selectedProjectManagerId || null,
//             department_ids: departmentIds,
//         });

//         if (!response.error) {
//             this.state.totalDueProjects = response.total_projects;
//             console.log("Projets dus chargés:", this.state.totalDueProjects);  
//         } else {
//             console.error("Erreur dans la réponse:", response.message);
//             this.state.totalDueProjects = 0;
//         }
//     } catch (error) {
//         console.error("Erreur lors du chargement des projets dus:", error);
//         this.state.totalDueProjects = 0;
//     }
// }
// async loadProjectsLate() {
//     try {
//         console.log("Chargement des projets en retard avec filtres:", {
//             project_type: this.state.selectedProjectType,
//             partner_id: this.state.selectedPartnerId,
//             project_manager_id: this.state.selectedProjectManagerId,
//             department_ids: this.state.selectedDepartmentId,
//         });

//         let departmentIds = null;
//         if (this.state.selectedDepartmentId && this.state.selectedDepartmentId !== "") {
//             departmentIds = [parseInt(this.state.selectedDepartmentId)];
//         }

//         const response = await this.rpc('/dashboard/projects_late', {
//             project_type: this.state.selectedProjectType || null,
//             partner_id: this.state.selectedPartnerId || null,
//             project_manager_id: this.state.selectedProjectManagerId || null,
//             department_ids: departmentIds,
//         });

//         if (!response.error) {
//             this.state.totalLateProjects = response.total_projects;
//             console.log("Projets en retard chargés:", this.state.totalLateProjects);
//         } else {
//             console.error("Erreur dans la réponse:", response.message);
//             this.state.totalLateProjects = 0;
//         }
//     } catch (error) {
//         console.error("Erreur lors du chargement des projets en retard:", error);
//         this.state.totalLateProjects = 0;
//     }
// }

// async loadDepartmentsCount() {
//     try {
//         console.log("Chargement du nombre de départements impliqués avec filtres:", {
//             project_type: this.state.selectedProjectType,
//             partner_id: this.state.selectedPartnerId,
//             project_manager_id: this.state.selectedProjectManagerId,
//             department_ids: this.state.selectedDepartmentId,
//         });

//         let departmentIds = null;
//         if (this.state.selectedDepartmentId && this.state.selectedDepartmentId !== "") {
//             departmentIds = [parseInt(this.state.selectedDepartmentId)];
//         }

//         const response = await this.rpc('/dashboard/departments_count', {
//             project_type: this.state.selectedProjectType || null,
//             partner_id: this.state.selectedPartnerId || null,
//             project_manager_id: this.state.selectedProjectManagerId || null,
//             department_ids: departmentIds,
//         });

//         if (!response.error) {
//             this.state.totalDepartments = response.total_departments;
//             console.log("Départements chargés:", this.state.totalDepartments);
//         } else {
//             console.error("Erreur dans la réponse:", response.message);
//             this.state.totalDepartments = 0;
//         }
//     } catch (error) {
//         console.error("Erreur lors du chargement du nombre de départements:", error);
//         this.state.totalDepartments = 0;
//     }
// }



//     // ===== GESTIONNAIRES DE FILTRES =====
//     onProjectTypeChange(ev) {
//         this.state.selectedProjectType = ev.target.value || "";
//         console.log("Type de projet sélectionné:", this.state.selectedProjectType);
//     }

//     onPartnerChange(ev) {
//         this.state.selectedPartnerId = ev.target.value || "";
//         console.log("Partenaire sélectionné:", this.state.selectedPartnerId);
//     }

//     onProjectManagerChange(ev) {
//         this.state.selectedProjectManagerId = ev.target.value || "";
//         console.log("Chef de projet sélectionné:", this.state.selectedProjectManagerId);
//     }

//     onDepartmentChange(ev) {
//         this.state.selectedDepartmentId = ev.target.value || "";
//         console.log("Département sélectionné:", this.state.selectedDepartmentId);
//     }

//     // ===== ACTIONS SUR LES FILTRES =====
//     async onApplyFilters() {
//         console.log("Application des filtres");
//         this.state.loading = true;
//         try {
//             await this.loadProjectCount();
//             await this.loadProjectsDue();
//             await this.loadProjectsLate();
//             await this.loadDepartmentsCount();

//         } catch (error) {
//             console.error("Erreur lors de l'application des filtres:", error);
//         } finally {
//             this.state.loading = false;
//         }
//     }

//     async onResetFilters() {
//         console.log("Réinitialisation des filtres");
        
//         // ✅ Utiliser "" au lieu de null pour réinitialiser les selects
//         this.state.selectedProjectType = "";
//         this.state.selectedPartnerId = "";
//         this.state.selectedProjectManagerId = "";
//         this.state.selectedDepartmentId = "";
        
//         await this.onApplyFilters();
//     }
// }

// ProjectManagementDashboard.template = "qc_dashboard.ProjectManagementDashboard";
// registry.category('actions').add('qc_dashboard.action_project_management_dashboard', ProjectManagementDashboard);



/** @odoo-module **/
import { registry } from "@web/core/registry";
import { useService } from "@web/core/utils/hooks";
const { Component } = owl;
const { useState, onMounted, onWillUnmount, useRef } = owl.hooks;

export class ProjectManagementDashboard extends Component {
    setup() {
        console.log("Initialisation du composant ProjectManagementDashboard");

        // ===== ÉTAT PRINCIPAL =====
        this.state = useState({
            loading: false,
            error: null,

            // Filtres
            selectedProjectType: "",
            selectedPartnerId: "",
            selectedProjectManagerId: "",
            selectedDepartmentId: "",

            // Listes déroulantes
            projectTypes: [],
            availablePartners: [],
            availableProjectManagers: [],
            availableDepartments: [],

            // KPI
            totalProjects: '--',
            totalDueProjects: '--',
            totalLateProjects: '--',
            totalDepartments: '--',

            // Graphiques
            chartData: {
                projectTypeDistribution: { labels: [], values: [] },
                projectsByDepartment: { labels: [], values: [] },
                // projectsByStatus: { labels: [], values: [] },
                // projectsByDepartment: { labels: [], values: [] },
            },

            // Tableau
            // tableData: [],
        });

        // ===== SERVICES =====
        this.rpc = useService("rpc");
        this.orm = useService("orm");
        this.action = useService("action");
        this.user = useService("user");

        // ===== REFS POUR GRAPHIQUES =====
        this.projectTypeDistributionChartRef = useRef("project-type-distribution-chart");
        this.projectsByDepartmentChartRef = useRef("projects-by-department-chart");
        // this.projectStatusChartRef = useRef("project-status-chart");
        // this.projectDepartmentChartRef = useRef("project-department-chart");
        // this.gridRef = useRef("projects-grid");
        
        // ===== GRID VARIABLES =====
        // this.gridApi = null;
        // this.gridColumnApi = null;
        // this.gridInitialized = false;
        // this.gridInstance = null;

        // ===== HOOKS =====
        onMounted(async () => {
            await this.loadInitialData();
            setTimeout(() => {
                this.initializeGrid();
            }, 100);
        });

        // onWillUnmount(() => {
        //     this.destroyGrid();
        // });
    }

    // ===== CHARGEMENT INITIAL =====
    async loadInitialData() {
        this.state.loading = true;
        try {
            // Charger les listes de filtres en parallèle
            await Promise.all([
                this.loadProjectTypes(),
                this.loadPartners(),
                this.loadProjectManagers(),
                this.loadDepartments(),
            ]);

            // Charger toutes les données (KPI + graphiques + tableau)
            await this.loadAllData();

        } catch (error) {
            console.error("Erreur lors du chargement initial:", error);
            this.state.error = error.message;
        } finally {
            this.state.loading = false;
        }
    }

    // ===== CHARGEMENT DE TOUTES LES DONNÉES =====
    async loadAllData() {
        const params = this.getFilterParams();
        
        try {
            await Promise.all([
                this.loadKPIData(params), 
                this.loadChartData(params),
                // this.loadTableData(params)
            ]);
            this.renderCharts();
            // this.updateGridData();
        } catch (error) {
            console.error("Erreur lors du chargement des données:", error);
            throw error;
        }
    }

    // ===== HELPER : Récupérer les paramètres de filtres =====
    getFilterParams() {
        let departmentIds = null;
        if (this.state.selectedDepartmentId && this.state.selectedDepartmentId !== "") {
            departmentIds = [parseInt(this.state.selectedDepartmentId)];
        }

        return {
            project_type: this.state.selectedProjectType || null,
            partner_id: this.state.selectedPartnerId || null,
            project_manager_id: this.state.selectedProjectManagerId || null,
            department_ids: departmentIds,
        };
    }

    // ===== CHARGEMENT DES KPI =====
    async loadKPIData(params) {
        try {
            const [
                projectCountResponse,
                projectsDueResponse,
                projectsLateResponse,
                departmentsCountResponse
            ] = await Promise.all([
                this.rpc('/dashboard/project_count', params),
                this.rpc('/dashboard/projects_due', params),
                this.rpc('/dashboard/projects_late', params),
                this.rpc('/dashboard/departments_count', params),
            ]);

            // Mise à jour des KPI
            this.state.totalProjects = projectCountResponse.error ? '--' : projectCountResponse.total_projects;
            this.state.totalDueProjects = projectsDueResponse.error ? '--' : projectsDueResponse.total_projects;
            this.state.totalLateProjects = projectsLateResponse.error ? '--' : projectsLateResponse.total_projects;
            this.state.totalDepartments = departmentsCountResponse.error ? '--' : departmentsCountResponse.total_departments;

            console.log("✅ KPI chargés avec succès");
        } catch (error) {
            console.error("Erreur lors du chargement des KPI:", error);
            this.state.totalProjects = '--';
            this.state.totalDueProjects = '--';
            this.state.totalLateProjects = '--';
            this.state.totalDepartments = '--';
        }
    }

    // ===== CHARGEMENT DES GRAPHIQUES =====
    async loadChartData(params) {
        try {
            await Promise.all([
                this.loadProjectTypeDistributionChart(params),
                this.loadProjectsByDepartmentChart(params),
                // this.loadProjectStatusChart(params),
                // this.loadProjectDepartmentChart(params),
            ]);
        } catch (error) {
            console.error("Erreur lors du chargement des données graphiques:", error);
            this.state.chartData = {
                projectTypeDistribution: { labels: [], values: [] },
                // projectsByStatus: { labels: [], values: [] },
                // projectsByDepartment: { labels: [], values: [] },
            };
        }
    }

   async loadProjectTypeDistributionChart(params) {
    try {
        console.log("Appel RPC vers /dashboard/project_type_distribution avec params:", params);
        
        const result = await this.rpc("/dashboard/project_type_distribution", params);

        // CETTE LIGNE EST LA PLUS IMPORTANTE DE TA VIE ACTUELLEMENT
        console.log("RÉPONSE COMPLÈTE DE L'ENDPOINT :", result);

        if (result.error) {
            console.error("Erreur endpoint :", result.message);
            this.state.chartData.projectTypeDistribution = { labels: [], values: [] };
            return;
        }

        // Si tu vois "undefined" ici → ton Python ne renvoie pas chart_data
        console.log("chart_data reçu :", result.chart_data);

        if (!result.chart_data) {
            console.warn("chart_data est manquant ! L'endpoint ne renvoie pas le bon format");
            this.state.chartData.projectTypeDistribution = { labels: [], values: [] };
            return;
        }

        this.state.chartData.projectTypeDistribution = result.chart_data;
        console.log("Données bien chargées →", this.state.chartData.projectTypeDistribution);

    } catch (error) {
        console.error("Exception RPC :", error);
        this.state.chartData.projectTypeDistribution = { labels: [], values: [] };
    }
}

async loadProjectsByDepartmentChart(params) {
    try {
        const result = await this.rpc("/dashboard/projects_by_department", params);
        if (result.error || !result.chart_data) {
            this.state.chartData.projectsByDepartment = { labels: [], values: [] };
            return;
        }
        this.state.chartData.projectsByDepartment = result.chart_data;
        console.log("Données projets par département chargées :", result.chart_data);
    } catch (error) {
        console.error("Erreur chargement projets par département :", error);
        this.state.chartData.projectsByDepartment = { labels: [], values: [] };
    }
}

    // ===== CHARGEMENT DES DONNÉES DU TABLEAU =====
    // async loadTableData(params) {
    //     try {
    //         console.log("Chargement des données du tableau...");
    //         const result = await this.rpc("/dashboard/projects_grid", params);
    //         if (result.error) {
    //             console.error("Erreur lors du chargement du tableau:", result.message);
    //             this.state.tableData = [];
    //         } else {
    //             this.state.tableData = result.data || [];
    //             console.log("Données du tableau chargées:", result.data.length, "lignes");
    //         }
    //     } catch (error) {
    //         console.error("Erreur lors du chargement du tableau:", error);
    //         this.state.tableData = [];
    //     }
    // }

    // ===== CHARGEMENT DES LISTES DE FILTRES =====
    async loadProjectTypes() {
        try {
            const response = await this.rpc('/dashboard/project_types', {});
            if (!response.error) {
                this.state.projectTypes = response.project_types || [];
                console.log("Types de projets chargés:", this.state.projectTypes);
            }
        } catch (error) {
            console.error("Erreur types de projets:", error);
        }
    }

    async loadPartners() {
        try {
            const response = await this.rpc('/dashboard/partners', {});
            if (!response.error) {
                this.state.availablePartners = response.partners || [];
                console.log("Partenaires chargés:", this.state.availablePartners);
            }
        } catch (error) {
            console.error("Erreur partenaires:", error);
        }
    }

    async loadProjectManagers() {
        try {
            const response = await this.rpc('/dashboard/project_managers', {});
            if (!response.error) {
                this.state.availableProjectManagers = response.managers || [];
                console.log("Chefs de projet chargés:", this.state.availableProjectManagers);
            }
        } catch (error) {
            console.error("Erreur chefs de projet:", error);
        }
    }

    async loadDepartments() {
        try {
            const departments = await this.orm.searchRead(
                "hr.department",
                [],
                ["id", "name"]
            );
            this.state.availableDepartments = departments;
            console.log("Départements chargés:", this.state.availableDepartments);
        } catch (error) {
            console.error("Erreur départements:", error);
        }
    }

    // ===== RENDU DES GRAPHIQUES =====
    renderCharts() {
        console.log("📊 Rendu des graphiques");
        this.renderProjectTypeDistributionChart();
        this.renderProjectsByDepartmentChart();
        // this.renderProjectStatusChart();
        // this.renderProjectDepartmentChart();
    }


    renderProjectTypeDistributionChart() {
        console.log("Tentative de rendu du pie chart types de projets...", {
            chartRef: this.projectTypeDistributionChartRef.el,
            hasData: this.state.chartData.projectTypeDistribution.labels?.length > 0,
            data: this.state.chartData.projectTypeDistribution
        });

        if (!this.projectTypeDistributionChartRef.el) {
            console.warn("Élément DOM du pie chart types de projets introuvable");
            return;
        }

        if (!this.state.chartData.projectTypeDistribution.labels?.length) {
            console.warn("Aucune donnée pour le pie chart types de projets");
            this.projectTypeDistributionChartRef.el.innerHTML = 
                '<div class="text-center p-4 text-gray-500">Aucune donnée à afficher pour les filtres sélectionnés</div>';
            return;
        }

        // Nettoyage propre de l'ancien graphique
        if (typeof Plotly !== 'undefined') {
            try {
                Plotly.purge(this.projectTypeDistributionChartRef.el);
            } catch (e) {
                console.warn("Erreur lors du nettoyage Plotly:", e);
            }
        }
        this.projectTypeDistributionChartRef.el.innerHTML = '';

        if (typeof Plotly === 'undefined') {
            console.warn("Plotly non disponible");
            return;
        }

        try {
            // ✅ Mapping des labels techniques vers labels français
            const labelMap = {
                'internal': 'Projets Internes',
                'external': 'Projets Externes',
                'Non défini': 'Non défini'
            };

            // ✅ Traduire les labels
            const translatedLabels = this.state.chartData.projectTypeDistribution.labels.map(
                label => labelMap[label] || label
            );

            // Mapping des couleurs par type de projet
            const colorMap = {
                'internal': '#3B82F6',        // Bleu vif (projets internes)
                'external': '#10B981',        // Vert émeraude (projets externes)
                'Non défini': '#9CA3AF',      // Gris
            };

            // Génère les couleurs dans le bon ordre (basé sur les labels ORIGINAUX)
            const colors = this.state.chartData.projectTypeDistribution.labels.map(
                label => colorMap[label.trim()] || '#9CA3AF'
            );

            const data = [{
                values: this.state.chartData.projectTypeDistribution.values,
                labels: translatedLabels,  // ✅ Utiliser les labels traduits
                type: 'pie',
                hole: 0.4,
                marker: {
                    colors: colors
                },
                textinfo: 'label+percent',
                textposition: 'none',
                hovertemplate: '<b>%{label}</b><br>' +
                              'Nombre de projets: %{value}<br>' +
                              'Pourcentage: %{percent}<br>' +
                              '<extra></extra>'
            }];

            const layout = {
                paper_bgcolor: '#FFFFFF',
                plot_bgcolor: '#FFFFFF',
                margin: { t: 0, r: 0, b: 0, l: 0 },
                showlegend: true,
                legend: {
                    orientation: "v",
                    yanchor: "middle",
                    y: 0.5,
                    xanchor: "left",
                    x: 1.05,
                    font: { size: 12 }
                },
                font: { family: 'Inter, sans-serif' }
            };

            const config = {
                displayModeBar: false,
                displaylogo: false,
                responsive: true
            };

            Plotly.newPlot(this.projectTypeDistributionChartRef.el, data, layout, config);

            console.log("✅ Pie chart types de projets rendu avec succès");

        } catch (error) {
            console.error("❌ Erreur lors du rendu du pie chart types de projets:", error);
        }
    }

renderProjectsByDepartmentChart() {
    console.log("Rendu du bar chart horizontal (barh) départements...");

    if (!this.projectsByDepartmentChartRef.el) {
        console.warn("Élément DOM du bar chart départements introuvable");
        return;
    }

    // Nettoyage
    if (typeof Plotly !== 'undefined') {
        try { Plotly.purge(this.projectsByDepartmentChartRef.el); } catch (e) {}
    }
    this.projectsByDepartmentChartRef.el.innerHTML = '';

    if (!this.state.chartData.projectsByDepartment.labels?.length) {
        this.projectsByDepartmentChartRef.el.innerHTML = 
            '<div class="text-center p-4 text-gray-500">Aucune donnée à afficher pour les filtres sélectionnés</div>';
        return;
    }

    if (typeof Plotly === 'undefined') return;

    try {
        // Tri décroissant (département avec le + de projets en haut)
        const sorted = this.state.chartData.projectsByDepartment.labels
            .map((label, i) => ({ label, value: this.state.chartData.projectsByDepartment.values[i] }))
            .sort((a, b) => b.value - a.value);

        const sortedLabels = sorted.map(item => item.label);
        const sortedValues = sorted.map(item => item.value);

        const data = [{
            y: sortedLabels,           // ← les noms sur l'axe Y (vertical)
            x: sortedValues,           // ← les valeurs sur l'axe X (horizontal)
            type: 'bar',
            orientation: 'h',          // ← BAR HORIZONTAL
            marker: { 
                color: '#3B82F6',
                line: { width: 1, color: '#2563eb' }
            },
            text: sortedValues.map(String),
            textposition: 'outside',
            hovertemplate: '<b>%{y}</b><br>Nombre de projets: <b>%{x}</b><extra></extra>',
            textfont: { size: 12 }
        }];

        const layout = {
            paper_bgcolor: '#FFFFFF',
            plot_bgcolor: '#FFFFFF',
            margin: { t: 0, r: 0, b: 0, l: 0 },  // ← beaucoup de place à gauche pour les longs noms
            xaxis: { 
                title: 'Nombre de projets',
                gridcolor: '#f0f0f0',
                zeroline: false
            },
            yaxis: { 
                automargin: true,
                tickfont: { size: 11.5 },
                title: null
            },
            font: { family: 'Inter, sans-serif' },
            hovermode: 'closest',
            bargap: 0.35
        };

        const config = {
            displayModeBar: false,
            displaylogo: false,
            responsive: true
        };

        Plotly.newPlot(this.projectsByDepartmentChartRef.el, data, layout, config);


        console.log("Bar chart HORIZONTAL (barh) projets par département → RENDU PARFAIT");
    } catch (error) {
        console.error("Erreur rendu barh départements:", error);
    }
}

    // ===== GESTION DU TABLEAU (AG-GRID) =====
    initializeGrid() {
    
    }

    updateGridData() {
  
    }

    reinitializeGrid() {
    }

    destroyGrid() {
        
    }

    // ===== GESTIONNAIRES DE FILTRES =====
    onProjectTypeChange(ev) {
        this.state.selectedProjectType = ev.target.value || "";
    }

    onPartnerChange(ev) {
        this.state.selectedPartnerId = ev.target.value || "";
    }

    onProjectManagerChange(ev) {
        this.state.selectedProjectManagerId = ev.target.value || "";
    }

    onDepartmentChange(ev) {
        this.state.selectedDepartmentId = ev.target.value || "";
    }

    // ===== ACTIONS SUR LES FILTRES =====
    async onApplyFilters() {
        console.log("🔄 Application des filtres");
        this.state.loading = true;
        try {
            await this.loadAllData();
        } catch (error) {
            console.error("Erreur application filtres:", error);
        } finally {
            this.state.loading = false;
        }
    }

    async onResetFilters() {
        console.log("🔄 Réinitialisation des filtres");
        this.state.selectedProjectType = "";
        this.state.selectedPartnerId = "";
        this.state.selectedProjectManagerId = "";
        this.state.selectedDepartmentId = "";
        await this.onApplyFilters();
    }

    // ===== HELPERS =====
    formatValue(value) {
        if (value === '--' || value === null || value === undefined) return '--';
        return value.toString();
    }
}

ProjectManagementDashboard.template = "qc_dashboard.ProjectManagementDashboard";
registry.category('actions').add('qc_dashboard.action_project_management_dashboard', ProjectManagementDashboard);